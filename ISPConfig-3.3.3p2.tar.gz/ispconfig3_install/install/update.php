<?php

/*
Copyright (c) 2007-2010, Till Brehm, projektfarm Gmbh
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.
    * Neither the name of ISPConfig nor the names of its contributors
      may be used to endorse or promote products derived from this software without
      specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

/*
	ISPConfig 3 updater.

	-------------------------------------------------------------------------------------
	- Interactive update
	-------------------------------------------------------------------------------------
	run:

	php update.php

	-------------------------------------------------------------------------------------
	- Noninteractive (autoupdate) mode
	-------------------------------------------------------------------------------------

	The autoupdate mode can read the updater questions from a .ini style file or from
	a php config file. Examples for both file types are in the docs folder.
	See autoinstall.ini.sample and autoinstall.conf_sample.php.

	run:

	php update.php --autoinstall=autoinstall.ini

	or

	php update.php --autoinstall=autoinstall.conf.php

*/

error_reporting(E_ALL);

define('INSTALLER_RUN', true);
define('INSTALLER_UPDATE', true);

//** The banner on the command line
echo "\n\n".str_repeat('-', 80)."\n";
echo " _____ ___________   _____              __ _         ____
|_   _/  ___| ___ \ /  __ \            / _(_)       /__  \
  | | \ `--.| |_/ / | /  \/ ___  _ __ | |_ _  __ _    _/ /
  | |  `--. \  __/  | |    / _ \| '_ \|  _| |/ _` |  |_ |
 _| |_/\__/ / |     | \__/\ (_) | | | | | | | (_| | ___\ \
 \___/\____/\_|      \____/\___/|_| |_|_| |_|\__, | \____/
                                              __/ |
                                             |___/ ";
echo "\n".str_repeat('-', 80)."\n";
echo "\n\n>> Update  \n\n";

//** Include the library with the basic installer functions
require_once 'lib/install.lib.php';

//** Include the library with the basic updater functions
require_once 'lib/update.lib.php';

//** Include the base class of the installer class
require_once 'lib/installer_base.lib.php';

//** Allow only one update run at a time, the lock is released when this process ends
$update_lock = @fopen('/run/lock/ispconfig-update.lock', 'ce');
if($update_lock && !flock($update_lock, LOCK_EX | LOCK_NB)) {
	die('Another ISPConfig update is running on this server (PID '.trim((string)@file_get_contents('/run/lock/ispconfig-update.lock')).').'."\n");
}
if($update_lock) {
	ftruncate($update_lock, 0);
	fwrite($update_lock, getmypid());
	fflush($update_lock);
}

//** Ensure that current working directory is install directory
$cur_dir = getcwd();
if(realpath(dirname(__FILE__)) != $cur_dir) die("Please run installation/update from _inside_ the install directory!\n");

//** Install logfile
define('ISPC_INSTALL_ROOT', realpath(dirname(__FILE__).'/../'));

//** Include the templating lib
require_once 'lib/classes/tpl.inc.php';

//** Check for ISPConfig 2.x versions
if(is_dir('/root/ispconfig') || is_dir('/home/admispconfig')) {
	if(is_dir('/home/admispconfig')) {
		die('This software cannot be installed on a server which runs ISPConfig 2.x.');
	} else {
		die('This software cannot be installed on a server which runs ISPConfig 2.x; the presence of the /root/ispconfig/ directory may indicate an ISPConfig 2.x installation, otherwise you can remove or rename it to continue.');
	}
}

// Patch is required to reapir latest amavis versions
if(is_installed('amavisd-new') && !is_installed('patch')) die('The patch command is missing. Install patch command and start update again.');

//** Get distribution identifier
$dist = get_distname();

include_once "/usr/local/ispconfig/server/lib/config.inc.php";
$conf_old = $conf;
unset($conf);
define('ISPC_LOG_FILE', $conf_old['ispconfig_log_dir'] . '/update.log');

if($dist['id'] == '') die('Linux distribution or version not recognized.');

//** Include the autoinstaller configuration (for non-interactive setups)
error_reporting(E_ALL ^ E_NOTICE);

//** Get commandline options
$cmd_opt = getopt('', array('autoinstall::'));

//** Load autoinstall file
if(isset($cmd_opt['autoinstall'])) {
	if (empty($cmd_opt['autoinstall'])) { // Meaning --autoinstall was passed without a value.
		// Set default
		$cmd_opt['autoinstall'] = "/usr/local/ispconfig/server/lib/autoinstall.conf.php";
	}
	if (!is_file($cmd_opt['autoinstall']) || !in_array(pathinfo($cmd_opt['autoinstall'], PATHINFO_EXTENSION), array('php', 'ini'))) {
		echo "Autoinstall config file not found or not a .php or .ini file. (default is /usr/local/ispconfig/server/lib/autoinstall.conf.php)\n";
		exit(1);
	}
	$path_parts = pathinfo($cmd_opt['autoinstall']);
	if($path_parts['extension'] == 'php') {
		include_once $cmd_opt['autoinstall'];
	} elseif($path_parts['extension'] == 'ini') {
		$tmp = ini_to_array(file_get_contents($cmd_opt['autoinstall']));
		if(!is_array($tmp['install'])) $tmp['install'] = array();
		if(!is_array($tmp['ssl_cert'])) $tmp['ssl_cert'] = array();
		if(!is_array($tmp['expert'])) $tmp['expert'] = array();
		if(!is_array($tmp['update'])) $tmp['update'] = array();
		$autoinstall = $tmp['update'] + $tmp['install'] + $tmp['ssl_cert'] + $tmp['expert'];
		unset($tmp);
	}
	unset($path_parts);
	define('AUTOINSTALL', true);
} else {
	$autoinstall = array();
	define('AUTOINSTALL', false);
}

//** Include the distribution-specific installer class library and configuration
if(is_file('dist/lib/'.$dist['baseid'].'.lib.php')) include_once 'dist/lib/'.$dist['baseid'].'.lib.php';
include_once 'dist/lib/'.$dist['id'].'.lib.php';
include_once 'dist/conf/'.$dist['confid'].'.conf.php';

//** Get hostname
exec('hostname -f', $tmp_out);
$conf['hostname'] = $tmp_out[0];
unset($tmp_out);

//** Set the mysql login information
$conf["mysql"]["host"] = $conf_old["db_host"];
$conf["mysql"]["database"] = $conf_old["db_database"];
$conf['mysql']['charset'] = 'utf8mb4';
$conf["mysql"]["ispconfig_user"] = $conf_old["db_user"];
$conf["mysql"]["ispconfig_password"] = $conf_old["db_password"];
$conf['mysql']['port'] = $conf_old["db_port"];
if($conf['mysql']['port'] == 0 || $conf['mysql']['port'] == '') $conf['mysql']['port'] = 3306;
$conf['language'] = $conf_old['language'];
$conf['theme'] = $conf_old['theme'];
if($conf['language'] == '{language}') $conf['language'] = 'en';
$conf['timezone'] = (isset($conf_old['timezone']))?$conf_old['timezone']:'UTC';
if($conf['timezone'] == '{timezone}' or trim($conf['timezone']) == '') $conf['timezone'] = 'UTC';
$conf['language_file_import_enabled'] = (isset($conf_old['language_file_import_enabled']))?$conf_old['language_file_import_enabled']:true;

if(isset($conf_old["dbmaster_host"])) $conf["mysql"]["master_host"] = $conf_old["dbmaster_host"];
if(isset($conf_old["dbmaster_port"])) $conf["mysql"]["master_port"] = $conf_old["dbmaster_port"];
if(isset($conf_old["dbmaster_database"])) $conf["mysql"]["master_database"] = $conf_old["dbmaster_database"];
if(isset($conf_old["dbmaster_user"])) $conf["mysql"]["master_ispconfig_user"] = $conf_old["dbmaster_user"];
if(isset($conf_old["dbmaster_password"])) $conf["mysql"]["master_ispconfig_password"] = $conf_old["dbmaster_password"];
if(isset($conf_old['dbmaster_client_flags'])) {
	$conf['mysql']['master_client_flags'] = intval($conf_old['dbmaster_client_flags']);
}
if(isset($conf_old['db_client_flags'])) {
	$conf['mysql']['client_flags'] = intval($conf_old['db_client_flags']);
}

//* Check if this is a master / slave setup
if($conf["mysql"]["master_host"] != '' && $conf["mysql"]["host"] != $conf["mysql"]["master_host"]) {
	$conf['mysql']['master_slave_setup'] = 'y';
}

// Resolve the IP address of the mysql hostname.
if(!$conf['mysql']['ip'] = gethostbyname($conf['mysql']['host'])) die('Unable to resolve hostname'.$conf['mysql']['host']);

$conf['server_id'] = intval($conf_old["server_id"]);
$conf['ispconfig_log_priority'] = $conf_old["log_priority"];
$conf['db_log_message_max_length'] = (isset($conf_old['db_log_message_max_length'])) ? $conf_old['db_log_message_max_length'] : '32768';


$inst = new installer();
$inst->is_update = true;

$inst->check_prerequisites();

echo "This application will update ISPConfig 3 on your server.\n\n";

//* Make a backup before we start the update
$do_backup = $inst->simple_query('Shall the script create a ISPConfig backup in /var/backup/ now?', array('yes', 'no'), 'yes','do_backup');

if($do_backup == 'yes') {

	//* Create the backup directory
	$backup_path = '/var/backup/ispconfig_'.$conf['hostname'].'_'.@date('Y-m-d_H-i');
	$conf['backup_path'] = $backup_path;
	exec("mkdir -p $backup_path");
	exec("chown root:root $backup_path");
	exec("chmod 700 $backup_path");

	//* Do the backup
	swriteln('Creating backup of "/usr/local/ispconfig" directory...');
	exec("tar pcfz $backup_path/ispconfig_software.tar.gz /usr/local/ispconfig 2> /dev/null", $out, $returnvar);
	if($returnvar != 0) die("Backup failed. We stop here...\n");

	swriteln('Creating backup of "/etc" directory...');
	exec("tar pcfz $backup_path/etc.tar.gz /etc 2> /dev/null", $out, $returnvar);
	if($returnvar != 0) die("Backup failed. We stop here...\n");

  if (is_dir('/root/.acme.sh')) {
    swriteln('Creating backup of "/root/.acme.sh" directory...');
    exec("tar pcfz $backup_path/acme.sh.tar.gz /root/.acme.sh 2> /dev/null", $out, $returnvar);
    if($returnvar != 0) die("Backup failed. We stop here...\n");
  }

	exec("chown root:root $backup_path/*.tar.gz");
	exec("chmod 700 $backup_path/*.tar.gz");
}


//** Initialize the MySQL server connection
include_once 'lib/mysql.lib.php';

//** Database update is a bit brute force and should be rebuild later ;)

/*
 * Try to read the DB-admin settings
 */
$clientdb_host   = '';
$clientdb_user   = '';
$clientdb_password  = '';
include_once "/usr/local/ispconfig/server/lib/mysql_clientdb.conf";
$conf["mysql"]["admin_user"] = $clientdb_user;
$conf["mysql"]["admin_password"] = $clientdb_password;
$clientdb_host   = '';
$clientdb_user   = '';
$clientdb_password  = '';

// Report failed logins by return value instead of an exception (default since PHP 8.1), so the retry loops work
mysqli_report(MYSQLI_REPORT_OFF);

//** Test mysql root connection
$finished = false;
$password_queried = false;
do {
	if(@mysqli_connect($conf["mysql"]["host"], $conf["mysql"]["admin_user"], $conf["mysql"]["admin_password"])) {
		$finished = true;
	} else {
		swriteln($inst->lng('Unable to connect to mysql server').' '.mysqli_connect_error());
		if(AUTOINSTALL && $password_queried) {
			// in autoinstall mode the answers cannot change, so retrying would loop forever
			exit(1);
		}
		$conf["mysql"]["admin_password"] = $inst->free_query('MySQL root password', $conf['mysql']['admin_password'],'mysql_root_password');
		$password_queried = true;
	}
} while ($finished == false);
unset($finished, $password_queried);

/*
 *  Prepare the dump of the database
 */
prepareDBDump();

//* initialize the database
$inst->db = new db();
$inst->db->setDBData($conf['mysql']["host"], $conf['mysql']["ispconfig_user"], $conf['mysql']["ispconfig_password"], $conf['mysql']["port"]);
$inst->db->setDBName($conf['mysql']['database']);

//* Check MySQL version
$inst->check_mysql_version();

//* initialize the master DB, if we have a multiserver setup
if($conf['mysql']['master_slave_setup'] == 'y') {
	//** Get MySQL root credentials
	$finished = false;
	do {
		$tmp_mysql_server_host = $inst->free_query('MySQL master server hostname', $conf['mysql']['master_host'],'mysql_master_hostname');
		$tmp_mysql_server_port = $inst->free_query('MySQL master server port', $conf['mysql']['master_port'],'mysql_master_port');
		$tmp_mysql_server_admin_user = $inst->free_query('MySQL master server root username', $conf['mysql']['master_admin_user'],'mysql_master_root_user');
		$tmp_mysql_server_admin_password = $inst->free_query('MySQL master server root password', $conf['mysql']['master_admin_password'],'mysql_master_root_password');
		$tmp_mysql_server_database = $inst->free_query('MySQL master server database name', $conf['mysql']['master_database'],'mysql_master_database');

		//* Initialize the MySQL server connection
		$tmp_link = mysqli_init();
		if(@mysqli_real_connect($tmp_link, $tmp_mysql_server_host, $tmp_mysql_server_admin_user, $tmp_mysql_server_admin_password, $tmp_mysql_server_database, (int)$tmp_mysql_server_port, null, (isset($conf['mysql']['master_client_flags']) ? $conf['mysql']['master_client_flags'] : 0))) {
			mysqli_close($tmp_link);
			$conf['mysql']['master_host'] = $tmp_mysql_server_host;
			$conf['mysql']['master_port'] = $tmp_mysql_server_port;
			$conf['mysql']['master_admin_user'] = $tmp_mysql_server_admin_user;
			$conf['mysql']['master_admin_password'] = $tmp_mysql_server_admin_password;
			$conf['mysql']['master_database'] = $tmp_mysql_server_database;
			$finished = true;
		} else {
			swriteln($inst->lng('Unable to connect to mysql server').' '.mysqli_connect_error());
			if(AUTOINSTALL) {
				// in autoinstall mode the answers cannot change, so retrying would loop forever
				exit(1);
			}
		}
	} while ($finished == false);
	unset($finished);

	// initialize the connection to the master database
	$inst->dbmaster = new db();
	if($inst->dbmaster->linkId) $inst->dbmaster->closeConn();
	$inst->dbmaster->setDBData($conf['mysql']["master_host"], $conf['mysql']["master_admin_user"], $conf['mysql']["master_admin_password"], $conf['mysql']["master_port"]);
	if(isset($conf['mysql']['master_client_flags'])) {
		$inst->dbmaster->setDBClientFlags($conf['mysql']['master_client_flags']);
	}
	$inst->dbmaster->setDBName($conf['mysql']["master_database"]);
} else {
	$inst->dbmaster= new db();
	$inst->dbmaster->setDBData($conf['mysql']["host"], $conf['mysql']["admin_user"], $conf['mysql']["admin_password"], $conf['mysql']["port"]);
	$inst->dbmaster->setDBName($conf['mysql']['database']);
}

/*
 *  Check all tables
*/
checkDbHealth();


/*
 * Check command line mysql login
 */
$cmd = "mysql ".mysql_admin_option()." --default-character-set=".escapeshellarg($conf['mysql']['charset'])." --force -D ".escapeshellarg($conf['mysql']['database'])." -e ". escapeshellarg('SHOW DATABASES');
$retval = 0;
$retout = array();
exec($cmd, $retout, $retval);
if($retval != 0) {
	die("Unable to call mysql command line with credentials from mysql_clientdb.conf\n");
}

/*
 *  dump the new Database and reconfigure the server.ini
 */
updateDbAndIni();

//** read server config from db into $conf['server_config']
$tmp = $inst->db->queryOneRecord("SELECT config FROM ?? WHERE server_id = ?", $conf["mysql"]["database"] . '.server', $conf['server_id']);
$conf['server_config'] = ini_to_array(stripslashes($tmp['config']));
unset($tmp);

/*
 * Reconfigure the permisson if needed
 * (if this is done at client side, only this client is updated.
 * If this is done at server side, all clients are updated.
 */
//if($conf_old['dbmaster_user'] != '' or $conf_old['dbmaster_host'] != '') {
//** Update master database rights
$reconfigure_master_database_rights_answer = $inst->simple_query('Reconfigure Permissions in master database?', array('yes', 'no'), 'no','reconfigure_permissions_in_master_database');

if($reconfigure_master_database_rights_answer == 'yes') {
	$inst->grant_master_database_rights();
}
//}

//** Detect the installed applications
$inst->find_installed_apps();

//* Only the configured web server counts as installed, also when the binary of the other one exists
if($conf['webserver']['server_type'] == 'nginx') {
	$conf['apache']['installed'] = false;
} else {
	$conf['nginx']['installed'] = false;
}

//** Check for current service config state and compare to our results
if ($conf['mysql']['master_slave_setup'] == 'y') $current_svc_config = $inst->dbmaster->queryOneRecord("SELECT mail_server,web_server,dns_server,xmpp_server,firewall_server,vserver_server,db_server FROM ?? WHERE server_id=?", $conf['mysql']['master_database'] . '.server', $conf['server_id']);
else $current_svc_config = $inst->db->queryOneRecord("SELECT mail_server,web_server,dns_server,xmpp_server,firewall_server,vserver_server,db_server FROM ?? WHERE server_id=?", $conf["mysql"]["database"] . '.server', $conf['server_id']);

if(isset($conf['postfix']['installed']) && $conf['postfix']['installed'] == true) {
	$conf['services']['mail'] = check_service_config_state('mail_server', true);
} else {
	$conf['services']['mail'] = check_service_config_state('mail_server', false);
}

if(isset($conf['powerdns']['installed']) && $conf['powerdns']['installed'] == true || isset($conf['bind']['installed']) && $conf['bind']['installed'] == true || isset($conf['mydns']['installed']) && $conf['mydns']['installed'] == true) {
	$conf['services']['dns'] = check_service_config_state('dns_server', true);
} else {
	$conf['services']['dns'] = check_service_config_state('dns_server', false);
}

if(isset($conf['apache']['installed']) && $conf['apache']['installed'] == true || isset($conf['nginx']['installed']) && $conf['nginx']['installed'] == true) {
	$conf['services']['web'] = check_service_config_state('web_server', true);
} else {
	$conf['services']['web'] = check_service_config_state('web_server', false);
}

if(isset($conf['xmpp']['installed']) && $conf['xmpp']['installed'] == true) {
	$conf['services']['xmpp'] = check_service_config_state('xmpp_server', true);
} else {
	$conf['services']['xmpp'] = check_service_config_state('xmpp_server', false);
}

if(isset($conf['ufw']['installed']) && $conf['ufw']['installed'] == true || isset($conf['firewall']['installed']) && $conf['firewall']['installed'] == true) {
	$conf['services']['firewall'] = check_service_config_state('firewall_server', true);
} else {
	$conf['services']['firewall'] = check_service_config_state('firewall_server', false);
}

if(isset($conf['vserver']['installed']) && $conf['vserver']['installed'] == true) {
	$conf['services']['vserver'] = check_service_config_state('vserver_server', true);
} else {
	$conf['services']['vserver'] = check_service_config_state('vserver_server', false);
}

$conf['services']['db'] = check_service_config_state('db_server', true); /* Will always offer as MySQL is of course installed on this host as it's a requirement for ISPC to work... */
unset($current_svc_config);


//** Write new decisions into DB
$service_flags = array();
foreach(array('mail', 'web', 'dns', 'file', 'db', 'vserver', 'proxy', 'firewall', 'xmpp') as $service) {
	$service_flags[] = $service.'_server = '.(int)$conf['services'][$service];
}
$sql = "UPDATE ?? SET ".implode(', ', $service_flags)." WHERE server_id = ?";
if(!$inst->db->query($sql, $conf['mysql']['database'].'.server', $conf['server_id'])) {
	swriteln('WARNING: The service settings of this server could not be saved in the local database.');
}
if($conf['mysql']['master_slave_setup'] == 'y') {
	if(!$inst->dbmaster->query($sql, $conf['mysql']['master_database'].'.server', $conf['server_id'])) {
		swriteln('WARNING: The service settings of this server could not be saved in the master database.');
	}
}

//** Is the ISPConfg Panel installed on this host? This might partially override user's preferences later.
if($conf['apache']['installed'] == true){
	if(!is_file($conf['apache']['vhost_conf_dir'].'/ispconfig.vhost')) $inst->install_ispconfig_interface = false;
}
elseif($conf['nginx']['installed'] == true){
	if(!is_file($conf['nginx']['vhost_conf_dir'].'/ispconfig.vhost')) $inst->install_ispconfig_interface = false;
}
else {
	// If neither webserver is installed then this can't be the server that hosts the ispconfig interface.
	$inst->install_ispconfig_interface = false;
}

//* Remote users are not replicated to a slave without the interface
if($conf['mysql']['master_slave_setup'] == 'y' && $conf['server_id'] != 1 && !$inst->install_ispconfig_interface) {
	$inst->db->query('DELETE FROM ??', $conf['mysql']['database'].'.remote_user');
}

//* Check and install rsync (required for secure backup restoration)
swriteln('Checking for rsync...');
$inst->check_and_install_rsync();

//** Shall the services be reconfigured during update
$reconfigure_services_answer = $inst->simple_query('Reconfigure Services?', array('yes', 'no', 'selected'), 'yes','reconfigure_services');

if($reconfigure_services_answer == 'yes' || $reconfigure_services_answer == 'selected') {

	checkAndRenameCustomTemplates();

	if($conf['services']['mail']) {

		//** Configure postfix
		if($inst->reconfigure_app('Postfix and IMAP/POP3', $reconfigure_services_answer)) {
			swriteln('Configuring Postfix');
			$inst->configure_postfix('dont-create-certs');

			if($conf['dovecot']['installed'] == true) {
				//* Configure dovecot
				swriteln('Configuring Dovecot');
				$inst->configure_dovecot();
			} elseif ($conf['courier']['installed'] == true) {
				//** Configure saslauthd
				swriteln('Configuring SASL');
				$inst->configure_saslauthd();

				//** Configure PAM
				swriteln('Configuring PAM');
				$inst->configure_pam();

				//* Configure courier
				swriteln('Configuring Courier');
				$inst->configure_courier();
			}

		}

		//** Configure mailman
		if($conf['mailman']['installed'] == true && $inst->reconfigure_app('Mailman', $reconfigure_services_answer)) {
			swriteln('Configuring Mailman');
			$inst->configure_mailman('update');
		}

		//** Configure Spamasassin
		if($inst->reconfigure_app('Spamassassin', $reconfigure_services_answer)) {
			swriteln('Configuring Spamassassin');
			$inst->configure_spamassassin();
		}

		//** Configure Amavis
		if($conf['amavis']['installed'] == true && $inst->reconfigure_app('Amavisd', $reconfigure_services_answer)) {
			swriteln('Configuring Amavisd');
			$inst->configure_amavis();
		}

		//** Configure Rspamd
		if($conf['rspamd']['installed'] == true && $inst->reconfigure_app('Rspamd', $reconfigure_services_answer)) {
			swriteln('Configuring Rspamd');
			$inst->configure_rspamd();
		}

		//** Configure Getmail
		if ($inst->reconfigure_app('Getmail', $reconfigure_services_answer)) {
			swriteln('Configuring Getmail');
			$inst->configure_getmail();
		}
	}

	if($conf['services']['dns'] && $inst->reconfigure_app('DNS', $reconfigure_services_answer)) {
		//* Configure DNS
		if($conf['powerdns']['installed'] == true) {
			swriteln('Configuring PowerDNS');
			$inst->configure_powerdns();
		} elseif($conf['bind']['installed'] == true) {
			swriteln('Configuring BIND');
			$inst->configure_bind();
			if(!is_installed('haveged')) {
				swriteln("[INFO] haveged not detected - DNSSEC can fail");
			}
		} else {
			swriteln('Configuring MyDNS');
			$inst->configure_mydns();
		}
	}

	if($conf['services']['web'] || $inst->install_ispconfig_interface) {

		if($conf['pureftpd']['installed'] == true && $inst->reconfigure_app('Pureftpd', $reconfigure_services_answer)) {
			//** Configure Pureftpd
			swriteln('Configuring Pureftpd');
			$inst->configure_pureftpd();
		}

		if($inst->reconfigure_app('Web-Server', $reconfigure_services_answer)) {
			if($conf['webserver']['server_type'] == 'apache'){
				//** Configure Apache
				swriteln('Configuring Apache');
				$inst->configure_apache();

				//** Configure vlogger
				swriteln('Configuring vlogger');
				$inst->configure_vlogger();
			} else {
				//** Configure nginx
				swriteln('Configuring nginx');
				$inst->configure_nginx();
			}

			if ($conf['server_config']['web']['apps_vhost_enabled'] == 'y') {
				//** Configure apps vhost
				swriteln('Configuring Apps vhost');
				$inst->configure_apps_vhost();
			} else swriteln('Skipping config of Apps vhost');
		}

		//* Configure Jailkit
		if($inst->reconfigure_app('Jailkit', $reconfigure_services_answer)) {
			swriteln('Configuring Jailkit');
			$inst->configure_jailkit();
		}

	}

	if($conf['services']['xmpp'] && $inst->reconfigure_app('XMPP', $reconfigure_services_answer)) {
		//** Configure Metronome XMPP
	$inst->configure_xmpp('dont-create-certs');
	}

  // Configure AppArmor
  if($conf['apparmor']['installed']){
    swriteln('Configuring AppArmor');
    $inst->configure_apparmor();
  }

	if($conf['services']['firewall'] && $inst->reconfigure_app('Firewall', $reconfigure_services_answer)) {
		if(isset($conf['ufw']['installed']) && $conf['ufw']['installed'] == true) {
			//* Configure Ubuntu Firewall
			$conf['services']['firewall'] = true;
			swriteln('Configuring Ubuntu Firewall');
			$inst->configure_ufw_firewall();
		} else {
			//* Configure Bastille Firewall
			swriteln('Configuring Bastille Firewall');
			$inst->configure_bastille_firewall();
		}
	}

	//* Configure DBServer
	swriteln('Configuring Database');
	$inst->configure_dbserver();

	/*
	if($conf['squid']['installed'] == true) {
		swriteln('Configuring Squid');
		$inst->configure_squid();
	} else if($conf['nginx']['installed'] == true) {
		swriteln('Configuring Nginx');
		$inst->configure_nginx();
	}
	*/
}

//** Configure ISPConfig
swriteln('Updating ISPConfig');

$issue_asked = false;
$issue_tried = false;
// create acme vhost
if($conf['nginx']['installed'] == true) {
	$inst->make_acme_vhost('nginx'); // we need this config file but we don't want nginx to be restarted at this point
}
if($conf['apache']['installed'] == true) {
	$inst->make_acme_vhost('apache'); // we need this config file but we don't want apache to be restarted at this point
}

if ($inst->install_ispconfig_interface) {
	//** Customise the port ISPConfig runs on
	$ispconfig_port_number = get_ispconfig_port_number();
	if(isset($autoupdate['ispconfig_port']) && $autoupdate['ispconfig_port'] == 'default') $autoupdate['ispconfig_port'] = $ispconfig_port_number;
	if($conf['webserver']['server_type'] == 'nginx'){
		$conf['nginx']['vhost_port'] = $inst->free_query('ISPConfig Port', $ispconfig_port_number,'ispconfig_port');
	} else {
		$conf['apache']['vhost_port'] = $inst->free_query('ISPConfig Port', $ispconfig_port_number,'ispconfig_port');
	}


	// $ispconfig_ssl_default = (is_ispconfig_ssl_enabled() == true)?'y':'n';
	if(strtolower($inst->simple_query('Create new ISPConfig SSL certificate', array('yes', 'no'), 'no','create_new_ispconfig_ssl_cert')) == 'yes') {
		$inst->make_ispconfig_ssl_cert();
		$issue_tried = true;
	}
	$issue_asked = true;
}

// Create SSL certs for non-webserver(s)?
if(!$issue_asked) {
    if(!file_exists('/usr/local/ispconfig/interface/ssl/ispserver.crt')) {
        if(!$issue_tried && strtolower($inst->simple_query('Do you want to create SSL certs for your server?', array('y', 'n'), 'y','create_ssl_server_certs')) == 'y') {
            $inst->make_ispconfig_ssl_cert();
	    }
    } else {
        swriteln('Certificate exists. Not creating a new one.');
    }
}

// update acme.sh if installed
$inst->update_acme();

$inst->install_ispconfig();
$inst->disable_unused_remote_api();

if($conf['services']['db']) {
	$inst->migrate_db_grant_names();
	$inst->migrate_pg_database_access();
}

// Cleanup
$inst->cleanup_ispconfig();

//** Configure Crontab
$update_crontab_answer = $inst->simple_query('Reconfigure Crontab?', array('yes', 'no'), 'yes','reconfigure_crontab');
if($update_crontab_answer == 'yes') {
	swriteln('Updating Crontab');
	$inst->install_crontab();
}

//** Restart services:
if($reconfigure_services_answer == 'yes') {
	swriteln('Restarting services ...');
	if($conf['mysql']['installed'] == true && isset($conf['mysql']['init_script']) && $conf['mysql']['init_script'] != '') system($inst->getinitcommand($conf['mysql']['init_script'], 'restart').' >/dev/null 2>&1');
	if($conf['services']['mail']) {
		if($conf['postfix']['installed'] == true && isset($conf['postfix']['init_script']) && $conf['postfix']['init_script'] != '') system($inst->getinitcommand($conf['postfix']['init_script'], 'restart'));
		if($conf['saslauthd']['installed'] == true && isset($conf['saslauthd']['init_script']) && $conf['saslauthd']['init_script'] != '') system($inst->getinitcommand($conf['saslauthd']['init_script'], 'restart'));
		if($conf['amavis']['installed'] == true && isset($conf['amavis']['init_script']) && $conf['amavis']['init_script'] != '') system($inst->getinitcommand($conf['amavis']['init_script'], 'restart'));
		if($conf['rspamd']['installed'] == true && isset($conf['rspamd']['init_script']) && $conf['rspamd']['init_script'] != '') system($inst->getinitcommand($conf['rspamd']['init_script'], 'restart'));
		if($conf['clamav']['installed'] == true && isset($conf['clamav']['init_script']) && $conf['clamav']['init_script'] != '' && $conf['amavis']['installed'] == true) system($inst->getinitcommand($conf['clamav']['init_script'], 'restart'));
		if($conf['courier']['installed'] == true){
			if($conf['courier']['courier-authdaemon'] != '') system($inst->getinitcommand($conf['courier']['courier-authdaemon'], 'restart'));
			if($conf['courier']['courier-imap'] != '') system($inst->getinitcommand($conf['courier']['courier-imap'], 'restart'));
			if($conf['courier']['courier-imap-ssl'] != '') system($inst->getinitcommand($conf['courier']['courier-imap-ssl'], 'restart'));
			if($conf['courier']['courier-pop'] != '') system($inst->getinitcommand($conf['courier']['courier-pop'], 'restart'));
			if($conf['courier']['courier-pop-ssl'] != '') system($inst->getinitcommand($conf['courier']['courier-pop-ssl'], 'restart'));
		}
		if($conf['dovecot']['installed'] == true && isset($conf['dovecot']['init_script']) && $conf['dovecot']['init_script'] != '') system($inst->getinitcommand($conf['dovecot']['init_script'], 'restart'));
		if($conf['mailman']['installed'] == true && isset($conf['mailman']['init_script']) && $conf['mailman']['init_script'] != '') system('nohup '.$inst->getinitcommand($conf['mailman']['init_script'], 'restart').' >/dev/null 2>&1 &');
	}
	if($conf['services']['web'] || $inst->install_ispconfig_interface) {
		if($conf['webserver']['server_type'] == 'apache') {
			// If user has configured a custom Apache init script, use that. Otherwise use the default auto-detected init script
			if(!empty($conf['server_config']['web']['apache_init_script'])) {
				system($inst->getinitcommand($conf['server_config']['web']['apache_init_script'], 'restart'));
			} elseif(!empty($conf['apache']['init_script'])) {
				system($inst->getinitcommand($conf['apache']['init_script'], 'restart'));
			}
		}
		//* Reload is enough for nginx
		if($conf['webserver']['server_type'] == 'nginx'){
			if($conf['nginx']['php_fpm_init_script'] != '') system($inst->getinitcommand($conf['nginx']['php_fpm_init_script'], 'reload'));
			if(isset($conf['nginx']['init_script']) && $conf['nginx']['init_script'] != '') system($inst->getinitcommand($conf['nginx']['init_script'], 'reload'));
		}
		if($conf['pureftpd']['installed'] == true && isset($conf['pureftpd']['init_script']) && $conf['pureftpd']['init_script'] != '') system($inst->getinitcommand($conf['pureftpd']['init_script'], 'restart'));
	}
	if($conf['services']['dns']) {
		if($conf['mydns']['installed'] == true && isset($conf['mydns']['init_script']) && $conf['mydns']['init_script'] != '') system($inst->getinitcommand($conf['mydns']['init_script'], 'restart').' > /dev/null 2>&1');
		if($conf['powerdns']['installed'] == true && isset($conf['powerdns']['init_script']) && $conf['powerdns']['init_script'] != '') system($inst->getinitcommand($conf['powerdns']['init_script'], 'restart').' > /dev/null 2>&1');
		if($conf['bind']['installed'] == true && isset($conf['bind']['init_script']) && $conf['bind']['init_script'] != '') system($inst->getinitcommand($conf['bind']['init_script'], 'restart').' > /dev/null 2>&1');
	}

    if($conf['services']['xmpp']) {
        if($conf['xmpp']['installed'] == true && isset($conf['xmpp']['init_script']) && $conf['xmpp']['init_script'] != '') system($inst->getinitcommand($conf['xmpp']['init_script'], 'restart').' > /dev/null 2>&1');
    }

	if($conf['services']['proxy']) {
		// if($conf['squid']['installed'] == true && isset($conf['squid']['init_script']) && $conf['squid']['init_script'] != '' && is_executable($conf['init_scripts'].'/'.$conf['squid']['init_script']))     system($conf['init_scripts'].'/'.$conf['squid']['init_script'].' restart > /dev/null 2>&1');
		if($conf['nginx']['installed'] == true && isset($conf['nginx']['init_script']) && $conf['nginx']['init_script'] != '') system($inst->getinitcommand($conf['nginx']['init_script'], 'restart').' > /dev/null 2>&1');
	}

	if($conf['services']['firewall']) {
		if(isset($conf['ufw']['installed']) && $conf['ufw']['installed'] == true && isset($conf['ufw']['init_script']) && $conf['ufw']['init_script'] != '' && is_executable($conf['init_scripts'].'/'.$conf['ufw']['init_script']))     system($conf['init_scripts'].'/'.$conf['ufw']['init_script'].' restart > /dev/null 2>&1');
	}
}

//* Set default servers
setDefaultServers();

$inst->create_mount_script();

//* Create md5 filelist
$md5_filename = '/usr/local/ispconfig/security/data/file_checksums_'.date('Y-m-d_H-i').'.md5';
exec('find /usr/local/ispconfig -type f -print0 | xargs -0 md5sum > '.$md5_filename . ' 2>/dev/null');
chmod($md5_filename,0600);

// TODO: In a future update, stop the update script when running courier
if ($conf['courier']['installed'] == true) {
	swriteln('WARNING: You are running Courier. We are removing support for Courier from ISPConfig. Migrate your system to Dovecot as soon as possible. See https://www.howtoforge.com/community/threads/migrate-from-courier-to-dovecot-on-your-ispconfig-managed-mailserver.88523/ for more information.');
}

//* Panel and remote users with a password hash that is not encrypted with crypt can not log in
if($conf['mysql']['master_slave_setup'] != 'y') {
	$tmp = $inst->db->queryAllRecords("SELECT username AS name FROM sys_user WHERE passwort NOT LIKE '\$%' AND passwort != '' UNION SELECT remote_username AS name FROM remote_user WHERE remote_password NOT LIKE '\$%' AND remote_password != ''");
	if(is_array($tmp) && !empty($tmp)) {
		swriteln('WARNING: These panel or remote users have an old password hash and can not log in until they get a new password (panel users: ispc user set-password <username>): '.implode(', ', array_column($tmp, 'name')));
	}
	unset($tmp);
}

//* Subdomains, alias domains, shell and FTP users of websites that no longer exist
if($conf['mysql']['master_slave_setup'] != 'y') {
	$tmp = $inst->db->queryAllRecords("SELECT CONCAT('domain ', c.domain) AS name FROM web_domain c LEFT JOIN web_domain p ON p.domain_id = c.parent_domain_id WHERE c.type != 'vhost' AND p.domain_id IS NULL
		UNION SELECT CONCAT('shell user ', s.username) FROM shell_user s LEFT JOIN web_domain p ON p.domain_id = s.parent_domain_id WHERE p.domain_id IS NULL
		UNION SELECT CONCAT('FTP user ', f.username) FROM ftp_user f LEFT JOIN web_domain p ON p.domain_id = f.parent_domain_id WHERE p.domain_id IS NULL");
	if(is_array($tmp) && !empty($tmp)) {
		swriteln('WARNING: These records belong to a website that no longer exists, delete them in the panel under Sites: '.implode(', ', array_column($tmp, 'name')));
	}
	unset($tmp);
}

//* Websites whose PHP-FPM pool listens on a TCP port instead of a socket
if($conf['mysql']['master_slave_setup'] != 'y') {
	$tmp = $inst->db->queryAllRecords("SELECT CONCAT(d.domain, ' (', IFNULL(s.server_name, d.server_id), ')') AS domain FROM web_domain d LEFT JOIN server s ON s.server_id = d.server_id WHERE d.type IN ('vhost', 'vhostsubdomain', 'vhostalias') AND d.php IN ('php-fpm', 'hhvm') AND d.php_fpm_use_socket = 'n'");
	if(is_array($tmp) && !empty($tmp)) {
		swriteln('WARNING: These websites run PHP-FPM on a TCP port that other system users on this server can connect to, enable "Use Socket For PHP-FPM" on their Options tab: '.implode(', ', array_column($tmp, 'domain')));
	}
	unset($tmp);
}

//* Inactive shell users of this server get an expired account, so no login works (the server does this on every change since 3.3.3)
$tmp = $inst->dbmaster->queryAllRecords("SELECT username FROM shell_user WHERE server_id = ? AND active != 'y'", $conf['server_id']);
if(is_array($tmp)) {
	foreach($tmp as $rec) exec('usermod -e 1 -- ' . escapeshellarg($rec['username']) . ' 2>/dev/null');
}
unset($tmp);

//* The relay host password map and its indexed copies are readable by root only
if(isset($conf['postfix']['installed']) && $conf['postfix']['installed'] == true && !empty($conf['postfix']['config_dir'])) {
	foreach(glob($conf['postfix']['config_dir'].'/sasl_passwd*') as $tmp) if(!is_link($tmp)) chmod($tmp, 0600);
	unset($tmp);
}

//* Protected folders of this server that belong to root are given to the website user (since 3.3.3 the server writes their files as the website user)
$tmp = $inst->dbmaster->queryAllRecords("SELECT f.path, d.document_root, d.type, d.web_folder, d.system_user, d.system_group FROM web_folder f JOIN web_domain d ON d.domain_id = f.parent_domain_id WHERE f.server_id = ?", $conf['server_id']);
if(is_array($tmp)) {
	$cwd = getcwd();
	foreach($tmp as $rec) {
		$web_folder = ($rec['type'] == 'vhostsubdomain' || $rec['type'] == 'vhostalias') ? $rec['web_folder'] : 'web';
		$folder_path = rtrim($rec['document_root'].'/'.$web_folder.'/'.trim($rec['path'], '/'), '/');
		//* only a folder whose real path is this path
		if($rec['system_user'] == '' || !@chdir($folder_path) || getcwd() !== $folder_path) continue;
		if(fileowner('.') === 0) {
			chown('.', $rec['system_user']);
			chgrp('.', $rec['system_group']);
		}
	}
	chdir($cwd);
}
unset($tmp);

$inst->vlogger_perl_module_warning();

//* nginx servers were installed without the file service before
if($conf['webserver']['server_type'] == 'nginx' && $conf['pureftpd']['installed'] == true && !$conf['services']['file']) {
	$inst->warning('Pure-FTPd is installed, but the file service of this server is off. Enable it under System > Server Services if this server shall provide FTP.');
}

echo "Update finished.\n";

?>
