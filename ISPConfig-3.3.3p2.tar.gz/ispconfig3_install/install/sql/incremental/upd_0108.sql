-- Log out all panel users once
DELETE FROM `sys_session`;

-- Grant the new datalog function permission to remote users with the server functions
UPDATE `remote_user` SET `remote_functions` = CONCAT(`remote_functions`, ';sys_datalog_get')
WHERE CONCAT(',', REPLACE(`remote_functions`, ';', ','), ',') LIKE '%,server_get,%'
AND CONCAT(',', REPLACE(`remote_functions`, ';', ','), ',') REGEXP ',(server_config_set|get_function_list|client_templates_get_all|server_get_serverid_by_ip|server_ip_get|server_ip_add|server_ip_update|server_ip_delete|system_config_set|system_config_get|config_value_get|config_value_add|config_value_update|config_value_replace|config_value_delete),'
AND CONCAT(',', REPLACE(`remote_functions`, ';', ','), ',') NOT LIKE '%,sys_datalog_get,%';

-- openvz_vm: new installs created the iptables column as iptabless
ALTER TABLE `openvz_vm` CHANGE `iptabless` `iptables` TEXT DEFAULT NULL;

-- sys_remoteaction: new installs created action_type with 20 characters, too short for extension_license_update
ALTER TABLE `sys_remoteaction` CHANGE `action_type` `action_type` varchar(64) NOT NULL DEFAULT '';

-- utf8mb4: convert the tables that are still utf8/utf8mb3 (upd_0103 stopped at the first table that failed);
-- old MyISAM tables become InnoDB (key length), zero dates are kept, a table that fails is reported and skipped.
-- A database that is already utf8mb4 keeps its collation (fresh installs use the server default)
SET @old_sql_mode = @@SESSION.sql_mode;
SET SESSION sql_mode = 'NO_ENGINE_SUBSTITUTION';
SET @ispc_collation = IF(@@collation_database LIKE 'utf8mb4%', @@collation_database, 'utf8mb4_unicode_ci');
SET @sql_stmt = CONCAT('ALTER DATABASE CHARACTER SET utf8mb4 COLLATE ', @ispc_collation);
PREPARE stmt FROM @sql_stmt;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
DROP PROCEDURE IF EXISTS ispc_convert_utf8mb4;
DELIMITER $$
CREATE PROCEDURE ispc_convert_utf8mb4()
BEGIN
  DECLARE done INT DEFAULT FALSE;
  DECLARE tbl VARCHAR(255);
  DECLARE cur CURSOR FOR
    SELECT TABLE_NAME
    FROM information_schema.TABLES
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_TYPE = 'BASE TABLE'
      AND TABLE_COLLATION NOT LIKE 'utf8mb4%';
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
  OPEN cur;
  read_loop: LOOP
    FETCH cur INTO tbl;
    IF done THEN
      LEAVE read_loop;
    END IF;
    SET @sql_stmt = CONCAT('ALTER TABLE `', tbl, '` ENGINE=InnoDB, ROW_FORMAT=DYNAMIC, CONVERT TO CHARACTER SET utf8mb4 COLLATE ', @ispc_collation);
    BEGIN
      DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
      BEGIN
        GET DIAGNOSTICS CONDITION 1 @sql_error = MESSAGE_TEXT;
        SELECT CONCAT('utf8mb4 conversion failed for table ', tbl, ': ', @sql_error) AS warning;
      END;
      PREPARE stmt FROM @sql_stmt;
      EXECUTE stmt;
      DEALLOCATE PREPARE stmt;
    END;
  END LOOP;
  CLOSE cur;
END$$
DELIMITER ;
CALL ispc_convert_utf8mb4();
DROP PROCEDURE ispc_convert_utf8mb4;
SET SESSION sql_mode = @old_sql_mode;
