<?php

if(!defined('INSTALLER_RUN')) die('Patch update file access violation.');


// Reset the mode of the website tmp directories that cron job changes set to 0777
// and the owner and mode of the home base directory of the websites,
// shell history files only readable for the shell user, obsolete files removed

class upd_0108 extends installer_patch_update {

	public function onAfterSQL() {
		global $inst, $conf;

		$sql = "SELECT DISTINCT document_root FROM web_domain WHERE (type = 'vhost' or type = 'vhostsubdomain' or type = 'vhostalias') AND server_id = ? AND document_root != ''";
		$records = $inst->db->queryAllRecords($sql, $conf['server_id']);
		foreach($records as $rec) {
			$tmp_dir = $rec['document_root'].'/tmp';
			if(is_dir($tmp_dir) && !is_link($tmp_dir) && (fileperms($tmp_dir) & 07777) == 0777) {
				chmod($tmp_dir, 0770);
				ilog('Set the permissions of '.$tmp_dir.' to 0770');
			}
			$home_dir = $rec['document_root'].'/home';
			if(is_dir($home_dir) && !is_link($home_dir) && (fileowner($home_dir) != 0 || filegroup($home_dir) != 0 || (fileperms($home_dir) & 07777) != 0755)) {
				chown($home_dir, 'root');
				chgrp($home_dir, 'root');
				chmod($home_dir, 0755);
				ilog('Set the owner of '.$home_dir.' to root:root and the permissions to 0755');
			}
		}

		//* the chmod runs as the shell user, the home directory belongs to the website user
		$records = $inst->db->queryAllRecords("SELECT dir, username FROM shell_user WHERE server_id = ? AND dir != '' AND username != ''", $conf['server_id']);
		foreach($records as $rec) {
			$history = $rec['dir'].'/home/'.$rec['username'].'/.bash_history';
			if(is_file($history) && !is_link($history) && (fileperms($history) & 07777) == 0750) {
				exec('/sbin/runuser -u '.escapeshellarg($rec['username']).' -- chmod 0600 '.escapeshellarg($history).' 2>/dev/null', $out, $ret);
				if($ret == 0) ilog('Set the permissions of '.$history.' to 0600');
				else ilog('Could not set the permissions of '.$history.' to 0600');
			}
		}

		// delete all the files that were deleted on previous updates
		$delete = array(
			'interface/web/mail/autoconfig/autodiscover.php',
			'interface/web/mail/autoconfig/index.php',
			'interface/web/monitor/datalog_del.php',
			'interface/web/mail/form/spamfilter_config.tform.php',
			'interface/web/mail/lib/lang/ar_spamfilter_config.lng',
			'interface/web/mail/lib/lang/ar_spamfilter_config_list.lng',
			'interface/web/mail/lib/lang/bg_spamfilter_config.lng',
			'interface/web/mail/lib/lang/bg_spamfilter_config_list.lng',
			'interface/web/mail/lib/lang/br_spamfilter_config.lng',
			'interface/web/mail/lib/lang/br_spamfilter_config_list.lng',
			'interface/web/mail/lib/lang/ca_spamfilter_config.lng',
			'interface/web/mail/lib/lang/ca_spamfilter_config_list.lng',
			'interface/web/mail/lib/lang/cn_spamfilter_config.lng',
			'interface/web/mail/lib/lang/cn_spamfilter_config_list.lng',
			'interface/web/mail/lib/lang/cz_spamfilter_config.lng',
			'interface/web/mail/lib/lang/cz_spamfilter_config_list.lng',
			'interface/web/mail/lib/lang/de_spamfilter_config.lng',
			'interface/web/mail/lib/lang/de_spamfilter_config_list.lng',
			'interface/web/mail/lib/lang/dk_spamfilter_config.lng',
			'interface/web/mail/lib/lang/dk_spamfilter_config_list.lng',
			'interface/web/mail/lib/lang/el_spamfilter_config.lng',
			'interface/web/mail/lib/lang/el_spamfilter_config_list.lng',
			'interface/web/mail/lib/lang/en_spamfilter_config.lng',
			'interface/web/mail/lib/lang/en_spamfilter_config_list.lng',
			'interface/web/mail/lib/lang/es_spamfilter_config.lng',
			'interface/web/mail/lib/lang/es_spamfilter_config_list.lng',
			'interface/web/mail/lib/lang/fi_spamfilter_config.lng',
			'interface/web/mail/lib/lang/fi_spamfilter_config_list.lng',
			'interface/web/mail/lib/lang/fr_spamfilter_config.lng',
			'interface/web/mail/lib/lang/fr_spamfilter_config_list.lng',
			'interface/web/mail/lib/lang/hr_spamfilter_config.lng',
			'interface/web/mail/lib/lang/hr_spamfilter_config_list.lng',
			'interface/web/mail/lib/lang/hu_spamfilter_config.lng',
			'interface/web/mail/lib/lang/hu_spamfilter_config_list.lng',
			'interface/web/mail/lib/lang/id_spamfilter_config.lng',
			'interface/web/mail/lib/lang/id_spamfilter_config_list.lng',
			'interface/web/mail/lib/lang/it_spamfilter_config.lng',
			'interface/web/mail/lib/lang/it_spamfilter_config_list.lng',
			'interface/web/mail/lib/lang/ja_spamfilter_config.lng',
			'interface/web/mail/lib/lang/ja_spamfilter_config_list.lng',
			'interface/web/mail/lib/lang/jp_spamfilter_config.lng',
			'interface/web/mail/lib/lang/jp_spamfilter_config_list.lng',
			'interface/web/mail/lib/lang/nl_spamfilter_config.lng',
			'interface/web/mail/lib/lang/nl_spamfilter_config_list.lng',
			'interface/web/mail/lib/lang/pl_spamfilter_config.lng',
			'interface/web/mail/lib/lang/pl_spamfilter_config_list.lng',
			'interface/web/mail/lib/lang/pt_spamfilter_config.lng',
			'interface/web/mail/lib/lang/pt_spamfilter_config_list.lng',
			'interface/web/mail/lib/lang/ro_spamfilter_config.lng',
			'interface/web/mail/lib/lang/ro_spamfilter_config_list.lng',
			'interface/web/mail/lib/lang/ru_spamfilter_config.lng',
			'interface/web/mail/lib/lang/ru_spamfilter_config_list.lng',
			'interface/web/mail/lib/lang/se_spamfilter_config.lng',
			'interface/web/mail/lib/lang/se_spamfilter_config_list.lng',
			'interface/web/mail/lib/lang/sk_spamfilter_config.lng',
			'interface/web/mail/lib/lang/sk_spamfilter_config_list.lng',
			'interface/web/mail/lib/lang/tr_spamfilter_config.lng',
			'interface/web/mail/lib/lang/tr_spamfilter_config_list.lng',
			'interface/web/mail/list/spamfilter_config.list.php',
			'interface/web/mail/spamfilter_config_del.php',
			'interface/web/mail/spamfilter_config_edit.php',
			'interface/web/mail/spamfilter_config_list.php',
			'interface/web/mail/templates/spamfilter_config_getmail_edit.htm',
			'interface/web/mail/templates/spamfilter_config_list.htm',
			'interface/web/mail/templates/spamfilter_config_mail_edit.htm',
			'interface/web/mail/templates/spamfilter_config_server_edit.htm',
			'interface/web/mail/mail_spamfilter_del.php',
			'interface/web/mail/mail_spamfilter_edit.php',
			'interface/web/mail/mail_spamfilter_list.php',
			'interface/web/mail/form/mail_spamfilter.tform.php',
			'interface/web/mail/list/mail_spamfilter.list.php',
			'interface/web/mail/lib/lang/ar_mail_spamfilter.lng',
			'interface/web/mail/lib/lang/ar_mail_spamfilter_list.lng',
			'interface/web/mail/lib/lang/bg_mail_spamfilter.lng',
			'interface/web/mail/lib/lang/bg_mail_spamfilter_list.lng',
			'interface/web/mail/lib/lang/br_mail_spamfilter.lng',
			'interface/web/mail/lib/lang/br_mail_spamfilter_list.lng',
			'interface/web/mail/lib/lang/ca_mail_spamfilter.lng',
			'interface/web/mail/lib/lang/ca_mail_spamfilter_list.lng',
			'interface/web/mail/lib/lang/cn_mail_spamfilter.lng',
			'interface/web/mail/lib/lang/cn_mail_spamfilter_list.lng',
			'interface/web/mail/lib/lang/cz_mail_spamfilter.lng',
			'interface/web/mail/lib/lang/cz_mail_spamfilter_list.lng',
			'interface/web/mail/lib/lang/de_mail_spamfilter.lng',
			'interface/web/mail/lib/lang/de_mail_spamfilter_list.lng',
			'interface/web/mail/lib/lang/dk_mail_spamfilter.lng',
			'interface/web/mail/lib/lang/dk_mail_spamfilter_list.lng',
			'interface/web/mail/lib/lang/el_mail_spamfilter.lng',
			'interface/web/mail/lib/lang/el_mail_spamfilter_list.lng',
			'interface/web/mail/lib/lang/en_mail_spamfilter.lng',
			'interface/web/mail/lib/lang/en_mail_spamfilter_list.lng',
			'interface/web/mail/lib/lang/es_mail_spamfilter.lng',
			'interface/web/mail/lib/lang/es_mail_spamfilter_list.lng',
			'interface/web/mail/lib/lang/fi_mail_spamfilter.lng',
			'interface/web/mail/lib/lang/fi_mail_spamfilter_list.lng',
			'interface/web/mail/lib/lang/fr_mail_spamfilter.lng',
			'interface/web/mail/lib/lang/fr_mail_spamfilter_list.lng',
			'interface/web/mail/lib/lang/hr_mail_spamfilter.lng',
			'interface/web/mail/lib/lang/hr_mail_spamfilter_list.lng',
			'interface/web/mail/lib/lang/hu_mail_spamfilter.lng',
			'interface/web/mail/lib/lang/hu_mail_spamfilter_list.lng',
			'interface/web/mail/lib/lang/id_mail_spamfilter.lng',
			'interface/web/mail/lib/lang/id_mail_spamfilter_list.lng',
			'interface/web/mail/lib/lang/it_mail_spamfilter.lng',
			'interface/web/mail/lib/lang/it_mail_spamfilter_list.lng',
			'interface/web/mail/lib/lang/ja_mail_spamfilter.lng',
			'interface/web/mail/lib/lang/ja_mail_spamfilter_list.lng',
			'interface/web/mail/lib/lang/jp_mail_spamfilter.lng',
			'interface/web/mail/lib/lang/jp_mail_spamfilter_list.lng',
			'interface/web/mail/lib/lang/nl_mail_spamfilter.lng',
			'interface/web/mail/lib/lang/nl_mail_spamfilter_list.lng',
			'interface/web/mail/lib/lang/pl_mail_spamfilter.lng',
			'interface/web/mail/lib/lang/pl_mail_spamfilter_list.lng',
			'interface/web/mail/lib/lang/pt_mail_spamfilter.lng',
			'interface/web/mail/lib/lang/pt_mail_spamfilter_list.lng',
			'interface/web/mail/lib/lang/ro_mail_spamfilter.lng',
			'interface/web/mail/lib/lang/ro_mail_spamfilter_list.lng',
			'interface/web/mail/lib/lang/ru_mail_spamfilter.lng',
			'interface/web/mail/lib/lang/ru_mail_spamfilter_list.lng',
			'interface/web/mail/lib/lang/se_mail_spamfilter.lng',
			'interface/web/mail/lib/lang/se_mail_spamfilter_list.lng',
			'interface/web/mail/lib/lang/sk_mail_spamfilter.lng',
			'interface/web/mail/lib/lang/sk_mail_spamfilter_list.lng',
			'interface/web/mail/lib/lang/tr_mail_spamfilter.lng',
			'interface/web/mail/lib/lang/tr_mail_spamfilter_list.lng',
			'interface/web/admin/form/dbsync.tform.php',
			'interface/web/tools/dns_import_tupa.php',
			'interface/web/tools/templates/dns_import_tupa.htm',
			'server/lib/classes/cron.d/100-monitor_mongodb.inc.php~',
			'server/cron_daily.php',
			'server/cron_daily.sh',
			'server/lib/classes/mod_mail_base.inc.php',
			'server/scripts/create_jailkit_chroot.sh',
			'server/scripts/create_jailkit_programs.sh',
			'server/scripts/create_jailkit_user.sh',
			'server/conf/nginx_reverse_proxy_plugin.vhost.conf.master',
			'interface/web/admin/lib/lang/it_software_package.lng',
			'interface/web/admin/lib/lang/it_software_package_install.lng',
			'interface/web/admin/lib/lang/it_software_package_list.lng',
			'interface/web/admin/lib/lang/it_software_repo.lng',
			'interface/web/admin/lib/lang/it_software_repo_list.lng',
			'interface/web/admin/lib/lang/it_software_update_list.lng',
			'interface/web/admin/form/iptables.tform.php',
			'interface/web/admin/iptables_del.php',
			'interface/web/admin/iptables_edit.php',
			'interface/web/admin/iptables_list.php',
			'interface/web/admin/lib/lang/ar_iptables.lng',
			'interface/web/admin/lib/lang/ar_iptables_list.lng',
			'interface/web/admin/lib/lang/bg_iptables.lng',
			'interface/web/admin/lib/lang/bg_iptables_list.lng',
			'interface/web/admin/lib/lang/br_iptables.lng',
			'interface/web/admin/lib/lang/br_iptables_list.lng',
			'interface/web/admin/lib/lang/ca_iptables.lng',
			'interface/web/admin/lib/lang/ca_iptables_list.lng',
			'interface/web/admin/lib/lang/cn_iptables.lng',
			'interface/web/admin/lib/lang/cn_iptables_list.lng',
			'interface/web/admin/lib/lang/cz_iptables.lng',
			'interface/web/admin/lib/lang/cz_iptables_list.lng',
			'interface/web/admin/lib/lang/de_iptables.lng',
			'interface/web/admin/lib/lang/de_iptables_list.lng',
			'interface/web/admin/lib/lang/dk_iptables.lng',
			'interface/web/admin/lib/lang/dk_iptables_list.lng',
			'interface/web/admin/lib/lang/el_iptables.lng',
			'interface/web/admin/lib/lang/el_iptables_list.lng',
			'interface/web/admin/lib/lang/en_iptables.lng',
			'interface/web/admin/lib/lang/en_iptables_list.lng',
			'interface/web/admin/lib/lang/es_iptables.lng',
			'interface/web/admin/lib/lang/es_iptables_list.lng',
			'interface/web/admin/lib/lang/fi_iptables.lng',
			'interface/web/admin/lib/lang/fi_iptables_list.lng',
			'interface/web/admin/lib/lang/fr_iptables.lng',
			'interface/web/admin/lib/lang/fr_iptables_list.lng',
			'interface/web/admin/lib/lang/hr_iptables.lng',
			'interface/web/admin/lib/lang/hr_iptables_list.lng',
			'interface/web/admin/lib/lang/hu_iptables.lng',
			'interface/web/admin/lib/lang/hu_iptables_list.lng',
			'interface/web/admin/lib/lang/id_iptables.lng',
			'interface/web/admin/lib/lang/id_iptables_list.lng',
			'interface/web/admin/lib/lang/it_iptables.lng',
			'interface/web/admin/lib/lang/it_iptables_list.lng',
			'interface/web/admin/lib/lang/ja_iptables.lng',
			'interface/web/admin/lib/lang/ja_iptables_list.lng',
			'interface/web/admin/lib/lang/jp_iptables.lng',
			'interface/web/admin/lib/lang/jp_iptables_list.lng',
			'interface/web/admin/lib/lang/nl_iptables.lng',
			'interface/web/admin/lib/lang/nl_iptables_list.lng',
			'interface/web/admin/lib/lang/pl_iptables.lng',
			'interface/web/admin/lib/lang/pl_iptables_list.lng',
			'interface/web/admin/lib/lang/pt_iptables.lng',
			'interface/web/admin/lib/lang/pt_iptables_list.lng',
			'interface/web/admin/lib/lang/ro_iptables.lng',
			'interface/web/admin/lib/lang/ro_iptables_list.lng',
			'interface/web/admin/lib/lang/ru_iptables.lng',
			'interface/web/admin/lib/lang/ru_iptables_list.lng',
			'interface/web/admin/lib/lang/se_iptables.lng',
			'interface/web/admin/lib/lang/se_iptables_list.lng',
			'interface/web/admin/lib/lang/sk_iptables.lng',
			'interface/web/admin/lib/lang/sk_iptables_list.lng',
			'interface/web/admin/lib/lang/tr_iptables.lng',
			'interface/web/admin/lib/lang/tr_iptables_list.lng',
			'interface/web/admin/list/iptables.list.php',
			'interface/web/admin/templates/iptables_edit.htm',
			'interface/web/admin/templates/iptables_list.htm',
			'server/plugins-available/iptables_plugin.inc.php',
			'interface/web/admin/form/tpl_default.tform.php',
			'interface/web/admin/lib/lang/ar_tpl_default_admin.lng',
			'interface/web/admin/lib/lang/bg_tpl_default_admin.lng',
			'interface/web/admin/lib/lang/br_tpl_default_admin.lng',
			'interface/web/admin/lib/lang/ca_tpl_default_admin.lng',
			'interface/web/admin/lib/lang/cn_tpl_default_admin.lng',
			'interface/web/admin/lib/lang/cz_tpl_default_admin.lng',
			'interface/web/admin/lib/lang/de_tpl_default_admin.lng',
			'interface/web/admin/lib/lang/dk_tpl_default_admin.lng',
			'interface/web/admin/lib/lang/el_tpl_default_admin.lng',
			'interface/web/admin/lib/lang/en_tpl_default_admin.lng',
			'interface/web/admin/lib/lang/es_tpl_default_admin.lng',
			'interface/web/admin/lib/lang/fi_tpl_default_admin.lng',
			'interface/web/admin/lib/lang/fr_tpl_default_admin.lng',
			'interface/web/admin/lib/lang/hr_tpl_default_admin.lng',
			'interface/web/admin/lib/lang/hu_tpl_default_admin.lng',
			'interface/web/admin/lib/lang/id_tpl_default_admin.lng',
			'interface/web/admin/lib/lang/it_tpl_default_admin.lng',
			'interface/web/admin/lib/lang/ja_tpl_default_admin.lng',
			'interface/web/admin/lib/lang/jp_tpl_default_admin.lng',
			'interface/web/admin/lib/lang/nl_tpl_default_admin.lng',
			'interface/web/admin/lib/lang/pl_tpl_default_admin.lng',
			'interface/web/admin/lib/lang/pt_tpl_default_admin.lng',
			'interface/web/admin/lib/lang/ro_tpl_default_admin.lng',
			'interface/web/admin/lib/lang/ru_tpl_default_admin.lng',
			'interface/web/admin/lib/lang/se_tpl_default_admin.lng',
			'interface/web/admin/lib/lang/sk_tpl_default_admin.lng',
			'interface/web/admin/lib/lang/tr_tpl_default_admin.lng',
			'interface/web/admin/lib/menu.d/tpl_default.menu.php',
			'interface/web/admin/templates/tpl_default_basic.htm',
			'interface/web/admin/tpl_default.php'
		);

		$curpath = dirname(dirname(realpath(dirname(__FILE__))));

		$c = 0;
		foreach($delete as $file) {
			if(strpos($file, '..') !== false) continue; // security!
			if(@is_file('/usr/local/ispconfig/' . $file) && !@is_file($curpath . '/' . $file)) {
				// be sure this is not a file contained in installation!
				@unlink('/usr/local/ispconfig/' . $file);
				ilog('Deleted obsolete file /usr/local/ispconfig/' . $file);
				$c++;
			}
		}
		ilog($c . ' obsolete files deleted.');
	}

}
