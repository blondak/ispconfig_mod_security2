## ISPConfig 3.3.3 Released

This release fixes security issues and bugs discovered after the 3.3.2p1 release. We recommend that all users update.

Already on 3.3.3 or 3.3.3p1? The two sections below list what the patch releases changed; the rest of this document describes 3.3.3.

### Changes in 3.3.3p2

- Websites on Apache: saving the Options tab failed with "Nginx directive blocked by security settings: include" when the website had stored nginx or proxy directives, which are hidden on Apache (e.g. from a former nginx server or set through the remote API). Stored directives that are sent back unchanged are now kept with a notice; new or changed directives are checked as before.
- Panel: after an error on a tab without the name field (e.g. the Options tab of a website), the heading shows the name of the record again instead of "Web Domain -".
- Multiserver: slave servers no longer log "command denied" errors for the master database when the name of a client database or database user is refused because it exists already on the server.
- Shell users: the jailkit maintenance accepts user and group names with a dot, like the creation of the shell user (#7096).
- Update: the installer no longer shows the PHP message "Creation of dynamic property db::$errorMessage is deprecated". When the server users can not be read from the master database, the update warns that their rights are not updated and goes on instead of stopping.
- Remote API: bugs found while writing the new API examples are fixed (#7095). The changes callers may notice are listed in docs/Remote_API_changes.md; `$conf['remote_api_version'] = 1;` keeps the old behaviour where noted there.
- Remote API examples: every function has a SOAP and a JSON example in remoting_client/examples, and the documentation in remoting_client/API-docs is generated from them (#7094).

### Changes in 3.3.3p1

- New setting System > Server Config > Web > "Certificate of a website named like the server host name" (#7093), see the notes for the update below.

### Security issues fixed in this release

- Privilege escalation of an authenticated client in the website module, reported by Saad ZITOUNI.
- A client could change the spamfilter settings of another client in the email module, reported by kta1kri (#7070).
- CSRF issue in the data log history viewer, reported by Alexei Khairov.

We thank the reporters for disclosing these issues responsibly. In addition, an internal code review of ISPConfig 3 found and fixed further security issues and many bugs; they are part of the lists below.

## What's new in ISPConfig 3.3.3?

### New Security Check Page

The new admin page Tools > Security check lists websites, users and settings with a known risk that ISPConfig does not change automatically, because they are a choice of the administrator or left over from an older version:

- Websites whose PHP-FPM pool listens on a TCP port instead of a socket
- Resellers that can use the website options (free web server directives)
- Remote users that can log in from any address
- Panel and remote users with a password hash of an older ISPConfig version
- Records of websites that no longer exist
- Secondary DNS zones of clients with a private or loopback primary server

Each entry explains what to change. We recommend checking this page after the update.

### Notes for the update

- Remote API users: the changes of the remote API that callers may notice are listed in docs/Remote_API_changes.md.
- The update logs out all users of the control panel once, including sessions with "Stay logged in". Everybody has to log in again after the update.
- The data log history in the monitor module is now only available for administrators.
- The check of the Apache and nginx directives in the website options refuses more directives. Existing websites keep their directives, they are checked again when the website is saved.
- Websites whose document root, PHP open_basedir or Apache AllowOverride contains spaces, line breaks or quotes (or whose document root is not an absolute path) are no longer written by the server; the server log shows a warning "Invalid document root, open_basedir or AllowOverride of website ...". Please correct these values in the website options.
- The values of select, radio and checkbox fields must be one of the options of the field, in the control panel and in the remote API. Values that are already stored stay valid. Apps that use the remote API and depend on the old behaviour can set `$conf['remote_api_version'] = 1;` in interface/lib/config.inc.local.php (the default is 2).
- Host names in the remote access list of MySQL databases are now granted on the database server, together with the IP addresses. Please run Tools > Resync for the databases after the update so that the database users of all databases are written again. An entry that is neither an IP address nor a host name (for example `192.168.1.%`) is not granted; leave the list empty to allow every host.
- nginx: the vhost template of the websites has changed. Please run Tools > Resync > Websites on nginx servers after the update, so that all websites get the new configuration (otherwise a website gets it when it is saved the next time).
- Borg backups no longer use a repository folder or a website backup folder (`web<id>` in the backup directory) that is a symlink; such backups and restores stop with a warning in the log. Link or mount the whole backup directory instead.
- The update scans the grants of the MySQL client databases for incorrect grants and fixes them. Grants it cannot fix, for example grants that were changed by hand, are listed as warnings during the update.
- Pure-FTPd now uses a real chroot on Debian and Ubuntu (VIRTUALCHROOT=false in /etc/default/pure-ftpd-common), the update sets it when the services are reconfigured. FTP users no longer follow symlinks that point outside their directory, for example to another website. Relative symlinks inside the website and the log folder keep working.
- The remote API no longer returns password hashes, the two-factor and password reset data of panel users and the private SSH key of clients, and these fields can not be used as filter. Apps that need them (for example for a migration) can set `remote_api_password_hashes=yes` in /usr/local/ispconfig/security/security_settings.ini.
- The update now keeps changed values of /usr/local/ispconfig/security/security_settings.ini (since 3.2 they were reset to the defaults). When server/conf-custom/install/security_settings.ini.master exists, that file is used as before.
- The remote API is now disabled on new installations (`remote_api_allowed=no` in /usr/local/ispconfig/security/security_settings.ini). The update also disables it on servers that have no remote user (System > Remote Users), servers with remote users keep their setting. To use the remote API, set `remote_api_allowed=yes` in that file on the server that runs the control panel. System > Remote Users shows a notice while the remote API is disabled.
- The remote function `client_login_get` now also limits failed logins per user name (10 within 5 minutes).
- The remote functions `sys_datalog_get` and `sys_datalog_get_by_tstamp` need the new remote permission "Datalog functions". The update grants it to remote users with the "Server functions"; other remote users that need these functions must get it in System > Remote Users. Their records leave out passwords and keys unless `remote_api_password_hashes=yes` is set.
- The mail import from ISPConfig (Tools > Import > ISPConfig Mail) now checks the SSL certificate of the remote server. For a remote server with a self-signed certificate, tick "Accept a self-signed or invalid SSL certificate of the remote server". The password of the remote user is no longer shown on the import page.
- The remote functions `server_config_set`, `system_config_set`, `server_ip_add`, `server_ip_update` and `server_ip_delete` follow the settings `admin_allow_server_config`, `admin_allow_system_config` and `admin_allow_server_ip` in /usr/local/ispconfig/security/security_settings.ini: with `no` they are refused. Nothing changes with the default `superadmin`.
- The remote functions of a DNS record type (for example `dns_txt_get`, `dns_txt_add`, `dns_txt_update`, `dns_txt_delete`) only read, change and delete records of that type. To read all records of a zone use `dns_rr_get_all_by_zone`; to change the type of a record, delete it and add a new one.
- WebDAV users created or changed through the remote API now get the same password digest as in the control panel, so they can log in. Apps that already send the digest must also send `_ispconfig_pw_crypted=1`. WebDAV users that were created through the remote API before need a new password.
- The lost password page gives the same answer for every request. Password reset links that were sent before the update no longer work; users can request a new link.
- Creating the firewall record of a server (System > Firewall) no longer resets UFW, and deleting it removes only the ports of the record before UFW is stopped. UFW rules that were added outside ISPConfig are kept.
- Generated passwords ("Generate password" buttons) are now 16 to 20 characters long and contain more special characters.
- Clients and resellers can add mail transports only for their own domains and their subdomains. Administrators can add transports for any domain as before.
- A website named like the host name of the server (the `hostname` in System > Server Config > Server) now shares its Let's Encrypt certificate with the server when acme.sh is used: the certificate is installed as the server certificate (/usr/local/ispconfig/interface/ssl/ispserver.crt and ispserver.key, used by the control panel, Postfix, Dovecot and Pure-FTPd) and the SSL files of the website link to it. The certificate then contains the domains of the website (e.g. the www subdomain and alias domains), and the renewal of the certificate runs the ISPConfig renew hook again, which reloads the services. Before, the website took over the certificate of the server and the server certificate was no longer renewed. Nothing changes with certbot, where the website and the server already used the same certificate.
  - Changed in 3.3.3p1: this is now a setting, System > Server Config > Web > "Certificate of a website named like the server host name" (#7093). "Off" (default) installs the certificate into the website as before 3.3.3 and leaves the server certificate files and links set up by the administrator as they are. "Server certificate" is the behaviour of 3.3.3. "Website certificate" installs the certificate into the website and links the server certificate files to it. The update selects "Server certificate" on servers where 3.3.3 already linked the website to the server certificate, and "Website certificate" where the server certificate files were links to the website, which 3.3.3 turned into a loop of links; the update repairs that loop with the certificate that acme.sh keeps for the website.
- A new MySQL database record whose database already exists on the server is removed again by the server, with a warning in the log; the existing database is not changed and gets no grants. Add the database record first and import the data afterwards (as the Migration Toolkit does). Renaming a database to the name of an existing database is refused, the record keeps its old name.
- A MySQL database user whose account already exists on the server with another password gets no grants and no password or name change, with a warning in the log; the existing account is not changed. Add the database user in ISPConfig instead of creating the account by hand. Renaming a database user to the name of an existing account is refused, the user keeps its old name.
- PostgreSQL databases: read-only users now get read access to the tables, views and sequences of their own database (also to those the owner creates later) instead of the role `pg_read_all_data`, and only the owner and the users of a database connect to it. The update changes the existing client databases and read-only users. Tables created by a role other than the database owner need a manual `GRANT SELECT` for the read-only user. The rules for existing databases and accounts above apply to PostgreSQL databases and roles as well, and `postgres`, `template0` and `template1` are not allowed as database names.
- nginx: the nginx directives of a website and the nginx directive snippets are written into the vhost as text. Template tags such as `<tmpl_if>` or `<tmpl_var>` in them are no longer processed; nginx refuses a vhost that contains them and the previous vhost stays active, so remove such tags from the directives and snippets. The placeholders `{DOCROOT}`, `{DOCROOT_CLIENT}`, `{DOMAIN}`, `{FASTCGIPASS}` and the location markers `##merge##` and `##delete##` work as before.
- nginx directives: the directives that set the paths of temporary files (`client_body_temp_path`, `proxy_temp_path`, `fastcgi_temp_path`, `uwsgi_temp_path`, `scgi_temp_path`) are no longer accepted for websites. A custom list `security/nginx_directives.blacklist.custom` replaces the shipped one and needs the same addition.
- System mail: the certificate of the SMTP server is now also checked with STARTTLS (as it was with SSL), except for an SMTP server on localhost. A new setting under System > Interface Config > Mail accepts self-signed or invalid certificates. The update turns it on for installations that use STARTTLS to an SMTP server other than localhost, so their mail keeps working; turn it off once the SMTP server has a valid certificate for the host name in the settings.
- PostgreSQL databases: the users of a deactivated database can no longer log in (their open sessions end) until the database is active again; the same applies to a user that is replaced by another one. The data stays unchanged.
- System mails sent by SMTP use SMTP line ends, and lines of the text that start with a dot keep it.
- Websites: clients and resellers can choose only the website's own domain, its alias domains and subdomains as SSL domain, as the form offers. A stored SSL domain stays valid.
- Databases and database users: when the prefix ends with a digit (as the default `c[CLIENTID]`), the panel refuses a new name, or a changed name, that starts with a digit. Existing names stay unchanged; the remote API is not affected.
- PostgreSQL databases: when ISPConfig removes the `pg_hba.conf` lines of a database user, lines whose database or user field is an unquoted keyword such as `all` or `replication` stay in the file.
- FTP: the daily FTP log job no longer makes the pure-ftpd log files world-readable; it removes the read access for other users from the files in `/var/log/pure-ftpd`.
- Rspamd: the controller (web interface and `rspamc`) asks for the password also for requests from the server itself; use `rspamc -P <password>` for commands that change data. ISPConfig adds `secure_ip = [];` to `/etc/rspamd/override.d/worker-controller.inc`, unless that file sets `secure_ip` already.
- Mail: the update makes the relay host password map `/etc/postfix/sasl_passwd` and its indexed copies readable by root only. The installer and the update no longer make the mail, syslog and ClamAV log files readable for all users.
- nginx: with a single address set for the apps vhost (System > Server Config > Web > Apps-vhost IP), the apps vhost listens only on that address and no longer also on all IPv6 addresses. An IPv6 address can be entered with or without brackets.
- Shell users: the directory can no longer contain spaces. A shell user with such a directory keeps working; correct the directory when you save the user again.
- Remote API: the REST endpoint `remote/rest.php` was removed, it answered every request with an error. Use the SOAP (`remote/index.php`) or JSON (`remote/json.php`) endpoint; the update deletes the files.
- Installer and update: the MySQL admin credentials are passed to the mysql command line tools (mysql, mysqldump, mysqlcheck) in a temporary option file readable only by root instead of on the command line.
- Update: the dumps of the ISPConfig and PowerDNS databases that the update writes into the install directory are readable for root only.
- Backups: the download of a Borg backup prepares the files in a new temporary directory that only root can access and removes it afterwards, also when the download fails.
- Virtual servers (OpenVZ): the action page (start, stop, restart, create OS template) only works for the virtual servers the user may change.
- Virtual servers (OpenVZ): the DNS record of a virtual server is only created in a zone that the user may change; administrators can use any zone as before.
- Statistics (GoAccess): the report is created in a temporary directory and copied into the stats folder of the website as the website user.
- Websites: the error pages are copied into the `error` folder of a website only when it is a real folder; otherwise the server writes a warning to the log.
- Websites, shell and FTP users: the server writes the files in the folders of a website (password and `.htaccess` files of protected folders and statistics, PHP starter scripts, WebDAV password files, the `.profile`, `.bashrc` and `authorized_keys` of shell users) and creates the folders in them (FTP directories, protected folders) as the website user. This needs `sudo` on the web servers.
- Only administrators can add a website, alias domain or subdomain named like the host name of a server. Clients and resellers get the message that the domain already exists.
- Extensions are installed and updated without confirmation only when their package is signed with a trusted key of the ISPConfig extension repository. For a package without such a signature, confirm the install or update with "Install anyway" or "Update anyway" in System > Extensions, or add `--allow-unsigned` to `ispc extension install` and `ispc extension update`. The reason and the confirmation are written to the system log.
- System > Server Config, System > Interface > Main Config and the additional PHP versions check paths, host names, ports and lists more strictly. A stored value that does not pass the new checks is kept when the form is saved without changing it, and the panel shows a warning for it; please correct such values. The login page shows the custom login text as plain text, HTML in it is no longer interpreted.

### Bugfixes

- Fixed intermittent "CSRF attempt blocked" errors when saving a form in the control panel. Two requests of the same login that ran at the same time (for example a slow page and a click on a form) could overwrite each other's session data, so the security token of the form was lost. Requests of one session now run one after the other, like with the PHP file sessions; a request waits at most 10 seconds. Form tokens are now valid for 24 hours instead of 1 hour, so a form that stays open for a long time can still be saved (#7041)
- Fixed the news feed in the left navigation of the dashboard failing to load with an error 500 on PHP 8 when the feed contains Unicode characters such as emojis. The bundled SimplePie library called several helper functions statically that were not declared as static, which PHP 8 no longer allows (#7059)
- Fixed the "Web server config" dropdown of alias domains and subdomains (vhost) being empty when logged in as admin. The form did not determine the server of the parent website, so the directive snippets were loaded for an empty server type. The form now always uses the server of the parent website for alias domains and subdomains, also for clients and resellers with several web servers (#7062)
- Fixed three issues in the extension framework that prevented extensions from creating their own database tables. The install, uninstall and migration SQL files of an extension were run as the ISPConfig database user, which has no CREATE, ALTER or DROP privilege, so any CREATE TABLE failed with "CREATE command denied". They now run with the MySQL root credentials from mysql_clientdb.conf, like the SQL files of the ISPConfig updater. Successful SQL runs, migrations and master grant registrations were logged with the undefined constant LOGLEVEL_INFO, which aborted the installation with "Undefined constant LOGLEVEL_INFO" right after the SQL had been loaded, and also the uninstallation of extensions with master grants. The root credentials for applying master database grants were never read because of an operator precedence error around include, so the grants were only applied by the next ISPConfig update or setrights.php run (#7063)
- Fixed install.php and update.php retrying forever when run with --autoinstall and a MySQL login fails, for example because of a wrong password in the autoinstall.ini file. As the answers are read from the file, each retry used the same credentials, which caused a flood of failed root logins on the MySQL server, on a slave server also on the master. The installer and updater now print the connection error and exit with status 1 in autoinstall mode. This applies to the local MySQL server and the master server. An invalid value for a y/n or selection question in the autoinstall.ini file now also stops the installer with an error instead of looping silently. The interactive mode still asks again. On PHP 8.1 and newer, a failed login to the local MySQL server aborted the installer and updater with an uncaught mysqli_sql_exception instead of asking for the password again, this has been fixed as well (#7065)
- Fixed the MySQL root password being stored wrong in mysql_clientdb.conf when it contains a double quote ("). The value was escaped with addslashes() but written into a single-quoted PHP string, so the double quote was read back with a leading backslash and the root login of the updater and the server scripts failed. Only the characters that need escaping in a single-quoted string are escaped now, which also applies to the MySQL hostname and username in that file (#7064)
- Fixed a slave server losing the connection to a master database server that requires SSL after an ISPConfig update. The update rewrote config.inc.php with dbmaster_client_flags = 0 and could not log in to the master itself, as the master connection of the updater did not use any client flags. The updater now keeps the existing dbmaster_client_flags and db_client_flags values and uses the master client flags for its own connection to the master. Custom config.inc.php.master templates in /usr/local/ispconfig/server/conf-custom/install/ are used as they are, so they need to be updated manually to keep the flags. Joining a new slave server to a master that requires SSL during installation is not supported yet (#4606)
- Fixed authentication failures for mail passwords containing non-ASCII characters such as umlauts, set through the mailbox form or the remote API. The password was converted to ISO-8859-1 before it was hashed, while mail clients send the password as UTF-8, so Dovecot could not verify it. The password is now hashed as UTF-8, like passwords set through the mail user self-service. Existing hashes are unchanged, affected passwords must be set again after the update (#7066)
- Spamfilter whitelist and blacklist: the recipient (mailbox or domain) must be one the user may change. Reported by kta1kri (#7070)
- Data log history: the undo of a change needs the security token of the panel. Reported by Alexei Khairov
- Website IP addresses: the panel and the remote API accept only the IPv4 and IPv6 addresses of the website's server that the user may use, and the server writes only valid IP addresses into the web server configuration. Reported by Saad ZITOUNI
- Website domains, alias domains, subdomains, redirects, web folders and protected folders: the server checks the values before it writes them into the web server configuration. A website with an invalid value keeps its current configuration and the server log shows a warning; an invalid alias or subdomain is left out of the configuration.
- The document root, PHP open_basedir and Apache AllowOverride of websites must be a valid path list or AllowOverride value. Stored values that do not match are kept when they are saved unchanged (with a warning in the control panel).
- The control panel login log (auth.log) writes each login attempt on one line.
- XMPP domains: the domain admins, MUC admins, MUC name and pastebin trigger are checked in the control panel, and the server writes them as escaped strings into the Metronome configuration.
- Email white- and blacklist: clients create entries with the action REJECT (blacklist) or OK (whitelist) and no sender entries in the whitelist; administrators and the remote API can use the Postfix access actions OK, REJECT, DUNNO, DISCARD, HOLD, DEFER and reply codes. See docs/Remote_API_changes.md
- Mail domains: clients can change the relay host settings only with the relay host permission and when the per-domain relay options are enabled; relay host, user and password are checked. See docs/Remote_API_changes.md
- Virtual servers (OpenVZ): host name, name servers, capabilities, features, iptables modules, resource limits and custom config lines are checked in the control panel and the remote API, and the server writes only a valid configuration. See docs/Remote_API_changes.md
- Form values that are checked against a pattern no longer accept a trailing line break.
- Email filters: the target folder must be a folder name below the mailbox (no leading /, no empty, . or .. parts).
- Virtual servers (OpenVZ): OS templates are created by administrators only, and the server does not replace an existing template file.
- DNS: TXT, DKIM, DMARC and SPF data must be valid quoted strings, and the server leaves records with broken quoting out of the zone file (with a warning). NAPTR replacements, zone origins, the allow-update list (IP addresses, networks, key names and ACL names), CAA data, the CA issuer and the values of DNS templates are checked. See docs/Remote_API_changes.md
- Mail domains: the DKIM public key is always derived from the private key, also for the remote API, so an own new private key gets its public key (#7091). See docs/Remote_API_changes.md
- Mail transports: the destination is checked for its type, the type custom is available to administrators only (existing custom transports of clients are kept). See docs/Remote_API_changes.md
- Spamfilter policies and spamfilter users: quarantine destinations, address extensions, admin addresses, banned rule names and the user email are checked. See docs/Remote_API_changes.md
- Mail: mailbox paths, uid/gid, IMAP prefix, maildir format and custom rules, content filter rules, forward destinations, alias domain destinations, white/blacklist sources and relay recipients are checked, also for the remote API; stored values are kept when they are saved unchanged. See docs/Remote_API_changes.md
- Websites: SSL certificate, key, bundle and CSR are checked when they are saved; WebDAV directories, FTP limits, website ports and admin group names are checked; auto alias names that are no host names are left out of the vhost (with a warning).
- Fixed the default values of the client, reseller and client template limits in the forms not matching the values new records get.
- Fixed a new OpenVZ virtual server not being saved with the preset boot order 0.
- Fixed Rspamd not DKIM-signing mail from a "send as" alias in another domain when the sender login check (reject_sender_login_mismatch) is on (#7086)
- The installer can join a multiserver setup whose MySQL master requires SSL (expert mode question, autoinstall key mysql_master_ssl) (#7067)
- Fixed the nginx stats folder protection (#7087)
- Fixed Tools > Resync logging the SQL error "Table 'dbispconfig.mail_relay' doesn't exist" and not offering the mail relay recipients (#7085)
- Fixed the help text of the DMARC aggregate report address: aggregate reports cover all messages of the domain (#7084)
- Fixed the database quota notification comparing the quota of a database with the size of a database with the same name on another server (#7082)
- Fixed "Reconfigure Permissions in master database" of the update failing on a master with a database name other than dbispconfig (#7079)
- Fixed system mails (OTP codes, password reset, notifications) to the administrator address getting a Reply-To that equals the recipient, which spam filters score high; the Reply-To is only set when it differs from the sender and the recipient (#7078)
- Fixed new shell users without jailkit getting the keys of root's authorized_keys regardless of the server setting; all new shell users now get only the keys of the "authorized_keys template for new shell users" setting (System > Server Config > Jailkit), which is empty on new installs. Updated servers keep their setting: check it, and check existing shell users for administrator keys copied earlier (#7076)
- Rspamd no longer DKIM-signs mail that is sent on the server without SMTP authentication (e.g. PHP mail() of websites); the new Mail setting "DKIM-sign local mail" turns it on again. Websites that need DKIM-signed mail send it through authenticated SMTP
- Fixed the {VEID} placeholder in the host name of an OpenVZ virtual server saved in the panel not being replaced
- Fixed email white- and blacklist entries not being saved when source and type were unchanged
- Fixed long DNS TXT records being split inside an escape, SRV records being built from unchecked weight and port values, and the rendered zone of a DNS zone being overwritten by the form; the DNS wizard offers clients only visible templates; DNSKEY records are no longer imported
- Fixed mail transports: a stored transport smtp: or an error text with a colon changed when it was saved again
- Fixed email filters on maildrop servers: rules for the size, the domain and the local part were incomplete; regular expression rules are refused for maildrop servers
- Fixed the Email Routing menu of clients being shown only with the white/blacklist permission, and the XMPP registration URL, registration message and SSL state being ignored
- Fixed a custom Sieve filter that does not compile replacing the working filter of a mailbox; the previous filter is kept and the server log shows a warning
- Fixed the acme.invalid check of website certificates reading the old certificate file, URL cron jobs breaking on %, and reseller email addresses with + being refused
- Removed the unused admin pages IPTables and default theme, the mail_spamfilter forms and unused DNS validator functions; the update deletes the files
- Fixed the Pure-FTPd SNI plugin not restarting Pure-FTPd after the certificate of a website changed. It called a service that was not registered, so every certificate update logged "Unable to restart pure-ftpd-mysql. Service not registered." and Pure-FTPd kept the old certificate. Pure-FTPd is now restarted once at the end of the server run (#7083, #7075). A restart of a service that is not registered no longer adds a PHP warning to the cron log
- Fixed the utf8mb4 conversion of the database stopping at the first table that could not be converted (old MyISAM tables on MySQL 8, zero dates with a strict SQL mode), so many tables stayed utf8mb3. The update now converts the remaining tables (MyISAM tables become InnoDB), keeps the collation of databases that are already utf8mb4 and lists tables it could not convert. New installs create all tables as utf8mb4 (#7072)
- Fixed Rspamd greylisting mail of recipients with greylisting off when the spam score reached the tag level; greylisting off now skips the greylisting check completely, also for whitelisted senders. The Rspamd settings files of existing mailboxes and spam filter users are rewritten when the records are saved, or with Tools > Resync > Mailboxes and Mailfilter after the update (#7071)
- PHP-FPM pools of websites and of the panel use a listen backlog of 4096 for all PHP versions (PHP up to 8.1 used 511), as PHP 8.2 and newer do by default (#7050)
- Fixed PostgreSQL databases and users no longer being created when the file /usr/local/ispconfig/server/lib/postgresql_clientdb.conf was missing while the PostgreSQL role ispconfig existed, for example after a reinstall. The file was written with a new password that the role never got; now the existing role gets the new password, and the pg_hba.conf lines for ispconfig are only added when they are missing
- Fixed `ispc extension list` showing the description of the previous extension for an extension without a repository entry, and listing nothing when the extension repository could not be reached
- Fixed the remote actions extension_list and extension_available stopping the server script; they are removed, as nothing uses them
- Fixed deleting a client removing the wrong group from a user. The remote function client_delete_everything did not remove the group of the deleted client from its reseller, and removing a group from a user who did not have it removed the first group of that user instead, for example a group of the admin user when a client of the admin was deleted
- Fixed changes of the relay host in the server config. The entry of the old relay host stayed in /etc/postfix/sasl_passwd in some cases, several changes at once added the same entry several times, and every change replaced smtp_sasl_password_maps with the sasl_passwd file only, so the relay hosts with authentication of mail domains no longer worked; the other password maps are now kept, and SASL authentication stays on while they are configured
- Fixed jailkit programs: after a program with a prohibited path (such as /tmp) all following programs of the list were skipped and not copied into the jail
- Fixed an update of a jailkit shell user creating .bash_history, .profile, .bashrc.d and .local in the document root of the website instead of the home directory in the jail. Files that earlier versions left in the document root are not removed automatically
- Fixed the installer replacing a Let's Encrypt certificate for the server that acme.sh had just issued with a self-signed one when certbot is installed as well
- Fixed the nginx PageSpeed option of a website adding the PageSpeed configuration also when the nginx directives of the website configure PageSpeed already
- Fixed nginx folder directive snippets creating their folder next to the web folder of the website (for example webshop instead of web/shop)
- Removed the placeholder {PHPFALLBACKFASTCGIPASS} from the nginx directive help in the panel; it was never replaced, and nginx refused a vhost that used it
- Fixed OpenVZ virtual servers: the values of the VM template were not copied to a virtual server, and on new installations the advanced tab and the remote functions openvz_vm_add and openvz_vm_update failed on the column iptables (the update renames the column)
- Fixed PostgreSQL databases: after a change of the read/write user the tables, views and sequences of the database now belong to the new user, and other databases of the old user keep their owner
- Fixed the FTP traffic statistics counting the traffic of the pure-ftpd log several times; the daily job now only counts the lines added since its last run
- Fixed the server script stopping at the delete of a vhost subdomain or vhost alias domain whose website was deleted before (for example when a client and all its records are deleted); no later change was applied on that server
- Fixed vhost subdomains and vhost alias domains added through the remote API: they now get the document root and system user of their website
- Fixed OpenVZ virtual servers: a change of the VM template now copies the values of the template to the virtual server, a change of the OS template no longer overwrites them
- Fixed a custom php.ini setting without a name (a line such as `= value`) stopping PHP-FPM: PHP-FPM refused its whole configuration, so all websites with that PHP version failed after the next restart. Such lines are no longer written into the pool, and the website form refuses them
- Fixed clients not being able to create XMPP domains (the check of the allowed XMPP servers always failed)
- Fixed the SSL certificate of an XMPP domain on a slave server not being stored in the master database. Run the update on the master with "Reconfigure Permissions in master database" to add the missing permission
- Fixed the Metronome setting for the creation of chat rooms of an XMPP domain: the host configuration got the stored value (n/m/y) instead of false/member/true
- Fixed the spamfilter whitelist and blacklist pages changing or deleting an entry of the other list
- Fixed the duplicate check of CAA records, an existing CAA record can still be saved unchanged
- Fixed the error messages of the DMARC record page for invalid report addresses, they now name the address
- Fixed the DNSSEC information of a DNS zone being overwritten when the zone is saved in the panel
- The SPF form lists the policies from strict to open (-all, ~all, ?all, +all) and a new SPF record starts with ~all instead of +all (#7090)
- DNS zones whose name starts with an underscore (e.g. `_acme-challenge.example.com`) can be saved again, also to enable DNSSEC (#7089)
- DNS records can only be added to a DNS zone that the user may change, read access to the zone is not enough
- A website with a PHP version that is no longer active, or that has no settings for the PHP mode of the website, now shows the error "PHP Version is invalid." on saving instead of switching to the default PHP version silently
- Fixed the wrong directive snippet being selected when the list of snippets is reloaded in the website form
- Fixed a domain added by a reseller in the domain module getting no client group when the selected client could not be used, the domain now belongs to the reseller
- Fixed the reseller select of the client form: the current reseller stays selected when it is no longer a reseller, and the client itself is not offered
- Fixed saving the CAs in System > Main Config > DNS CAs: the name, issuer and the checkboxes for wildcard, critical and active are saved, and the tab no longer writes an empty section into the system config
- Fixed vhost alias domains being switched off in System > Main Config while vhost alias domains exist
- Fixed saving a remote user removing the functions of modules that the admin user does not have in its own module list
- Virtual servers added through the remote API (openvz_vm_add) are set up as in the panel: VEID, VM template values, IP addresses and OpenVZ config. See docs/Remote_API_changes.md
- Websites added through the remote API without php_fpm_use_socket use the PHP-FPM socket, as in the panel
- Mail filters with an invalid regular expression are refused; such a filter added through the remote API never matches instead of stopping all Sieve filters of the mailbox
- Fixed white- and blacklist entries of client IP addresses and hostnames having no effect on Rspamd servers
- A message to a client circle without members is sent to nobody (before: to all clients)
- Fixed client_update through the remote API without a new password making the client password unusable
- The version check of the dashboard waits at most 5 seconds when the ISPConfig download server can not be reached
- Fixed the mails of an mdbox mailbox not being moved to the new maildir when the maildir changes
- Fixed the RAID monitor not reporting degraded or failed arrays of 3ware, HP, MegaRAID and Adaptec controllers
- PostgreSQL database names are limited to 63 characters including the prefix
- Fixed the size of PostgreSQL databases with upper case letters in the name not being recorded
- The ISPConfig import tool reports mailboxes imported without a password
- Fixed the server selection of the ISPConfig import tool being empty after connecting
- Fixed DNS record forms storing a record type other than their own
- Fixed update_serial of the DNS record functions of the remote API requiring the zone functions; see docs/Remote_API_changes.md
- Fixed update_record_permissions of the remote API changing only one of several matching records on the servers; see docs/Remote_API_changes.md
- A locked client can no longer delete items
- Fixed PHP 8.5 deprecation notices for (double) casts
- Fixed nginx leaving the log mounts of a website behind when the website is deleted or moved
- Fixed server.php stopping when the record of a server is deleted
- Fixed extension license updates not reaching the server on servers installed with ISPConfig 3.3.0 or newer
- Fixed the groups of deleted clients and resellers staying on slave servers
- Fixed the PHP link of shell users on websites with the default PHP, and the PHP deprecation messages it logged (#7074)
- An update of a shell user keeps the user's ~/.profile
- Fixed jail directories being created with wrong permissions
- authorized_keys of shell users ends with a newline
- Fixed errors in the log when the password of a database user changes together with its remote hosts
- Fixed changes of folder protection users and shell users touching users whose name ends with the same name
- Fixed the installer removing the wrong lines from configuration files (e.g. freshclam on CentOS)
- Fixed server.php and security/check.php stopping with a fatal error when the database connection fails
- The updater warns when it can not store the service flags of the server
- The Let's Encrypt pre-check of the hostnames gives up after a timeout
- Saving a tab of the server settings keeps the settings of the section that have no form field
- The client selection of a new website follows the domain module setting for administrators
- Fixed the backup retention of a database deleting the backups of other databases with the same name prefix
- Fixed backups with "etc" in their path that could not be restored, downloaded or deleted
- Borg repositories shrink when backups are deleted
- Fixed the website quota during a root restore (ext4 and XFS)
- The extension page offers an update only for a newer version
- `ispc extension` ends with exit status 1 on errors and can disable, enable and uninstall extensions without the repository
- License keys can be set for extensions with "_" in their name, and the extension installer stops on a failed unzip
- The warning about the hidden default PHP version of a website is shown
- Fetchmail accounts follow a renamed mailbox and are deleted with it, mail filters are deleted with the mail domain
- Deleting a mail filter keeps the indentation of the custom Sieve rules
- The DNS zone import reads record TTLs with units (e.g. 1h, 2d)
- Unlocking a client restores the previous owner of its records
- MX and NAPTR priorities above 65535 are refused; A, AAAA, HINFO and SRV names may be up to 255 characters; TLSA names like _443._tcp are accepted
- Customer number templates of resellers may contain digits
- A client password sent back as the stored hash through the remote API no longer locks the client out
- Getmail accepts destinations with punycode top-level domains
- Website, subdomain and alias names with empty labels (e.g. a..b.com) are refused; the web folder of a subdomain may have one character
- The SOA admin address keeps dots of its local part (first.last@...)
- Secondary DNS zones accept networks and any in the transfer list
- Fixed the mail queue, Let's Encrypt log, MySQL, POP3/IMAP and firewall monitors
- A failed web server restart after a website change shows an error on the website
- The cron frequency limit of clients is checked against the whole schedule (weekly and monthly jobs are allowed)
- Web folder paths with .. are refused
- server.php no longer stops when a website is deleted before its WebDAV or shell users are processed
- Deleting a cron job keeps the domain in the other cron jobs of the website
- Fixed client updates through the remote API switching websites of the client on again
- An additional client template that is still in use can not be deleted
- The DNS zone import reports records outside the zone, refuses a zone file of another domain and keeps the case of TXT data
- DNS templates are checked when they are saved; the DNS wizard reports a broken template instead of stopping
- sites_database_add and sites_database_update no longer fail with the backup format parameters
- Fixed the tables of an extension being registered twice
- Fixed monitor data: ISPConfig cron log escaping, stale mailbox quota and database size data, network rates and memory of the system usage
- Fixed the website quota of multiserver setups being read from another server
- The FTP traffic statistics in the remote API return values
- The monitor keeps the selected server, the job queue lists the entries for all servers and of the master of a mirror
- Removed the broken delete button of the job queue
- Resync of mail transports, relays, filters, fetchmail accounts and mailing lists uses the selected server
- Fixed searches in lists with extra conditions (e.g. support messages)
- Deleting a mailbox no longer deletes the backups of mailboxes whose ID starts with the same digits
- Changing the backup format of a website keeps the backup interval of its databases
- A web backup is only restored on the server of the website
- IPv6 addresses of a server are compared independently of their notation
- The firewall ports accept spaces and refuse text before the first port
- An IP mapping of a mirror can not be added twice
- Clients without backups in their limits no longer see the backup interval of databases
- Deleting a mail domain on a multiserver setup removes it on the master
- Starting a backup in the panel needs the edit permission of the website
- A failed database dump of the system backup is reported and no longer replaces older backups
- Fixed the error pages and the standard index page of websites on servers with the language ja, el or ar
- The installer accepts autoinstall languages like en_US
- The disk usage monitor converts all units
- The dashboard search treats % and _ as text
- Renaming a PostgreSQL user no longer adds pg_hba.conf lines for MySQL databases
- mdbox mailboxes with an IMAP prefix get their default folders with the prefix
- Fixed the resync of database users and `ispc resync client`
- Fixed German texts of the DNS wizard
- The duplicate check of CAA records looks in the zone of the record
- The server settings refuse a relative backup directory
- The admin IP whitelist stays readable for the panel after an update
- The addresses of the mirror servers are added to the remote access of a database
- The limits of child domains and database users are also checked when the form is saved
- Status changes of mail domains and DNS zones through the remote API reach the servers
- PowerDNS: TXT records are written quoted and HINFO records keep their blanks
- The `[update]` section of an autoinstall file takes precedence in update.php
- The installer writes database passwords with backslashes or single quotes correctly into config.inc.php
- A failed rename of a MySQL database keeps the old database and name
- Failed extension actions are reported as failed, errors of an earlier action are cleared
- Moving a website to another client also changes the owner of its subdomains and alias domains
- A changed document root moves the FTP and shell user folders and the open_basedir paths below it
- Fixed the check of active websites when a directive snippet is disabled
- Fixed the IP detection of the installer on slave servers
- The domain limit of the domain module is also checked when the form is saved
- A failing cron job of the server no longer stops the other jobs
- Extension repository: invalid catalog answers, dependency lists as arrays and dependency cycles are handled
- Let's Encrypt: names with a wildcard are left out of the certificate request with a warning
- The database name and user prefixes accept only the supported placeholders
- Moving a website to another client removes the link in the folder of the old client
- The DNS wizard refuses a zone that exists already
- Domain names with an empty part after the last @ no longer give an error in the IDN conversion
- Deleting an alias domain or subdomain whose website is gone no longer gives PHP warnings
- The cleanup of soft-deleted mailboxes no longer looks outside the mail home with an empty home path
- install.php and update.php stop with exit status 1 when the autoinstall file is missing
- Mirror servers keep their jailkit update state of websites
- Fixed PHP warnings in the nginx, postfix and mail quota code
- The jk_socketd.ini entries of deleted jails are removed
- useradd no longer creates home directories for website, cron and shell users (RHEL-like systems)
- The file checksum list of install and update uses the 24-hour clock in its name and mode 0600
- Deletes replicated to a slave no longer fail because of an earlier SQL error
- The datalog cleanup keeps entries a mirror server has not processed yet
- server.php logs an error when it can not read the datalog of the master
- Server modules are loaded in name order
- `ispc` refuses invalid module names
- Deleting a mailbox with the maildeliver plugin removes the Sieve file in the maildir of that mailbox
- Unsubscribed default mail folders are no longer subscribed again on every mailbox update
- A failed nginx config test or reload is logged as a warning
- The Postfix client access list only uses entries of its own server
- The automatic CAA record of a wildcard website gets a fully qualified name
- Fixed PHP warnings in the PHP binary detection and Let's Encrypt key type selection
- certbot gets the key type explicitly, a key type in the certbot cli.ini no longer changes the certificate type
- The update counts only the configured web server as installed
- Removed the deprecated curl_close() calls for PHP 8
- The group, passwd and shadow files written by ISPConfig end with a newline
- Added missing error texts of the FTP, shell user, website, spamfilter and DNS template forms
- server.php and cron.php stop with a warning when a database is not reachable
- The installer functions report write errors instead of a PHP error
- Only one update can run at a time on a server
- Apache: the SAN of a CA-signed SSL certificate is the domain of the website
- Pure-FTPd SNI uses the certificate of the SSL domain and Let's Encrypt certificates
- nginx stores the key of a generated SSL certificate in the website, as Apache does
- A successful Let's Encrypt request only clears the SSL fields of websites that use Let's Encrypt
- awstats statistics stop with a warning when the awstats scripts are missing
- Commands with a lot of output no longer hang in pipe_exec()
- Fixed PHP warnings in the ispc table output
- Website quota commands no longer run in the background on Debian and Ubuntu
- Renaming a mailbox also updates forwards with several targets
- Errors of a datalog entry processed by several servers are logged for each server
- The database usage is matched per server when several servers have a database with the same name
- A failed rename of a MySQL user or PostgreSQL role is logged, pg_hba.conf keeps the old entries
- A failed XFS quota limit is logged as a warning
- A subdomain or alias website whose parent website is gone no longer breaks PHP-FPM
- Database quotas are enforced for databases on slave servers: the master sets the quota flag from the monitor data of all servers
- The installer always sets the given admin password; the autoinstall samples default to a random password
- Install and update warn when the Perl module Date::Format for vlogger is missing on Apache servers
- Log folder bind mounts are no longer stacked when a website is updated again
- The placeholders [website_idhash_2] to [website_idhash_4] give 2 to 4 levels also on a client change (new website paths follow the configured layout)
- The installer asks before requesting a Let's Encrypt certificate for a hostname without public DNS records
- nginx servers with Pure-FTPd get the file service on install; the update warns when it is off
- Client passwords with a backslash work for the panel login
- The phpPgAdmin button is shown for PostgreSQL databases in the database list
- The restore of a damaged website backup archive stops with an error and leaves the website unchanged
- The database quota is shown in the same unit the server uses for the quota check (1 MB = 1024 × 1024 bytes)
- install.php and update.php read the answer file given with --autoinstall, also when an autoinstall.ini exists in the install directory
- nginx: Let's Encrypt certificates for new websites and new alias domains include all names (before: names that nginx did not serve yet were dropped)
- The system log shows the last output lines of certbot or acme.sh when a Let's Encrypt certificate could not be issued
- The web server is reloaded after certbot renewals done by the certbot timer of the distribution
- When acme.sh and certbot are both installed, unused certbot certificates are also removed by the Let's Encrypt cleanup
- New certbot accounts are registered without an email address (before: the webmaster address of the first website)
- Database backups only include the active databases whose backup interval is due; a database with the interval "none" is no longer backed up because another database of the website is due
- The backup cleanup on a multiserver node no longer deletes backup records of other backups on the master
- A client with full permissions on a website created by the reseller can save the main tab of the website
- Saving a website, DNS zone, mail domain or database user as reseller keeps the client protection set by the admin
- The client protection setting applies to all client websites created by admin users or through the remote API
- The old spamfilter server config pages (no menu entry since years) were removed; use System > Server Config
- A new or updated slave server takes the system settings (System > Main Config) from the master
- Jailkit: the hard link setting of the server applies to all jails and to the jail maintenance, and jails are no longer updated without a change; the nightly bash check of the maintenance no longer fails for every jail and rebuilds it (#7073)
- The jail maintenance waits while the server is processing changes
- Saving the mail server settings keeps the Postfix sender restrictions list; the sender blacklist check of the panel comes before permit_mynetworks again
- Rspamd: the greylisting of a mailbox or forward without its own spam filter policy is applied
- The spam filter policy form has the Rspamd greylisting checkbox again
- PostgreSQL databases: pg_hba.conf of the running PostgreSQL server is used and its configuration is reloaded through PostgreSQL (all distributions)
- The security check counts the admin users only on the master or a single server
- EL: the update keeps the TLS and passive port settings of pure-ftpd.conf
- The package update check of the monitor no longer blocks the cron jobs while apt or dpkg is in use, and a failed check keeps the last result
- Deleting a shell user of a PHP-FPM website no longer restarts PHP-FPM
- The installer uses the Debian 13 configuration for unknown newer Debian versions; Debian testing gets PHP 8.4 paths
- The installer keeps own rules in the local AppArmor override of BIND
- A folder protection user that is moved to another protected folder is removed from the password file of the old folder
- System mails sent through SMTP: a mail that the SMTP server refuses (login, sender, recipient or message) is no longer reported as sent, the answer of the server is written to the log; without an SMTP user no login is sent
- PHP-FPM reload through incron: the incron line reloads the PHP-FPM service of the website's PHP version, and a missing incron service no longer stops the processing of the server
- Commands of the server and of the installers that discard their output now run in the foreground also when sh is dash, so their result is checked
- Postfix: a non-numeric mailbox or message size limit in the server settings no longer stops the mail server configuration
- New installations store the Rspamd Redis passwords under the setting names the panel uses
- The check of the Postfix virtual uid/gid maps setting counts the mailboxes of the server that is edited
- A domain name that can not be converted to its ASCII form (e.g. a leading or trailing hyphen or an empty label) is refused with an error instead of being saved as an empty value
- Correct error texts for the BOSH inactivity time and the Jailkit settings

### Other Improvements

- Cleanup Remote API code (#7069)
- Deleting a mail domain also deletes its mailing lists on the server
- The FTP, WebDAV and shell user limits of clients are checked when the form is opened and saved
- Missing error texts of the FTP user, protected folder and folder user forms were added
- Passwords with a backslash set in the forced password change work for the panel login
- Backup actions started in the panel (backup now, mail restore) show an error when they fail
- A website restore leaves the backup excludes of the website untouched (before: the restore deleted them)
- Failed Borg database backups and restores are reported as failed; a failed database backup no longer moves the whole Borg repository aside
- A remote backup action no longer unmounts the backup directory while a backup runs
- An extension cannot be uninstalled while an installed extension depends on it
- The installer of an extension can stop its install or update
- An extension update removes the files the new version no longer contains
- Mailbox traffic statistics also count Rspamd servers and the rotated mail log; the last day of a month is counted in its own month
- Resellers and clients can switch off CGI, SSI, Perl, Ruby, Python, SuExec, error documents, SSL and Let's Encrypt of a website when their limits allow it
- Renaming a mail domain updates the spam filter settings of the new domain name and keeps its policy when the form sends none
- FTP users and protected folders cannot be moved to a website on another server
- The cron job limit of resellers is checked when a cron job is added
- Deleting a client or reseller also deletes its WebDAV users, mail transports, spam filter policies and protected folders
- The check before removing a server from the server list of a client counts all websites, DNS zones, databases and mail domains of the client (before: only the records the client created itself)
- Chrooted Apache/nginx: the website user is changed and deleted in the chroot too
- Restoring a website backup in a 7z format as the website user works like the other formats
- Mail backup actions unmount a mounted backup directory again
- Website changes reload Apache (graceful) and nginx instead of restarting them, running requests are no longer cut off
- Installer and updater commands on Debian and Ubuntu report failures in the install log
- Cron jobs with a step on a start value (e.g. minute 5/15) are written in a form cron accepts
- The DNS zone import keeps parentheses, semicolons and blanks inside quoted TXT data and reads records written over several lines
- Full names typed without trailing dot in a DNS record of the zone are stored as absolute names (the panel no longer appends the zone again)
- IP addresses are refused as targets of CNAME, DNAME, ALIAS, MX, NS, PTR and SRV records and as primary name server of a zone
- The size of a mail filter is labelled in MB, and a size that is not a number is refused
- The SSH key field of shell users accepts only public keys (one per line, with options and comment lines)
- Unlocking a client or reseller switches on only the records the lock switched off
- Remote API client functions: assignment IDs for additional templates, fields set by a master template, form defaults for new clients, the login check and country of client_login_get (see docs/Remote_API_changes.md)
- Mail log views and the mail statistics use the systemd journal when there is no mail log file
- The hourly mailbox login statistics read only the new mail log lines and store the last access with hour precision
- Remote actions that no server plugin handles are shown as error instead of done
- Failed firewall commands are logged as warning; firewall changes no longer wait one second per port
- The OS update from the panel runs without questions, keeps changed configuration files and reports a failure
- Remote actions that ended with a warning or error are deleted after 30 days
- The metrics dashlet shows the data of the panel server and names it
- The PDNS Tupa import was removed
- Support messages send their mails only after the message was saved; all admin users see the messages to the administrators
- Vhost subdomains and alias domains cannot be switched off in the system settings while such websites exist
- A server cannot be deleted while records use it; deleting a server also removes its firewall, PHP version and IP mapping records
- An IP address cannot be deleted while a website of the server uses it (remote API: see docs/Remote_API_changes.md)
- The backup list shows a backup as encrypted only for the formats that use the backup password (zip, rar, 7z)
- The backup defaults of the server settings form match the values of a new installation
- New FTP users created by an admin have unlimited file quota, ratios and bandwidths by default
- Mailboxes in mdbox format work on Debian 13 (Dovecot 2.4); run the update with "reconfigure services"
- Redirect types of the other web server (e.g. after a change from nginx to Apache) give a valid vhost
- The IPv6 prefix of mirror servers keeps the host part of compressed IPv6 addresses
- Finished remote actions are never run again, also after the action counter file of a server was lost
- Monitor data of services that are no longer monitored is removed after 2 days
- The quota dashlets of a client show only the client's own websites, mailboxes and databases
- A database of a client with a database quota limit always needs a quota
- Databases of a reseller's clients count against the database quota of the reseller also when they are added
- Databases with unlimited quota no longer lower the free database quota of a client
- Deleting a database user writes one delete entry for all servers; moving an alias domain to another website updates the old website correctly
- Deleting a website also removes its manual web backups
- A vhost subdomain or alias domain moved to another website takes its folder along, the old website is protected again; the new website must be on the same server
- Database restores set the definer of views, triggers and routines to the database user of the database
- Mail filters, autoresponder and quota work for mailboxes with a mail path other than /var/vmail/<domain>/<user> (Dovecot 2.3 and 2.4); run the update with "reconfigure services"
- The PowerDNS database is created with the MySQL admin account
- New installations limit the message size to 50 MB
- `ispc resync` without server ID resyncs all servers of a multiserver setup; the help lists the server ID option
- The ISPConfig mail import reads aliases, catch-alls and all domains correctly, does not duplicate filter rules and logs out of the remote server
- The link in support message mails carries the panel port
- RP, DS, SSHFP, LOC and HINFO records are checked for their structure, also for admins; CAA options must match completely
- Backups and restores of encrypted zip, rar and 7z formats work with any character in the backup password
- A vhost subdomain or alias domain moved to another website no longer leaves its log folder mounted in the old website
- A client change of a website with a website path without the client ID changes the group of the website files and of the website user
- A client change of a website moves its FTP and shell users, cron jobs, child domains and databases after the website, the new document root no longer ends up as a _bak folder; this also works for a client change in the domain module
- Admins can unlock a second factor locked by too many wrong codes (checkbox in the user form; also reset by a new password or a 2FA type change)
- Switching on the domain module keeps existing domain list entries
- A name server or mailbox without dots in the SOA form is a name in the zone (ns1 becomes ns1.<zone>.)
- Database backup folders on servers without the website user stay owned by root, without a warning
- A failing server plugin no longer stops the server run: the change stays queued and is retried, the error names the plugin, and remote actions and service restarts still run
- A server module or plugin that can not be loaded (e.g. a broken extension) pauses the processing of changes, remote actions (also disabling the extension in the panel) still run
- Changes that can not be read are skipped with an error in the system log; on slaves a change is only marked as done after it was applied
- The cron jobs of a website get the cron type of the new client when the website is moved to another client
- Saving the server settings no longer switches on the Postfix stress adaptive mode and the PHP-FPM incron reload
- Mailbox CSV import addon: duplicates are no longer imported, passwords are hashed like in the panel and not shown in the result
- Remote API database user, mail, DNS and web domain functions: see docs/Remote_API_changes.md
- Remote API sites, mail backup and quota functions: see docs/Remote_API_changes.md
- Switching a server service on or off in System > Server Services links or unlinks its module and all of its plugins; run ispconfig_update.sh with "reconfigure services" to configure the services of a newly enabled role. The server applies further changes in its next run
- Jailkit: the [php] section uses the PHP version of the system, new section [php8_5]
- Unused server files (cron_daily, mod_mail_base, the old jailkit scripts, ...) were removed, the update deletes them
- Mailbox CSV import addon: the first line is skipped only when it is a header, invalid addresses are refused and a mail domain is only created together with an imported mailbox
- WordPress addon: the database and user name schemes must contain [ID]
- Remote API spam filter policy functions: see docs/Remote_API_changes.md
- EL: a new installation enables the configured services at boot
- Remote API server_config_set and system_config_set: see docs/Remote_API_changes.md
- The system log shows a warning when the disk quota of a website could not be set or when getmail is not installed for Fetchmail accounts
- The rkhunter report of the monitor shows the error messages of rkhunter
- Only admins can switch a website from the PHP-FPM socket to a TCP port; the update lists the websites that use a TCP port
- The option "Resellers can use the option-tab for websites" shows a note that it is meant for trusted resellers only
- Changing the own password or second factor in the user settings and the mail user password page needs the current password
- Panel sessions end when the user was deleted, deactivated or got a new password; mail users logged in during the update have to log in once again
- Remote API login without "Remote Access": only from this server; with "Remote Access" the address list decides (see docs/Remote_API_changes.md)
- Renaming a MySQL database moves all tables, sequences, routines and events and keeps the old database when something could not be moved
- Renaming a DNSSEC zone removes the keys of the old zone name
- Protected folders: the update gives protected folders owned by root to the website user; the server no longer changes the owner of a protected folder
- Jailkit shell users: the website root no longer gets an .ssh/authorized_keys file for them; existing copies can be deleted
- MySQL: a database user whose password can not be set is removed again; check for database accounts without password left by older versions
- Directive snippets need the security setting admin_allow_server_config, like System > Server config
- Secondary DNS zones: clients and resellers can use only public IP addresses as primary server
- Added an end-to-end test framework in tests/ with Docker test containers. The PHP error reporting level of the control panel and the server scripts can now be set with $conf['error_reporting'] in config.inc.local.php (#7081)

Please see changelog for a full list of features and bugfixes:

https://git.ispconfig.org/ispconfig/ispconfig3/-/milestones/102

---

## ISPConfig 3.3.2p1 Released

This is a patch release that fixes bugs discovered after the 3.3.2 release.

## What's new in ISPConfig 3.3.2p1?

### Bugfixes

- Fixed rspamd not starting after an update to ISPConfig 3.3.2 with reconfiguration of services. The update renames the no longer used /etc/rspamd/local.d/users.conf, but the include directive for that file was only removed from /etc/rspamd/rspamd.conf when it ended with a line break. Older ISPConfig versions appended the directive without one, so on most servers it stayed in place and pointed to a file that no longer exists. The directive is now removed regardless of how it was written. Servers that are already affected are repaired by this update, a manually restored users.conf can be removed afterwards (#7054)
- Fixed the hard disk quota monitoring reading the wrong column of the repquota output for a website whose disk soft limit is exceeded. repquota prints a grace time behind the block limits in that case, which shifts the number of files one column to the right. The monitoring stored the grace time instead of the number of files and, on servers with more than one quota enabled filesystem, aborted the whole ISPConfig cron run with "Unsupported operand types: string + string" on PHP 8 (#7053)
- Fixed the ISPConfig update not adding the pid column to the sys_cron table on MySQL and on MariaDB versions older than 10.0.2, as the SQL statement used ADD COLUMN IF NOT EXISTS, which only MariaDB supports (#7055)
- Fixed database users not being created on MariaDB older than 10.1.3 and MySQL older than 5.7.8, which do not support CREATE USER IF NOT EXISTS. These versions use the previous behaviour again. Changing the name or password of a database user is now only applied on the servers that host a database of that user (#7056)
- Fixed mailboxes, email aliases, email forwards and catchalls being created on the wrong server when the same mail domain exists on more than one mail server. The forms now identify the selected mail domain by its ID instead of its name and show the server name for domains that exist on several servers (#7057)

Please see changelog for a full list of features and bugfixes:

https://git.ispconfig.org/ispconfig/ispconfig3/-/milestones/101

---

## ISPConfig 3.3.2 Released

This release adds support for Ubuntu 26.04, an option to enforce inbound DMARC rules, a separate sender address for system mails, an interface for extensions to add their own client and reseller limits, and fixes a number of bugs reported after the 3.3.1p1 release.

A privilege escalation security vulnerability has been found in the Fetchmail function of the Email module. This issue has been fixed in ISPConfig 3.3.2. We thank Arvin Shivram of Brutecat Security for reporting the issue to us (#7052).

A SQL injection vulnerability has been found in the update and delete functions of the remote API, which allowed a remote API user to modify or delete records beyond their permissions. This issue has been fixed in ISPConfig 3.3.2. We thank Nguyen Chi Quang from MBBank for reporting the issue to us (#7051).

## What's new in ISPConfig 3.3.2?

### Ubuntu 26.04 Support

ISPConfig 3.3.2 adds support for Ubuntu 26.04 LTS, including the Dovecot 2.4 configuration syntax used by that release (#6996).

### Inbound DMARC Enforcement

A new option allows to enforce inbound DMARC rules in rspamd, so that incoming mail is rejected or quarantined according to the DMARC policy published by the sending domain (#6995).

### Separate Sender Address for System Mails

The e-mail address of the administrator was used as sender address and as recipient address for system mails at the same time. This caused problems with SPF when the mailbox of the administrator is hosted on a different server, as the ISPConfig server had to send mails using an address of a domain that it does not host.

The setting has been split into two fields in System > Main Config > Mail:

- **Administrator's contact e-mail** (`admin_mail`) is the recipient of system notifications and is used as reply address.
- **Server sender e-mail address** (`server_sender_mail`) is the address that system mails are sent from.

This affects notification mails like traffic and quota mails, monitoring notifications, OTP and password reset mails, the welcome mails for clients and resellers, and support messages. Custom mail templates in `conf-custom/mail/` that use their own sender address are not changed.

The update sets the new field to the current administrator e-mail address, so the behaviour of existing installations does not change until a different sender address is configured (#7028).

### Extensible Client and Reseller Limits

Extensions can now register additional client and reseller limits without patching core files. A new limits registry makes the limit fields available in the client and reseller forms and in the client templates (#7019).

### Updated CA List for CAA Records

The list of certificate authorities offered for CAA DNS records has been updated to reflect the current trust landscape. Former CAs were removed, CAs that merged or changed their name were updated and new CAs were added (#7017).

### Database Backups Without Table Locks

mysqldump locks all tables of a database while it dumps them, so a website can become unresponsive for as long as its database backup runs. A new setting in System > Server Config > Server controls whether the backup is made with `--single-transaction` instead, which does not lock the database.

The setting defaults to **Automatic**. In this mode ISPConfig looks at the storage engines of the database and dumps it without table locks when all of its tables use a transactional engine such as InnoDB. A database that contains MyISAM or MEMORY tables is still dumped with table locks, because a dump taken without locks is not consistent for those engines. **Yes** always dumps without table locks, which is the right choice for a mixed database whose availability matters more than the consistency of its non transactional tables. **No** keeps the behaviour of earlier releases (#7049).

### Custom Error Pages Disabled by Default

Custom error pages are now disabled by default for newly created websites. Existing websites are not changed by the update (#7021).

### Bugfixes

- Fixed the password reset link in the password reset e-mail being built from the Host header of the request, which allowed an attacker to send a reset link pointing to a host under their control to the user. The link is now built from the interface_base_url setting in interface/lib/config.inc.php if set, otherwise from the hostname of the server that runs the interface. If the panel is reached under a different hostname than the server hostname, set interface_base_url accordingly (#7044)
- Fixes from the code audit by siteguardian.io (#7044): the user type scope (any/user/admin) of entries in the IDS whitelist and htmlfield files is now enforced, it was ignored before. If you use a custom whitelist (security/ids.whitelist.custom), check that entries for fields that resellers can edit use the user scope. CSRF tokens are now required for backup actions, DNS zone import, extension installation and management, and the vpopmail import. TLS certificate verification is no longer disabled when downloading extensions and APS packages. The session ID is regenerated on login unless session_regenerate_id is set to no in security_settings.ini. Password hashes and CSRF tokens are compared in constant time, the CSRF token timeout is enforced for form submits, e-mail headers are protected against CRLF injection, shell arguments in the PowerDNS DNSSEC, certbot and PostgreSQL size commands are escaped, the APS package extraction rejects paths outside the target directory, and unserialize() calls no longer allow objects. The stale interface/web/remote/monitor.php file from versions before 3.2 is removed by the updater
- Fixed the client select field of the website, mail domain, mailing list, XMPP domain, DNS zone, secondary DNS zone, database user, client domain and OpenVZ virtual machine forms falling back to the first entry of the list when the form was redisplayed after a validation error. For a reseller the first entry is the reseller himself, so correcting the reported error and saving again handed the record over to the reseller and, in case of a website, moved the site to a different directory. The field now keeps the client that was selected, or the current owner of the record if the selection can not be determined. A reseller can now only assign a record to himself or to one of his sub clients, other client groups sent with the form are ignored and logged (#7048)
- Fixed resellers not being offered the additional PHP versions of the selected client in the website form, and the sort priority of PHP versions being ignored for resellers. PHP versions with the same sort priority are now listed with the most recently added version first, so that a new website defaults to the newest PHP version unless the sort priority says otherwise
- Fixed BIND not being able to write the zone files of secondary DNS zones on Ubuntu 24.04 and other systems with AppArmor, as the installer did not detect AppArmor when the apparmor_status command is not available and did not reload the BIND AppArmor profile after adding the rules for the slave zone directory. The rules now also allow file locking. The fix is applied by the ISPConfig update
- Fixed a privilege escalation vulnerability in the Fetchmail function of the Email module. The values of a Fetchmail account were written into the getmail configuration file without validation, which allowed a client to inject additional configuration sections through line breaks in the account fields. Line breaks and null bytes are now removed from the values, the destination has to be a valid e-mail address, and the getmail plugin refuses to write or delete a configuration file that is a symlink or resolves to a path outside the getmail configuration directory (#7052)
- Fixed a SQL injection vulnerability in the remote API. The record ID passed to the update and delete functions of the API was used in the SQL query without validation, which allowed a remote API user with permission for an update or delete function to modify or delete records beyond that permission and to read data from other tables. The ID is now required to be a positive integer and the affected queries use parameter placeholders (#7051)
- Fixed configuration values containing backslashes (e.g. the SMTP password in System > Main Config > Mail) losing one backslash each time an unrelated configuration tab was saved. The sections that are not being edited were unescaped when read and written back without re-escaping. Values set through the remote API system_config_set and server_config_set functions are now escaped in the same way as values saved through the interface (#7042)
- Fixed PHP warnings "Trying to access array offset on value of type bool" and invalid width/height CSS on the login and main pages when the custom panel logo is an SVG image or can not be parsed. The logo now falls back to the stylesheet dimensions (#7039)
- Fixed the "more" button of the donation dashlet reacting to every button on the dashboard, including the logout button and the close buttons of info messages. The dashlet now uses a plain HTML disclosure element without JavaScript (#7043)
- Fixed an internal cron job never being executed again when a cron run was aborted while the job was running. The job is now released as soon as the cron run that started it is gone, instead of staying marked as running for up to a day. Cron jobs can declare a maximum expected run time, which is used when the process that started the job is not known (#7034)
- Fixed the SSH key pair generation for a client failing with "Data too long for column ssh_rsa" when the domain or user name used in the key comment is long, as the public key of a 3072 bit RSA key with a long comment exceeds 600 characters. The column is now a text column. The database_password_sha2 column of database users, which was exactly as long as the generated hash, has been widened to 255 characters as pre-hashed values passed through the remote API can be longer (#7074)
- Fixed the owner of an existing .htaccess file being changed to root:root when a folder protection is deleted or set to inactive. The file now keeps the system user and group of the website (#7035)
- Fixed the rspamd settings file of a mailbox or forwarding not being regenerated when its greylisting setting is changed, so that disabling greylisting had no effect until the next resync (#7027)
- Fixed traffic quota not being enforced when the quota is set to 0, which could be used to bypass the client traffic limit and the automatic deactivation of overtraffic websites (#7024)
- Fixed uncaught DivisionByZeroError when opening the website traffic statistics on PHP 8.x (#7023)
- Fixed undefined $php_fpm_reload_mode in the nginx plugin, which aborted the PHP-FPM reload when a website was deleted (#7022)
- Fixed broken installation of the pureftpd_sni_plugin.inc.php plugin (#7020)
- Fixed false warning "PHP cli binary is not available in the jail" when PHP is provided by the global jailkit configuration (#7018)
- Fixed grant_master_database_rights silently failing on a master server (#7016). The fix in the development version aborted the update of a single server with "Unable to get the user rights" when the master database permissions were reconfigured, because a single server has no slave server users. An empty user list is now handled as the normal case and only a database error aborts the update
- Fixed PHP fatal error after a deb.sury.org PHP upgrade when the IDS temp folder became read-only (#7010)
- Fixed email routing error when adding routing for an email domain in multiserver setups (#7009)
- Removed the stale interface/lib/config.inc.php file from the repository (#7007)
- Fixed TypeError when sending a second mail from a cronjob (#7003)
- Fixed admin not receiving notifications for failed nightly backups (#7002)
- Fixed PHP fatal error (TypeError) in nginx_plugin.inc.php and apache2_plugin.inc.php (#7000)
- Fixed shell_user_update being triggered before the web_domain record was replicated, which resulted in an outdated configuration on secondary servers (#6997)
- Fixed invalid Sieve syntax when using Subject as source together with the domain or localpart operator (#7011)
- Migrated rspamd user settings to follow the rspamd configuration best practices (#7006)
- Fixed the sender address of the reseller welcome mail, which was empty because the mail section of the global config was not read (#7028)
- Fixed a malformed From header in notification mails that use a sender name in the mail template (#7028)

### Other Improvements

- Added a commandline option to ispconfig_update.sh to update to a specific branch beside develop
- Improved acme.sh handling for local loopback addresses, improved acme.sh logging in the installer and added a curl fallback to download acme.sh
- Added the systemd override for the ISPConfig temp dir to the Apache systemd unit as well
- Avoid errors when the ISPConfig log directory does not exist yet
- Improved getmail input field validation
- Mailbox soft-delete values are automatically converted from y/n to the numeric values used by the new configuration

Please see changelog for a full list of features and bugfixes:

https://git.ispconfig.org/ispconfig/ispconfig3/-/milestones/99

---

## ISPConfig 3.3.1p1 Released

This is a patch release that fixes several bugs discovered after the 3.3.1 release, including Debian 13 PHP socket issues, Rspamd spam header handling, MySQL 8.0.45 compatibility, and various other improvements.

## What's new in ISPConfig 3.3.1p1?

### Bugfixes

- Fixed Debian 13 PHP socket issue in apps vhost and PHP-FPM pools (#6983)
- Fixed Rspamd X-Spam-Status header not being added when using "Rewrite Subject" spam tag method, which caused spam to be forwarded via CC/redirect rules (#6979)
- Fixed Apache error.log rotation causing logs to not being written after rotation (#6992)
- Fixed phpMyAdmin link not showing in database list (#6981)
- Fixed SimplePie PHP 8 compatibility for RSS feeds (#6982)
- Fixed client creation via API failing with usertheme_syntax_incorrect error (#6990)
- Fixed mail user login field not being updated when renaming mailbox (#6989)
- Fixed Dovecot last_access log parsing pattern for Debian 13/Dovecot 2.4 (#6994)
- Fixed vmail user permissions to dovecot-sql.conf for Debian 13 (#6976)
- Fixed stale content.php file causing errors (#6974)
- Fixed system_update warning remaining after disabling the Check for Linux updates feature (#6896)
- Fixed harddisk storage monitoring trigger values (#6978)
- Cleaned up bouncing space in postfix config (#6985)
- Added missing disablereplicator column to mail_user table (#6993)

### New Features

- Added support for MySQL 8.0.45 (#6991)
- Added support for extended RBL syntax for Spamhaus RBL (#6977)
- Added support for per-domain mail relaying without username/password (#6877)
- Added support for RHEL 10 postfix without hash map type (#6980)

Please see changelog for a full list of features and bugfixes:

https://git.ispconfig.org/ispconfig/ispconfig3/-/milestones/100

---

## ISPConfig 3.3.1 Released

This version brings Debian 13 support with Dovecot 2.4 compatibility, RHEL 10 based distribution support (AlmaLinux 10, RockyLinux 10), PHP 8.5 compatibility, pgAdmin for PostgreSQL databases, improved DNS validation, and many bugfixes. It also fixes 3 security issues.

## What's new in ISPConfig 3.3.1?

### Debian 13 Support

ISPConfig 3.3.1 adds full support for Debian 13 (Trixie), including compatibility with Dovecot 2.4 which introduces an incompatible configuration language. The Dovecot configuration templates have been updated to work with the new 2.4 syntax.

### RHEL 10 Based Distribution Support

Support has been added for RHEL 10 based distributions including AlmaLinux 10 and RockyLinux 10.

### PHP 8.5 Compatibility

ISPConfig is now compatible with PHP 8.5. This includes fixes for deprecated functions like `mysqli_ping()` and non-canonical casts.

### pgAdmin for PostgreSQL Databases

A pgAdmin link has been added for PostgreSQL databases, similar to how phpMyAdmin works for MySQL/MariaDB databases. The phpMyAdmin link is now correctly hidden for PostgreSQL databases.

### DNS Record Validation Improvements

Improved validation for DNS records including better CNAME conflict detection, SRV record field validation, and DMARC record handling.

### Rspamd Greylisting Fixes

Fixed issues where rspamd greylisting settings from spamfilter policies were not being applied correctly to domain-level spam filter entries and user configurations.

### Let's Encrypt Improvements

- Removed OCSP stapling sections from vhosts as Let's Encrypt no longer supports OCSP
- Fixed default CA setting when acme.sh is installed from the Let's Encrypt class

### Extended CLI Resync Functionality

The Tools > Resync function has been extended in the ispc CLI command, allowing more flexible server synchronization from the command line.

### Improved Autoinstall Updates

Improved updating with autoinstall.conf.php including better documentation and the ability to pass --autoinstall option from ispconfig_update.sh and ispc update to update.php.

### Improved website logfile permissions

Website logfiles are now created with stricter permissions (640) and ownership (root:clientX).

### Security Fixes

This release addresses three security vulnerabilities that could allow privilege escalation under certain conditions. The issues affect theme handling, backup restoration, and backup download functionality. We strongly recommend all users to update to this version as soon as possible.

We would like to thank **SSD Secure Disclosure** for responsibly discovering and reporting these vulnerabilities.

### Backup System Changes

- Removed zip and rar archive formats from rootgz backup mode as they do not preserve file ownership. These formats will automatically fall back to tar_gzip when selected with rootgz mode. The zip and rar mode will stay available for userzip mode.

### Bugfixes & Minor Features

- Fixed DKIM config bug in amavis that could cause DKIM entries to be lost
- Fixed PowerDNS records not being created when domain is inactive
- Fixed PHP 8.3 compatibility issues
- Fixed false positive "Possible attack detected" for valid Nginx directive snippets
- Fixed trailing space in nginx vhost server_name property
- Fixed data cleanup when server is deleted (monitor_data and server_ip)
- Fixed sysdatalog processing with incorrect unixtime values
- Improved useragent for cronjobs (wget)
- Silenced z_php_fpm_incron_reload_plugin warnings when no PHP version is set
- Fixed CAA DNS entry name handling with TLD
- Improved email filter regex syntax validation
- Fixed stats/.htaccess file permissions
- Added more plugin events for interface plugins

Please see changelog for a full list of features and bugfixes:

https://git.ispconfig.org/ispconfig/ispconfig3/-/milestones/95

## Known issues

Please take a look at the bug tracker:

https://git.ispconfig.org/ispconfig/ispconfig3/-/issues?scope=all&utf8=%E2%9C%93&state=opened&label_name[]=Bug

You can report bugs at https://git.ispconfig.org/ispconfig/ispconfig3/issues

## Supported Linux distributions

- Debian 11 – 13 (recommended) and Debian testing
- Ubuntu 22.04 LTS – 26.04 LTS (recommended)
- AlmaLinux 8 – 10
- RockyLinux 8 – 10
- CentOS 8

## Download ISPConfig 3.3.2

https://www.ispconfig.org/downloads/ISPConfig-3.3.2.tar.gz

The installation instructions for ISPConfig can be found here:

https://www.ispconfig.org/ispconfig-3/documentation/

## How can I update to ISPConfig 3.3.2?

Run the following commands as root user on your ISPConfig server:

```
cd /tmp
wget https://www.ispconfig.org/downloads/ISPConfig-3.3.2.tar.gz
tar xvfz ISPConfig-3.3.2.tar.gz
cd ispconfig3_install/install
php -q update.php
```
