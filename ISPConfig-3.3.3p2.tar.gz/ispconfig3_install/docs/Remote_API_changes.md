# Remote API changes

This file lists the changes of the ISPConfig remote API (SOAP and JSON) that callers may notice: values that
are accepted or refused, results, permissions, error messages and side effects. New functions are listed in
the release notes.

Validation errors of add and update functions are returned as a `data_processing_error` fault with the
English text of the field's error message, for example `Invalid value for the field server_php_id.`.

## ISPConfig 3.3.3p2

- All add functions: an empty value of a select or radio field without an empty option (for example `ssl_country`
  of a website) is handled like a field that is not sent (3.3.3: refused with `Invalid value for the field
  <field>.`).
- All update functions: the plugins that run after the update see the stored record together with the sent fields.
  An update that sends only some fields no longer has side effects of the missing ones; for example
  `mail_domain_update` without `domain` renamed every mailbox, forward and mailing list of the domain to
  `<local part>@` (before: only callers that sent the whole record were safe).
- The examples in `remoting_client/examples` were rewritten for 3.3.3 and cover every function, each with a SOAP
  and a JSON example; the documentation in `remoting_client/API-docs` is generated from them as Markdown
  (`remoting_client/API-docs/README.md`, one page per function). The old HTML pages and `rest_example.php` are
  removed.
- `openvz_get_free_ip`: without a free address the fault `no_free_ip` is returned (before: a PHP error and no
  valid answer).
- `dns_zone_set_dnssec`: when `client_id` gives the zone another owner, the records of the zone get that owner
  too, like with `dns_zone_update` (before: the records stayed with the previous owner; remote API v1 keeps that).
- `mail_relay_domain_add`, `mail_relay_domain_update`: a relay domain that exists already on the server is
  refused with `domain_error_unique` (before: `database_error` with the failed query).
- `sites_aps_get_package_details`, `sites_aps_get_package_settings`, `sites_aps_get_package_file`: the answer is
  for the newest version of the package, like the panel shows it (before: the given version; remote API v1 keeps
  that). Text that is already UTF-8 is no longer encoded a second time.
- `sites_aps_install_package`: `main_domain` = `www.<domain>` installs into the website `<domain>` with the
  subdomain www (before: always refused with `error_main_domain`). Like in the panel, `main_domain` must be a
  website, vhost subdomain or vhost alias domain with a document root (before: any web domain record).
- `sites_aps_install_package`: the database user of the instance also works with MySQL 8 (before: the query for
  its password hash failed there).
- `sites_aps_instance_delete`: `keep_database` also takes 1, '1', 'y', 'yes' and 'true' (before: only boolean
  true kept the database; any other value deleted it).
- `sites_aps_update_package_list`: an error of the package crawler is returned as the fault `package_error`
  (before: the HTML error page of the panel).
- `sites_web_domain_update`, `sites_web_vhost_aliasdomain_update`, `sites_web_vhost_subdomain_update`:
  `log_retention`, `pm_max_children`, `pm_start_servers`, `pm_min_spare_servers` and `pm_max_spare_servers` keep
  their stored values when they are not sent; a value sent empty still gets the default (before: a value that was
  not sent was reset to 30, 10, 2, 1 and 5; remote API v1 keeps that).
- The get, update and delete functions of mail aliases, forwards, catchalls, alias domains, whitelist and
  blacklist entries act on records of their own type only: `-1` and filters return only that type, the ID of
  another type returns nothing, and update and delete refuse it with `invalid_id` (before: any record of the
  table, e.g. `mail_alias_delete` deleted a forward; remote API v1 keeps that).
- `mail_domain_delete` deletes the forwards and aliases, fetchmail accounts, mailboxes with their filters,
  spamfilter users with their white- and blacklist entries and the mailing lists of the domain, and
  `mail_user_delete` deletes the spamfilter user, the filters and the fetchmail accounts of the mailbox, like the
  panel (before: only the domain or mailbox record; remote API v1 keeps that).
- `mail_domain_update`: when `client_id` gives the domain another client, the mailboxes, forwards, spamfilter
  users and white- and blacklist entries of the domain get that client too, like in the panel (before: only the
  domain changed its owner unless `client_group_id` was sent as well; remote API v1 keeps that).
- `sites_web_subdomain_*`, `sites_web_vhost_subdomain_*`, `sites_web_vhost_aliasdomain_*`: the record is checked
  with the subdomain or alias domain form of the panel, so a wildcard subdomain such as `*.example.com` is
  accepted and the website-only fields are not part of the vhost subdomain and alias domain records (before: the
  alias domain or website form; a wildcard subdomain was refused; remote API v1 keeps that).
- `sites_web_aliasdomain_add`, `sites_web_subdomain_add`, `sites_web_vhost_aliasdomain_add`,
  `sites_web_vhost_subdomain_add` store their own record type, a sent `type` is ignored. `sites_web_domain_get`
  returns websites only (`-1` lists no child domains, the ID of another type returns nothing). The delete
  functions of websites, alias domains and subdomains and `sites_web_domain_set_status` refuse the ID of another
  record type with `invalid_id` (before: the type was not checked, e.g. `sites_web_aliasdomain_delete` deleted a
  website; remote API v1 keeps that).
- `sites_web_folder_add`, `sites_web_folder_update`: a path that is already protected in the same website is
  refused with `data_processing_error` `error_folder_already_protected_txt`; `sites_web_folder_user_add`,
  `sites_web_folder_user_update`: a user name that exists already in the same folder is refused with
  `error_user_exists_already_txt`, like in the panel (before: the duplicate was stored; remote API v1 keeps that).
- `sites_web_domain_update`, `sites_web_vhost_subdomain_update`, `sites_web_vhost_aliasdomain_update`:
  `apache_directives`, `nginx_directives` and `proxy_directives`, and `sites_web_aliasdomain_update`,
  `sites_web_subdomain_update`: `proxy_directives`, sent with their stored value are kept even when the directive
  check refuses them (e.g. nginx directives of a website on an Apache server); a new or changed value is checked
  as before (3.3.3: the update was refused with `Nginx directive blocked by security settings:` or the Apache
  message).

## ISPConfig 3.3.3

### General

- The REST endpoint `remote/rest.php` is removed (it answered every request with status 400 since it was added). The SOAP endpoint `remote/index.php` and the JSON endpoint `remote/json.php` stay.
- All add and update functions: values of select, radio and checkbox fields must be one of the options of the
  field (static options or the options the panel reads from the database). A value that is already stored in
  the record stays valid on update, fields that are not sent are not checked, checkbox values are compared
  case-insensitively. Other values are refused with `Invalid value for the field <field>.` (before: stored as
  sent). `$conf['remote_api_version'] = 1;` in `config.inc.local.php` restores the old behaviour, the default
  is 2.
- All add and update functions: a value checked by a format pattern (for example user names, database names,
  logins) may no longer end with a line break; before, one trailing line break was accepted and stored.
- All functions that return records: the keys `password`, `passwort`, `database_password`,
  `database_password_sha2`, `database_password_postgres`, `database_password_mongo`, `stats_password`,
  `otp_data`, `otp_recovery`, `lost_password_hash`, `id_rsa` and `remote_password` are left out of the result
  at any depth, and the `*_get` functions refuse a filter on one of these keys (`invalid_filter`).
  `remote_api_password_hashes=yes` in `security_settings.ini` restores the old behaviour.
- Datalog entries of records added through the API now carry the record ID in `dbidx`
  (`<index field>:<id>`, before: the ID was empty).
- `login`: the third parameter `client_login = true` is no longer supported and refused with
  `client_login_failed`; sessions of such logins are refused.
- `login`: remote users whose stored password is an old MD5 hash can no longer log in (`login_failed`). Set a
  new password for them in System > Remote Users; the update lists such users.
- `login`: a login from an address that is not in the allowed IP addresses of the remote user fails with
  `login_failed` / `The login failed. Username or password wrong.` (before: `The login is not allowed from
  <ip>`).
- `login` from the ISPConfig server itself (127.0.0.1 / ::1): a remote user with "Remote Access" on and a list of
  allowed addresses needs `127.0.0.1` and `::1` in that list (before: the server itself was always allowed). Users
  with "Remote Access" off (only from this server) or with an empty list are not affected.
- `login` and calls with an unknown or expired session ID: every attempt is counted, more than 10 attempts
  within 5 minutes from one address give `login_failure_limit`. IPv6 addresses are counted per /64 network,
  a successful login no longer resets the counter. Clients that retry with expired sessions may reach the
  limit earlier.
- All update functions: a password field that is sent with the value stored in the record (the record read
  back with the `*_get` function) keeps the password, it is not hashed again (before: only `client_update`).
- `get_function_list`: leaves out PHP methods starting with `__` such as `__construct`.
- All add and update functions: a domain name or address in a field with IDN conversion that can not be converted
  to ASCII (for example `-bad`, `bad-`, `a..b` or a label longer than 63 characters) is refused with
  `Invalid domain name in the field <field>.` (before: the field was stored empty, e.g. a DNS record name).
- All `*_get` functions with a filter array: `#OFFSET#` and `#LIMIT#` no longer shift the values of the column
  filters after them (before: a filter like `#OFFSET#`, `#LIMIT#`, `username` returned no record).
- All endpoints: request bodies above 2 MB are refused (SOAP fault `The request is too large`, JSON code
  `invalid_data`). A gzip or deflate compressed SOAP request counts by its unpacked size.

### Clients

- `client_login_get`: limits the attempts per `remote_ip` (more than 6 within 1 minute) and per user name
  (more than 10 within 5 minutes), both with `error_user_too_many_logins`; successful logins are not counted.
  Users with an old MD5 password hash are refused. A mail user login (user name with `@`) with a wrong
  password or an unknown address returns `false` (before: `null`).
- `client_add`, `client_update`, `client_template_additional_add`: each entry of `template_additional` must be
  an additional client template or a template that is already assigned to the client.
- `client_add`, `client_update`: `country` is converted to upper case and must be a code of the country list
  or empty; `default_xmppserver` and `xmpp_servers` must be XMPP servers.
- `client_add`: without `limit_cron_type` the client gets `url` (before: the call failed with `Data truncated for
  column 'limit_cron_type'`).
- `client_update`: the additional templates of the client are only changed when `template_additional` is sent
  (before: every update without it removed the assigned templates), and only after the record was validated
  (before: a refused update changed them anyway).
- `client_update`: without `password` the stored password stays (before: the stored hash was hashed again, the
  client could no longer log in).
- `client_update`: a `password` equal to the stored hash (the record read back with `client_get`) keeps the
  password (before: the hash was hashed again).
- `client_update`: `locked` and `canceled` lock/unlock and cancel the client only when the value differs from the
  stored one (before: every update with these keys ran the lock or unlock again, e.g. websites the admin had
  switched off were switched on).
- `client_template_additional_get`, `_add`, `_delete`: invalid IDs return the faults `invalid_id`,
  `invalid_client_id` and `invalid_template_id` (before: a PHP error and no valid answer).
- `client_delete_everything`: needs the permissions for `client_delete_everything` and `client_delete`; a
  missing permission is reported before anything is deleted (before: the records were deleted first). The
  group of the deleted client is removed from its reseller.
- `client_change_password`: a password with a backslash is hashed as the panel login checks it, so the client
  can log in (before: the login failed).
- `client_delete_everything`: also deletes the WebDAV users, mail transports, spam filter
  policies, protected folders and folder users of the client.
- `client_login_get`: users whose panel login is deactivated (`sys_user.active` not 1; for an email login the
  panel user of the client) are refused like in the panel login. `country` is the country of the client
  (before: always `de`), users without client keep `de`.
- `client_template_additional_delete`: `assigned_template_id` is the ID of the assignment
  (`client_template_assigned.assigned_template_id`, the number before the colon in the client's `template_additional`
  entries), so one of two assignments of the same template can be removed (before: the template ID).
  `$conf['remote_api_version'] = 1;` restores the old behaviour.
- `client_update`: for a client with a master template (`template_master` > 0), a changed value of a field the
  template sets is refused with `data_processing_error` (before: accepted and overwritten by the template later);
  unchanged values pass. `$conf['remote_api_version'] = 1;` restores the old behaviour.
- `client_add`: omitted checkbox fields (e.g. `force_suexec` and the feature switches) and default servers get the
  default of the panel form, as when the client is added in the panel; omitted limits stay 0.
  `$conf['remote_api_version'] = 1;` restores the old behaviour.
- `client_get_all`: returns an empty array when there are no clients (before: `false`).
  `$conf['remote_api_version'] = 1;` restores the old behaviour.
- `client_add`, `client_update`: with `_ispconfig_pw_crypted = 1`, a client or reseller password hash that PHP
  `crypt()` can not verify is refused with `data_processing_error` (such a hash never allowed a login).
- `domains_domain_delete`, `domains_domain_update`: a domain of the domain module that is used by a DNS zone,
  secondary zone, mail domain or website (also as parent of a subdomain) can not be deleted or renamed
  (`domain_in_use` fault, as in the panel); an unused entry can still be renamed.
  `$conf['remote_api_version'] = 1;` restores the old behaviour.

### Websites

- `sites_web_domain_*`, `sites_web_vhost_subdomain_*`, `sites_web_vhost_aliasdomain_*` (add and update):
  - `apache_directives`, `nginx_directives` and `proxy_directives` are checked against the lists of blocked
    directives in more cases (quoted directives, continued Apache lines, several nginx directives on one line,
    `TransferLog`, `RewriteMap`, `${...}`, nginx `include`, `error_log`, `access_log` other than `off`, and the
    nginx temp path directives such as `client_body_temp_path`). A missing or unreadable list blocks all
    directives. The blocked lines in the error message are HTML-escaped.
  - `ip_address` must be `*` (when the IP wildcard is enabled for the server) or an IPv4 address of the
    server with "HTTP NameVirtualHost", `ipv6_address` empty or such an IPv6 address; subdomains and alias
    domains may use the IP of their website. `server_php_id` must be 0 or an active PHP version of the server
    for the PHP mode of the website that the client may use. `parent_domain_id` of a website must be 0.
  - `ssl_domain` must be a host name, optionally starting with `*.`.
  - `domain` (also of subdomains and alias domains) must consist of labels: empty labels such as `a..b.com` or
    `.b.com` are refused. `web_folder` of a subdomain or alias domain may have 1 character, but not `.`.
  - `web_folder` of a subdomain or alias domain must start with a letter, a digit, `_`, `.` or `-`.
  - `domain`, `redirect_path` and `web_folder` may not end with a line break.
  - `document_root` must be an absolute path without a `..` segment, `allow_override` an AllowOverride value
    (letters, digits, `=`, `,` and spaces), `php_open_basedir` empty or absolute paths separated by `:` (also `*`).
    A stored value that does not match is accepted when it is sent back unchanged (an update with the whole
    record keeps working).
  - When `client_group_id` changes the owner, `sys_userid` of the record is set to the user of the API session.
- `custom_php_ini` of websites, subdomains and alias domains: lines whose key is empty or contains other
  characters than letters, digits, `.` and `_` are not written into the PHP-FPM pool (a warning is logged on the
  server); the panel refuses such lines.
- `sites_web_vhost_subdomain_add` and `sites_web_vhost_aliasdomain_add`: the record gets the document root,
  system user and system group of its website (before: `-`), as in the panel.
- `sites_web_domain_delete`, `sites_web_vhost_subdomain_delete`, `sites_web_vhost_aliasdomain_delete`: deleting
  a website also deletes its subdomains and alias domains, FTP, shell and WebDAV users, cron jobs, backups,
  APS instances, protected folders and their users and its traffic statistics, and unlinks its databases
  (`parent_domain_id = 0`), as in the panel. Deleting a subdomain or alias domain deletes its protected folders.
- `sites_web_domain_update` with a new `domain`: only the subdomains and alias domains of this website are
  renamed, the traffic statistics move to the new names.
- Websites with Let's Encrypt and automatic CAA records: the CAA record is only created in a DNS zone of the
  website's owner.
- `sites_webdav_user_add`, `sites_webdav_user_update`: the password is stored as the digest the panel uses, so
  the user can log in. Callers that send the digest already must also send `_ispconfig_pw_crypted=1`.
- `sites_database_user_add`, `sites_database_user_update`: `server_id` 0 (all database servers) is accepted.
- `ftptrafficquota_data`: the FTP traffic of the pure-ftpd log is counted once (before: it could be counted
  several times).
- `sites_web_domain_add`, `sites_web_vhost_subdomain_add`, `sites_web_vhost_aliasdomain_add`: without
  `php_fpm_use_socket` the website uses the PHP-FPM socket (`y`, as in the panel; before: `n`, a TCP port).
- `ftptrafficquota_data`: returns the FTP traffic of `this_month`, `this_year`, `last_month`, `last_year` and
  `lastdays` (before: the values were always empty).
- `databasequota_get_by_user`: `used_raw` is the size of the database on its own server (before: the size of
  a database with the same name on another server could be returned).
- `databasequota_get_by_user`: `database_quota_raw` and `used_percentage` use MB × 1024 × 1024, the unit the
  servers use for the quota check (before: MB × 1000 × 1000).
- `trafficquota_get_by_user`, `ftptrafficquota_data`: every website has the keys `this_month`, `this_year`,
  `last_month`, `last_year` (and `lastdays` when requested), 0 for a period without traffic (before: the key
  was missing). `lastdays` is also accepted as a string, for example `"7"` (before: ignored).
- `sites_web_domain_add`, `sites_web_vhost_aliasdomain_add`, `sites_web_vhost_subdomain_add` and their
  `_update`: an empty `subdomain` is stored as `none` (before: a database error or an empty value).
- `sites_shell_user_add`, `sites_shell_user_update`: an empty `chroot` is stored as `no` (`_add` also without
  `chroot`; before: an empty string).
- `sites_shell_user_add`, `sites_shell_user_update`: `ssh_rsa` must contain public keys in authorized_keys
  format (one per line; options before the key and `#` comment lines allowed); private keys and other text are
  refused (`data_processing_error`, message `ssh_rsa_error`).

- `sites_web_aliasdomain_get`, `sites_web_subdomain_get`, `sites_web_vhost_aliasdomain_get`,
  `sites_web_vhost_subdomain_get`: return only records of their type: the ID of another web domain returns an empty
  array, `-1` returns all records of the type (before: all web domains), a filter array gets the type added.
  `$conf['remote_api_version'] = 1;` restores the old behaviour.
- `sites_web_domain_update`, `sites_web_vhost_aliasdomain_update`, `sites_web_vhost_subdomain_update`,
  `sites_web_aliasdomain_update`, `sites_web_subdomain_update`: the ID of a web domain of another type is refused
  with `invalid_id`, and `type` in the parameters is ignored (before: the record type could be changed).
  A new `parent_domain_id` of a vhost subdomain or alias domain now always sets its document root and website
  user to those of the new website (before: only when `type` was sent), and the server moves its folder.
- `sites_web_vhost_aliasdomain_update`, `sites_web_vhost_subdomain_update`, `sites_web_aliasdomain_update`,
  `sites_web_subdomain_update`, `sites_database_update`: the record keeps its owner, `client_id` no longer moves it
  to another client; an alias domain or subdomain moved to another website gets the owner of that website, as in the
  panel. `$conf['remote_api_version'] = 1;` restores the old behaviour.
- `quota_get_by_user`, `databasequota_get_by_user`: return only the records of the client's groups (before: also
  records of other clients that are readable by all users).
- `sites_web_domain_add`: `readonly` also accepts `1`, `"1"`, `"y"`, `"yes"` and `"true"` (before: only the
  boolean `true`, other values were ignored).
- `sites_ftp_user_add`, `sites_ftp_user_update`: `quota_files`, `ul_ratio`, `dl_ratio`, `ul_bandwidth` and
  `dl_bandwidth` must be empty, `-1` or a number (before: other values were stored as 0); `uid` and `gid` are
  checked without trimming, so a value with spaces or a line break is refused.
- `sites_web_domain_add`, `sites_web_domain_update` (and the vhost subdomain/alias functions): `http_port` and
  `https_port` must be 1 to 65535.
- `sites_webdav_user_add`, `sites_webdav_user_update`: `dir` must be a folder name (letters, digits, `_`, `-`,
  `.`, not starting with a dot, up to 64 characters).
- A stored value of these fields is accepted when it is sent back unchanged.

### Databases

- `sites_database_add`: when a database of that name exists already on the server, the server removes the new
  record again and leaves the existing database unchanged; a rename to the name of an existing database keeps
  the old name in the record. MySQL refuses `sys` (besides `mysql`, `information_schema` and
  `performance_schema`), PostgreSQL refuses `postgres`, `template0` and `template1`.
- `sites_database_user_add`, `sites_database_user_update`: a user whose account exists already on the database
  server and was not created by ISPConfig gets no rights and keeps its password; a rename to the name of such
  an account keeps the old name in the record.
- `sites_database_add`, `sites_database_update`: the read/write and the read-only user must belong to the client
  of the website (`parent_domain_id`), as in the panel; otherwise the call is refused with
  `database_client_differs` / `The client of the parent web and the database do not match.` (before: accepted).
  `$conf['remote_api_version'] = 1;` restores the old behaviour.
- `sites_database_add`, `sites_database_update` (MySQL): host names in `remote_ips` are granted together with
  the IP addresses; an empty list allows every host. A list with an entry that is neither an IP address nor a
  host name (such as `192.168.1.%`) is refused with `database_remote_error_ips` (before: accepted, the check ran
  only for panel forms); such entries stored by an older version are not granted.
- PostgreSQL: after a change of `database_user_id` the new user owns the tables, views and sequences of the
  database; other databases of the old user keep their owner.
- `sites_database_add`, `sites_database_update`: `backup_format_web` and `backup_format_db` are ignored (before:
  the call failed with a database error, the columns do not exist).
- `sites_database_update` without `backup_interval` keeps the stored backup interval (before: it was cleared
  to none).
- `sites_database_get_all_by_user`: every database is returned once (before: once per user of the client's
  group, e.g. twice for the admin group with two admin users).
- `sites_web_domain_backup`, `mail_user_backup`: a `primary_id` that is not an integer is refused with
  `invalid_backup_id` (before: the trailing text was ignored).
- `sites_database_user_add`, `sites_database_user_update`: a sent plain `database_password` also sets the SHA2 and
  PostgreSQL passwords of the user, as in the panel (before: they kept the old or no password). Not with
  `_ispconfig_pw_crypted = 1` or when the stored hash is sent back.

### Mail

- `mail_blacklist_*`, `mail_whitelist_*` (add and update): `access` must be a Postfix access action: `OK`,
  `REJECT`, `DUNNO`, `DISCARD`, `HOLD`, `DEFER`, `DEFER_IF_REJECT`, `DEFER_IF_PERMIT` or a 4xx/5xx code,
  optionally followed by one line of text. A stored value is accepted when it is sent back unchanged.
- `mail_domain_add`, `mail_domain_update`: `relay_host` must be empty or a list of next hops (`host`, `[host]`,
  `[ipv6:...]`, each with an optional `:port`, separated by commas), `relay_user` one line without `:`,
  `relay_pass` one line. A stored value is accepted when it is sent back unchanged.
- `mail_user_add`, `mail_user_update`: passwords with non-ASCII characters are hashed from their UTF-8 bytes,
  so mail clients can log in with them.
- `mail_alias_*`, `mail_forward_*`, `mail_aliasdomain_*`, `mail_catchall_*` (add and update): `type` must be
  `alias`, `forward`, `aliasdomain` or `catchall` according to the function.
- `mail_transport_*`, `mail_spamfilter_user_*` (add and update): `server_id` must be a mail server that is not
  a mirror; `mail_spamfilter_user_*`: `policy_id` must be 0 or an existing policy, `local` is converted to
  upper case.
- `mail_policy_add`, `mail_policy_update`: the Y/N fields are converted to upper case and must be `Y` or `N`.
- `mail_policy_add`, `mail_policy_update`, `mail_policy_get`: new field `rspamd_greylisting` (`y`/`n`, default `n`),
  the greylisting of the policy with Rspamd (before: not part of the form, a sent value was ignored).
- `mail_spamfilter_whitelist_*`, `mail_spamfilter_blacklist_*` (add and update): `email` may not contain
  spaces, control characters, `"` or `\`.
- `mail_spamfilter_whitelist_*`, `mail_spamfilter_blacklist_*`: the functions of a list only read, change and
  delete entries of that list. `_add` and `_update` store `wb` of the function (`W` or `B`), a `wb` parameter is
  ignored; `_get` with `-1` or a filter array returns only entries of the list, an ID of the other list returns
  `null`; `_update` and `_delete` refuse an entry of the other list with `invalid_id` / `The entry is not a
  whitelist entry.` (or `blacklist`). `$conf['remote_api_version'] = 1;` restores the old behaviour.
- `mail_user_filter_add`, `mail_user_filter_update`: line breaks in `searchterm` are replaced by spaces, and
  quotes and backslashes are escaped in the generated Sieve script.
- `mail_user_filter_add`, `mail_user_filter_update`: a filter with the operator `regex` and a search term that is
  no valid POSIX regular expression (as Dovecot reads it from the Sieve string) is saved, but its rule in the
  Sieve script never matches (before: the whole Sieve script of the mailbox failed).
- `mail_domain_set_status`: the change goes through the datalog, so the servers apply it; the answer is 1 when
  the status changed and 0 otherwise (before: the record changed only in the database).
- `mail_relay_domain_add`, `_get`, `_update`, `_delete`: accept the remote permission of the relay domain
  functions as well as the old one of the relay recipient functions.
- `mail_user_update` without `email`: the mail domain check is skipped (before: a PHP warning).
- `mail_user_add`: without `maildir` or `homedir` they are built from the mail server settings, as in the panel
  (before: stored empty, the server did not create the mailbox).

- `mail_user_backup_list`: the mail domain ID filters the list as documented (before: always all backups).
- `mailquota_get_by_user`: `last_access` is the Unix timestamp (0 = never) and `name` is returned as stored
  (before: a date in the panel language or a "never" text, and the name with HTML entities). It returns only the
  mailboxes of the client's groups. `$conf['remote_api_version'] = 1;` restores the old formatting.
- `mail_user_*`, `mail_alias_*`, `mail_forward_*`, `mail_catchall_*`, `mail_user_filter_*` (add and update): the
  record gets the owner of its mail domain, as in the panel; updates keep the owner (before: the client of
  `client_id` became the owner). `$conf['remote_api_version'] = 1;` restores the old behaviour.
- `mail_user_add`: without `maildir_format` the mailbox gets the maildir format of the mail server (before:
  always `maildir`).
- `mail_user_update`: a sent `maildir_format` is ignored, as in the panel; the server keeps the existing mail in
  its format (before: stored, and the mailbox looked empty). `$conf['remote_api_version'] = 1;` restores the old
  behaviour.
- `mail_user_filter_add`, `mail_user_filter_update`: a `target` that starts with `/` or has an empty, `.` or `..`
  part is refused (`target_error_path`). On mail servers with the maildrop filter syntax, a rule with the
  operator `regex` never matches.
- `mail_domain_add`, `mail_domain_update`: `dkim_public` is always the public key of `dkim_private` (a sent value
  is ignored, empty without a readable private key); with `dkim` = `y` an invalid `dkim_private` is refused
  (`dkim_private_key_error`; before: not checked for API calls). An unchanged stored private key is accepted.
- `mail_domain_update`: a rename or owner change moves only the mailboxes, aliases, mailing lists, fetchmail
  accounts and spam filter users on the server of the mail domain (before: those with the domain name on all
  servers). Forwards of other records whose destination is an address of the domain keep their owner, their
  destination gets the new name only when they belong to the old owner of the domain (before: all of them got the
  new name and the domain's owner). Only whole addresses are renamed (before: `str_replace` on the text).
- `mail_transport_add`, `mail_transport_update`: `transport` must be one line `name:nexthop` (or `name`) with a
  transport name of letters, digits, `.`, `_` and `-` (`transport_error_format`).
- `mail_policy_add`, `mail_policy_update`: the `*_quarantine_to` fields must be empty, a name or an address, the
  `addr_extension_*` fields a name, the `*_admin` fields an email address or empty, `banned_rulenames` a comma
  separated list of names.
- `mail_spamfilter_user_add`, `mail_spamfilter_user_update`: `email` must be an address, `user@`, `@domain`,
  `@.domain`, `@` or `@.`.
- `mail_user_add`, `mail_user_update`: `maildir` must be below the mail home or the maildir path of the mail
  server, `homedir` an absolute path without `.`/`..` parts, `uid`/`gid` `-1` or a number from 1, `maildir_format`
  `maildir` or `mdbox`, `imap_prefix` empty or a name followed by `.` or `/`, `custom_mailfilter` without control
  characters (tab and line breaks allowed); `cc` addresses may have digits in the top level domain.
- `mail_forward_add`, `mail_forward_update`: `destination` must be email addresses (before: not checked for API
  calls).
- `mail_aliasdomain_add`, `mail_aliasdomain_update`: `destination` must be `@domain` like `source`.
- `mail_relay_recipient_add`, `mail_relay_recipient_update`: `source` must be an address or `@domain`, `access`
  must be `OK`.
- `mail_whitelist_add`, `mail_whitelist_update`, `mail_blacklist_add`, `mail_blacklist_update` (Postfix lists):
  `source` must be a host name or IP for the type `client`, otherwise an address, `user@`,
  `@domain` or a domain.
- `mail_filter_add`, `mail_filter_update` (Postfix header/body checks): `pattern` and `data` must
  be one line without control characters.
- `mail_catchall_*`, `mail_mailinglist_*`, `mail_fetchmail_*`: top level domains may contain digits and have up
  to 63 characters.
- A stored value of these fields is accepted when it is sent back unchanged (except the mail filter target).

### DNS

- `dns_<type>_get`, `_add`, `_update`, `_delete`: the functions of a record type only read, change and delete
  records of that type. `_get` with `-1` or a filter array returns only records of the type, an ID of another
  type returns `null`; `_update` and `_delete` refuse a record of another type with `invalid_id`; `_add` and
  `_update` store the type of the function, a `type` parameter is ignored.
- `dns_<type>_add`, `dns_<type>_update`: `name` and `data` may not contain line breaks.
- `dns_<type>_add`, `dns_<type>_update`: `server_id` of the record is set to the server of its zone, a sent
  `server_id` is ignored; a `zone` that does not exist is refused with `invalid_zone` / `The zone does not
  exist.` (before: both were stored as sent).
- `dns_<type>_update` with `update_serial`: the serial of the record's zone is increased also when `zone` is
  not in the parameters (before: the serial stayed).
- `dns_<type>_add`, `_update`, `_delete` with `update_serial`: the serial is increased without the zone
  functions; a remote user with only the record functions of the type no longer gets `permission_denied`. Only
  the serial of the zone is written (before: the whole zone was saved again through `dns_zone_update`).
- `dns_zone_add`, `dns_zone_update`: `also_notify` takes single IP addresses only; networks in `xfer` must be
  network addresses (`192.168.1.0/24`, not `192.168.1.5/24`).
- `dns_zone_delete`: the records of the zone are deleted as well, as in the panel (before: they stayed in the
  database).
- `dns_templatezone_add`: `ip` must be a valid IPv4 address, `ipv6` empty or a valid IPv6 address, `email`
  may not contain spaces, `"`, `|` or `\`; the values are inserted into the fields of the template records only.
- `dns_mx_*`, `dns_naptr_*` (add and update): `aux` must be 0 to 65535.
- `dns_a_*`, `dns_aaaa_*`, `dns_hinfo_*`: `name` may have up to 255 characters; `dns_srv_*`: the target in `data`
  up to 255 characters; `dns_tlsa_*`: `name` may be `_<port>._<tcp|udp>` without a host part.
- `dns_slave_add`, `dns_slave_update`: `xfer` accepts networks and `any` as for primary zones.
- `dns_templatezone_add`: a template with an unknown section returns an error (before: the answer was a
  "Unknown section type" page and no valid JSON/SOAP answer).
- `dns_zone_set_status`: the change goes through the datalog, so the servers apply it; the answer is 1 when
  the status changed and 0 otherwise (before: the record changed only in the database).
- `dns_templatezone_get_all` without the permission returns the `permission_denied` fault (before: a PHP
  fatal error).
- `dns_zone_add`, `dns_zone_update`: an `origin` without a trailing dot gets one.
- `dns_*_add`, `dns_*_update`: a missing or invalid `stamp` is replaced by the current time (before: a zero
  date or a database error); the examples no longer send `CURRENT_TIMESTAMP`.
- `dns_templatezone_add`: a zone that exists already is refused with an error (before: a second zone with the
  same name was created).
- `dns_cname_add`, `dns_dname_add`, `dns_alias_add`, `dns_mx_add`, `dns_ns_add`, `dns_ptr_add`, `dns_srv_add`
  (and the `_update` functions), `dns_zone_add`/`_update` (`ns`): an IPv4 address as target or primary name
  server is refused (`data_processing_error` with the existing regex message; such records never resolved).
- `dns_<type>_add`, `dns_<type>_update`: the record gets the owner of its zone, updates keep the owner;
  `dns_zone_update` with a new owner moves the records of the zone along, as in the panel (before: the client
  of `client_id` became the owner, the records stayed). `$conf['remote_api_version'] = 1;` restores the old
  behaviour.
- `dns_templatezone_add`: the zone is created on the default DNS server of the client when it is one of the
  client's DNS servers (before: always on the default DNS server of the system).
  `$conf['remote_api_version'] = 1;` restores the old behaviour.
- `dns_rp_*`, `dns_ds_*`, `dns_sshfp_*`, `dns_loc_*`, `dns_hinfo_*` (add and update): `data` must have the structure
  of the record type (RP: two names; DS: key tag, algorithm, digest type, hex digest; SSHFP: algorithm, type,
  hex fingerprint; LOC: the RFC 1876 text format; HINFO: two strings), refused with the regex error message of
  the field (before: stored, and the zone was not published any more).
- `dns_txt_add`, `dns_txt_update`: `data` must be one or more quoted strings as written into the zone file
  (quotes and backslashes escaped, several strings as `a" "b`); an unchanged stored value is accepted. The
  server leaves records with unbalanced quotes or `(`, `)` or `;` outside quotes out of the zone file.
- `dns_naptr_*`: the replacement must be `.` or a host name. `dns_caa_*`: `data` must be flags (0 or 128), a tag
  and a quoted value without quotes and backslashes (or one word). Unchanged stored values are accepted.
- `dns_zone_add`, `dns_zone_update`, `dns_slave_add`, `dns_slave_update`: a `/` in `origin` is allowed only in the
  first label (RFC 2317), a `_` only at the start of a label other than the last one (e.g.
  `_acme-challenge.example.com`); `update_acl` must be a list of IP addresses or networks, `key <name>` and ACL names,
  each optionally with `!`, separated by `,` or `;` (an unchanged stored value is accepted).
- `dns_templatezone_add`: the zone values of the template (origin, name servers, mailbox, update_acl, TXT
  records) get the checks of the zone and TXT record functions, the SOA times are numbers.
- `dns_srv_add`, `dns_srv_update`: weight, port and target are stored as checked.

### Server and system

- `server_config_set`, `system_config_set`, `server_ip_add`, `server_ip_update`, `server_ip_delete`: refused
  with `permission_denied` when `admin_allow_server_config`, `admin_allow_system_config` or
  `admin_allow_server_ip` in `security_settings.ini` is `no` (default `superadmin`: no change).
- `sys_datalog_get`, `sys_datalog_get_by_tstamp`: need the new remote permission "Datalog functions"; the
  update grants it to remote users with the server functions. The returned data leaves out the keys listed
  under General.
- `update_record_permissions`: `permissions` must be a non-empty array, otherwise `invalid parameters`.
- `update_record_permissions`: when `index_field` matches several rows, every row is changed and gets its own
  datalog entry, so the servers apply the change to all of them (before: the database changed all rows, the
  servers only one). Tables without a single-column primary key are refused with `invalid parameters`.
- `system_config_get`, `system_config_set` (section `mail`): new key `smtp_accept_invalid_cert` (`y`/`n`).
- `server_get_serverid_by_ip`: finds an IPv6 address also when it is stored in another notation.
- `server_get_app_version` with a server ID returns the version of the newest monitor record of that server.
- `monitor_jobqueue_count`: a mirror server also counts the pending jobs of its master server.
- `sys_datalog_get`: `newer` also accepts `1`, `"1"` and `"true"` (before: only boolean `true`, so JSON and SOAP
  clients got only the one entry).
- `server_ip_delete`: refused with `ip_in_use` while a website of the server uses the address.
  `$conf['remote_api_version'] = 1;` restores the old behaviour (the address is deleted).
- `server_config_set`, `system_config_set`: `section` and `key` must consist of letters, digits and `_`,
  otherwise `invalid_function_parameter` (in every API version).
- `server_config_set`, `system_config_set`: a value of a field of the System > Server Config or System >
  Interface > Main Config form is checked like in the panel (filters, validators and the options of select,
  radio and checkbox fields); a refused value gives `data_processing_error` with the field's error message.
  A value that is already stored is accepted unchanged, keys that are not fields of the form are stored as
  before. The checks of many path, host, port and list fields are stricter in 3.3.3 (panel and API).
  `$conf['remote_api_version'] = 1;` stores the value without these checks.

### Virtual servers (OpenVZ)

- `openvz_vm_*`, `openvz_template_*`, `openvz_ostemplate_*` (add and update): `hostname` must be a host name
  (`{VEID}` allowed), `nameserver` IP addresses separated by spaces, `capability` and `features` lists of
  `name:on` / `name:off`, `iptables` module names, `io_priority` 0 to 7, the resource limits of templates a number
  or `unlimited` (optionally `barrier:limit`), `custom` lines that are empty, comments or `KEY="value"` / `KEY=value`
  without quotes, backticks, backslashes and `$` (except `$VEID`) in the value, `template_file` a file name. A
  stored value is accepted when it is sent back unchanged.
- `openvz_vm_add`, `openvz_vm_update`: `ostemplate_id` must be an existing OS template, `ip_address` an IP of
  the server that is not reserved and free or used by this virtual server, each `additional_ip` 0 or such an IP.
- `openvz_vm_add`, `openvz_vm_update`: no longer fail on new installations (the column `iptables` was named
  `iptabless`, the update renames it).
- `openvz_vm_update`: a new `template_id` copies the values of the VM template to the virtual server; a new
  `ostemplate_id` no longer does.
- `openvz_vm_add`: the virtual server is set up as in the panel: it gets the next free VEID (a sent `veid` is
  replaced), the values of the VM template, its IP address and additional IPs are assigned, the OpenVZ config
  is written and, with `create_dns`, the DNS record is added (before: the record was stored as sent, without
  config and without IP assignment). `$conf['remote_api_version'] = 1;` restores the old behaviour.
