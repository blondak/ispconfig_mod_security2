<?php
/*
Copyright (c) 2012, Till Brehm, ISPConfig UG
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.
    * Neither the name of ISPConfig nor the names of its contributors
      may be used to endorse or promote products derived from this software without
      specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/


/******************************************
* Begin Form configuration
******************************************/

$tform_def_file = "form/mail_user_password.tform.php";

/******************************************
* End Form configuration
******************************************/

require_once '../../lib/config.inc.php';
require_once '../../lib/app.inc.php';

//* Check permissions for module
$app->auth->check_module_permissions('mailuser');

// Loading classes
$app->uses('tpl,tform,tform_actions');
$app->load('tform_actions');

class page_action extends tform_actions {

	function onSubmit() {
		global $app, $conf;
		
		$this->id = $app->functions->intval($_SESSION['s']['user']['mailuser_id']);

		//* A new password needs the current password
		if(isset($_POST['password']) && $_POST['password'] != '') {
			$rec = $app->db->queryOneRecord("SELECT password FROM mail_user WHERE mailuser_id = ?", $this->id);
			if(!is_array($rec) || !$app->auth->check_current_password(isset($_POST['current_password']) ? $_POST['current_password'] : '', $rec['password'])) {
				$app->tform->errorMessage .= $app->tform->lng('current_password_error_txt').'<br />';
			}
		}

		parent::onSubmit();

	}

	function onAfterUpdate() {
		global $app;

		//* Keep the own session after a password change
		$rec = $app->db->queryOneRecord("SELECT password FROM mail_user WHERE mailuser_id = ?", $this->id);
		$_SESSION['s']['user']['pw_stamp'] = hash('sha256', (string)$rec['password']);

		parent::onAfterUpdate();
	}

	function onShowEnd() {
		global $app, $conf;

		$rec = $app->tform->getDataRecord($_SESSION['s']['user']['mailuser_id']);
		$app->tpl->setVar("email", $app->functions->idn_decode($rec['email']), true);

		parent::onShowEnd();
	}

}

$app->tform_actions = new page_action;
$app->tform_actions->onLoad();

?>
