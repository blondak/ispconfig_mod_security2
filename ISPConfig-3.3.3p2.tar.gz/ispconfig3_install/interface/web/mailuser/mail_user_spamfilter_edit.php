<?php
/*
Copyright (c) 2012, Till Brehm, ISPConfig UG
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.
    * Neither the name of ISPConfig nor the names of its contributors
      may be used to endorse or promote products derived from this software without
      specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/


/******************************************
* Begin Form configuration
******************************************/

$tform_def_file = "form/mail_user_spamfilter.tform.php";

/******************************************
* End Form configuration
******************************************/

require_once '../../lib/config.inc.php';
require_once '../../lib/app.inc.php';

//* Check permissions for module
$app->auth->check_module_permissions('mailuser');

// Loading classes
$app->uses('tpl,tform,tform_actions');
$app->load('tform_actions');

class page_action extends tform_actions {

	function onShow() {
		global $app;

		$this->id = $app->functions->intval($_SESSION['s']['user']['mailuser_id']);

		parent::onShow();

	}

	function onSubmit() {
		global $app;

		$this->id = $app->functions->intval($_SESSION['s']['user']['mailuser_id']);

		//* The spamfilter policy must be one of the policies of the select field or the policy that is already set
		if(isset($this->dataRecord["policy"])) {
			$app->uses('custom_datasource');
			$policy_id = $app->functions->intval($this->dataRecord["policy"]);
			$policies = $app->custom_datasource->mailuser_spamfilter_policies(array(), $this->dataRecord);
			if($policy_id != 0 && !isset($policies[$policy_id])) {
				$tmp = $app->db->queryOneRecord("SELECT spamfilter_users.policy_id FROM mail_user, spamfilter_users WHERE mail_user.mailuser_id = ? AND spamfilter_users.email = mail_user.email", $this->id);
				if(!is_array($tmp) || $tmp['policy_id'] != $policy_id) $app->tform->errorMessage .= sprintf($app->lng('err_invalid_option'), $app->tform->lng('policy_txt'))."<br />";
				unset($tmp);
			}
			unset($policy_id, $policies);
		}

		parent::onSubmit();

	}

	function onAfterUpdate() {
		global $app, $conf;

		$rec = $app->tform->getDataRecord($this->id);
		$email_parts = explode('@', $rec['email']);
		$email_domain = $email_parts[1];
		// Prefer the domain on the server of the mailbox, fall back to the first domain with a matching name
		$domain = $app->db->queryOneRecord("SELECT sys_userid, sys_groupid, server_id FROM mail_domain WHERE domain = ? AND server_id = ?", $email_domain, $rec['server_id']);
		if(!is_array($domain) || empty($domain['server_id'])) {
			$domain = $app->db->queryOneRecord("SELECT sys_userid, sys_groupid, server_id FROM mail_domain WHERE domain = ? ORDER BY server_id", $email_domain);
		}

		// Spamfilter policy
		$policy_id = $app->functions->intval($this->dataRecord["policy"]);
		$tmp_user = $app->db->queryOneRecord("SELECT id FROM spamfilter_users WHERE email = ?", $rec["email"]);
		if($tmp_user["id"] > 0) {
			// There is already a record that we will update
			$app->db->datalogUpdate('spamfilter_users', array("policy_id" => $policy_id), 'id', $tmp_user["id"]);
		} elseif(is_array($domain) && !empty($domain['server_id'])) {
			// We create a new record
			$insert_data = array(
				"sys_userid" => $domain["sys_userid"],
				"sys_groupid" => $domain["sys_groupid"],
				"sys_perm_user" => 'riud',
				"sys_perm_group" => 'riud',
				"sys_perm_other" => '',
				"server_id" => $domain["server_id"],
				"priority" => 7,
				"policy_id" => $policy_id,
				"email" => $rec["email"],
				"fullname" => $rec["email"],
				"local" => 'Y'
			);
			$app->db->datalogInsert('spamfilter_users', $insert_data, 'id');
		} // endif spamfilter policy
	}

	function onShowEnd() {
		global $app, $conf;

		$rec = $app->tform->getDataRecord($this->id);
		$app->tpl->setVar("email", $app->functions->idn_decode($rec['email']), true);

		// Get the spamfilter policies for the user
		$tmp_user = $app->db->queryOneRecord("SELECT policy_id FROM spamfilter_users WHERE email = ?", $rec['email']);
		$app->uses('custom_datasource');
		$policies = $app->custom_datasource->mailuser_spamfilter_policies(array(), $rec);
		$policy_select = "<option value='0'".(($tmp_user['policy_id'] == 0)?" SELECTED>":">").$app->tform->lng("inherit_policy")."</option>";
		foreach($policies as $policy_id => $policy_name) {
			$selected = ($policy_id == $tmp_user["policy_id"])?'SELECTED':'';
			$policy_select .= "<option value='$policy_id' $selected>" . $app->functions->htmlentities($policy_name) . "</option>\r\n";
		}
		$app->tpl->setVar("policy", $policy_select);
		unset($policies);
		unset($policy_select);
		unset($tmp_user);

		parent::onShowEnd();
	}

}

$app->tform_actions = new page_action;
$app->tform_actions->onLoad();

?>
