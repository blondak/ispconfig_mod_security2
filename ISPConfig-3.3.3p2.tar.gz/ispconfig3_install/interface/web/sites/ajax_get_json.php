<?php

/*
Copyright (c) 2005, Till Brehm, projektfarm Gmbh
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.
    * Neither the name of ISPConfig nor the names of its contributors
      may be used to endorse or promote products derived from this software without
      specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

require_once '../../lib/config.inc.php';
require_once '../../lib/app.inc.php';

//* Check permissions for module
$app->auth->check_module_permissions('sites');

$app->uses('getconf,tform');

$server_id = $app->functions->intval($_GET["server_id"]);
$web_id = $app->functions->intval($_GET["web_id"]);
$php_type = $_GET["php_type"];
$client_group_id = $app->functions->intval($_GET['client_group_id']);
$type = $_GET["type"];

//if($_SESSION["s"]["user"]["typ"] == 'admin') {

if($type == 'getservertype'){
	$json = '{"servertype":"';
	$server_type = 'apache';
	$web_config = $app->getconf->get_server_config($server_id, 'web');
	if(!empty($web_config['server_type'])) $server_type = $web_config['server_type'];
	$json .= $server_type;
	unset($web_config);
	$json .= '"}';
}

if($type == 'getserverid'){
	$json = '{"serverid":"';
	$sql = "SELECT server_id FROM web_domain WHERE domain_id = ? AND ".$app->tform->getAuthSQL('r');
	$server = $app->db->queryOneRecord($sql, $web_id);
	$json .= $server['server_id'];
	unset($server);
	$json .= '"}';
}

if($type == 'getserverphp'){
	//* The PHP versions that the website form offers for the server, PHP mode and client, the same list is checked when the form is saved
	$app->uses('custom_datasource');
	$versions = array();
	//Wrap Objects into Array because chrome reorder objects itself
	foreach($app->custom_datasource->web_domain_php_versions(null, array('server_id' => $server_id, 'php' => $php_type, 'client_group_id' => $client_group_id)) as $php_version => $name) {
		$versions[] = (object)array($php_version => $name);
	}
	$json = json_encode(array('phpversion' => $versions));
}

if($type == 'getphptype'){
	$json = '{"phptype":"';
	$sql = "SELECT php FROM web_domain WHERE domain_id = ? AND ".$app->tform->getAuthSQL('r');
	$php = $app->db->queryOneRecord($sql, $web_id);
	$json .= $php['php'];
	unset($php);
	$json .= '"}';
}

if($type == 'getredirecttype'){
	$json = '{"redirecttype":"';
	$sql = "SELECT redirect_type FROM web_domain WHERE domain_id = ? AND ".$app->tform->getAuthSQL('r');
	$redirect = $app->db->queryOneRecord($sql, $web_id);
	$json .= $redirect['redirect_type'];
	unset($redirect);
	$json .= '"}';
}

if($type == 'get_ipv4'){
	$result = array();

	// ipv4
	//$result[] = _search('admin', 'server_ip', "AND ip_type = 'IPv4' AND (client_id = 0 OR client_id=".$app->functions->intval($_SESSION['s']['user']['client_id']).")");
	$result[] = $app->functions->suggest_ips('IPv4');

	$json = $app->functions->json_encode($result);
}

if($type == 'get_ipv6'){
	$result = array();

	// ipv6
	//$result[] = _search('admin', 'server_ip', "AND ip_type = 'IPv6' AND (client_id = 0 OR client_id=".$app->functions->intval($_SESSION['s']['user']['client_id']).")");
	$result[] = $app->functions->suggest_ips('IPv6');

	$json = $app->functions->json_encode($result);
}

if($type == 'getdatabaseusers') {
	$json = '{}';

	$sql = "SELECT sys_groupid FROM web_domain WHERE domain_id = ? AND ".$app->tform->getAuthSQL('r');
	$group = $app->db->queryOneRecord($sql, $web_id);
	if($group) {
		$sql = "SELECT database_user_id, database_user FROM web_database_user WHERE sys_groupid = ?";
		$records = $app->db->queryAllRecords($sql, $group['sys_groupid']);

		$tmp_array = array();
		foreach($records as $record) {
			$tmp_array[$record['database_user_id']] = $record['database_user'];
		}
		$json = $app->functions->json_encode($tmp_array);
		unset($records, $group, $tmp_array);
	}
}

if($type == 'get_use_combobox'){
	$json = '{"usecombobox":"';
	$use_combobox = 'y';
	$server_config_array = $app->getconf->get_global_config();
	if($server_config_array['misc']['use_combobox'] != 'y') $use_combobox = 'n';
	$json .= $use_combobox;
	unset($server_config_array);
	$json .= '"}';
}

if($type == 'get_use_loadindicator'){
	$json = '{"useloadindicator":"';
	$use_loadindicator = 'y';
	$server_config_array = $app->getconf->get_global_config();
	if($server_config_array['misc']['use_loadindicator'] != 'y') $use_loadindicator = 'n';
	$json .= $use_loadindicator;
	unset($server_config_array);
	$json .= '"}';
}

if ($type == 'getdirectivesnippet') {
	$server_type = 'apache';
	$web_config = $app->getconf->get_server_config($server_id, 'web');
	if (!empty($web_config['server_type'])) $server_type = $web_config['server_type'];

	$snippets = $app->db->queryAllRecords("SELECT directive_snippets_id, name FROM directive_snippets WHERE customer_viewable = 'y' AND active = 'y' AND type = ? ORDER BY name ASC", $server_type);

	$json = json_encode(array('snippets' => $snippets));
}

if($type == 'getclientssldata'){
	$web = $app->db->queryOneRecord("SELECT * FROM web_domain WHERE domain_id = ? AND ".$app->tform->getAuthSQL('r'), $web_id);
	$sys_group = $app->db->queryOneRecord("SELECT * FROM sys_group WHERE groupid = ?", $web['sys_groupid']);
	$client = $app->db->queryOneRecord("SELECT company_name,contact_firstname, contact_name, street, zip, city, telephone, mobile,fax, country, state, email FROM client WHERE client_id = ?",$sys_group['client_id']);
	if(is_array($client) && !empty($client)){
		if($client['telephone'] == '' && $client['mobile'] != '') $client['telephone'] = $client['mobile'];

		$fname = '';
		$lname = '';
		$parts = preg_split("/\s+/", $client['contact_name']);
		if(sizeof($parts) == 2){
			$fname = $parts[0];
			$lname = $parts[1];
		}
		if(sizeof($parts) > 2){
			$fname = $parts[0].' ';
			for($i=1;$i<sizeof($parts);$i++){
				if($i == (sizeof($parts) - 1)){
					$lname .= $parts[$i];
				} else {
					if(preg_match('@^(von|van|ten|ter|zur|zu|auf|sieber)$@i', $parts[$i])){
						$lname .= implode(' ', array_slice($parts, $i));
						break;
					} else {
						$fname .= $parts[$i].' ';
					}
				}
			}
		}
		$fname = trim($fname);
		$lname = trim($lname);
		$client['fname'] = $fname;
		$client['lname'] = $lname;
		if(trim($client['company_name']) == '') $client['company_name'] = $fname.' '.$lname;
	}
	$json = $app->functions->json_encode($client);
}

if ($type == 'getcronplaceholders') {

    if (!empty($web_id)) {
        $web_docroot_client = '';

        $web = $app->db->queryOneRecord("SELECT wd.sys_groupid, wd.domain, wd.document_root, sp.php_cli_binary
            FROM web_domain wd
            	LEFT JOIN server_php sp ON wd.server_php_id = sp.server_php_id
            WHERE wd.domain_id = ?", $web_id);

		// We exit here if we do not have a website with this ID
		if(empty($web)) die();

        if (empty($web['php_cli_binary'])) {
            $php_cli_binary = "/usr/bin/php";
        } else {
            $php_cli_binary = $web['php_cli_binary'];
        }

        if (empty($web['domain'])) {
            $domain = $app->tform->wordbook["domain_not_selected_placeholder_txt"];
        } else {
            $domain = $web['domain'];
        }

        $domain_owner = $app->db->queryOneRecord("SELECT limit_cron_type FROM sys_group, client WHERE sys_group.client_id = client.client_id and sys_group.groupid = ?", $web["sys_groupid"]);

        //* True if the site is assigned to a client
        if (isset($domain_owner["limit_cron_type"])) {
            if ($domain_owner["limit_cron_type"] == 'full') {
                $cron_type = 'full';
            } else {
                $cron_type = 'chrooted';
            }
        } else {
            //* True if the site is assigned to the admin
            $cron_type = 'full';
        }

        if ($cron_type != 'chrooted') {
            $web_docroot_client = $web['document_root'];
        }

        $web_docroot_client .= '/web';

        $json = json_encode(array(
			'php_cli_binary' => $php_cli_binary,
			'docroot_client' => $web_docroot_client,
			'cron_type' => $cron_type,
			'domain' => $domain
		));
    }
}

header('Content-type: application/json');
echo $json;

function sort_php($a, $b) {
	return strcmp($a['name'], $b['name']);
}

?>
