<?php

/*
Copyright (c) 2010, Till Brehm, projektfarm Gmbh
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.
    * Neither the name of ISPConfig nor the names of its contributors
      may be used to endorse or promote products derived from this software without
      specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

class mail_user_filter_plugin {

	var $plugin_name = 'mail_user_filter_plugin';
	var $class_name = 'mail_user_filter_plugin';

	/*
	 	This function is called when the plugin is loaded
	*/

	function onLoad() {
		global $app;

		/*
		Register for the events
		*/

		$app->plugin->registerEvent('mail:mail_user_filter:on_after_insert', 'mail_user_filter_plugin', 'mail_user_filter_edit');
		$app->plugin->registerEvent('mail:mail_user_filter:on_after_update', 'mail_user_filter_plugin', 'mail_user_filter_edit');
		$app->plugin->registerEvent('mail:mail_user_filter:on_after_delete', 'mail_user_filter_plugin', 'mail_user_filter_del');
		$app->plugin->registerEvent('mailuser:mail_user_filter:on_after_insert', 'mail_user_filter_plugin', 'mail_user_filter_edit');
		$app->plugin->registerEvent('mailuser:mail_user_filter:on_after_update', 'mail_user_filter_plugin', 'mail_user_filter_edit');
		$app->plugin->registerEvent('mailuser:mail_user_filter:on_after_delete', 'mail_user_filter_plugin', 'mail_user_filter_del');

	}


	/*
	 *	Render the mail filter rule in the desired format and insert it into the custom rules
	 *	field when a new mail filter is added or modified.
	 */
	function mail_user_filter_edit($event_name, $page_form) {
		global $app, $conf;

		$mailuser = $app->db->queryOneRecord("SELECT custom_mailfilter FROM mail_user WHERE mailuser_id = ?", $page_form->dataRecord["mailuser_id"]);
		$skip = false;
		$lines = explode("\n", $mailuser['custom_mailfilter']);
		$out = '';
		$found = false;

		foreach($lines as $line) {
			$line = rtrim($line);
			if($line == '### BEGIN FILTER_ID:'.$page_form->id) {
				$skip = true;
				$found = true;
			}
			if($skip == false && $line != '') $out .= $line ."\n";
			if($line == '### END FILTER_ID:'.$page_form->id) {
				if($page_form->dataRecord["active"] == 'y') $out .= $this->mail_user_filter_get_rule($page_form);
				$skip = false;
			}
		}

		// We did not find our rule, so we add it now as first rule.
		if($found == false && $page_form->dataRecord["active"] == 'y') {
			$new_rule = $this->mail_user_filter_get_rule($page_form);
			$out = $new_rule . $out;
		}

		$app->db->datalogUpdate('mail_user', array("custom_mailfilter" => $out), 'mailuser_id', $page_form->dataRecord["mailuser_id"]);


	}

	/*
	 *	Remove the rendered filter from custom_mailfilter when a mail_user_filter is deleted.
	 */
	function mail_user_filter_del($event_name, $page_form) {
		global $app, $conf;

		$mailuser = $app->db->queryOneRecord("SELECT custom_mailfilter FROM mail_user WHERE mailuser_id = ?", $page_form->dataRecord["mailuser_id"]);
		$skip = false;
		$lines = explode("\n", $mailuser['custom_mailfilter']);
		$out = '';

		foreach($lines as $line) {
			$line = rtrim($line);
			if($line == '### BEGIN FILTER_ID:'.$page_form->id) {
				$skip = true;
			}
			if($skip == false && $line != '') $out .= $line ."\n";
			if($line == '### END FILTER_ID:'.$page_form->id) {
				$skip = false;
			}
		}

		$app->db->datalogUpdate('mail_user', array("custom_mailfilter" => $out), 'mailuser_id', $page_form->dataRecord["mailuser_id"]);
	}


	/*
		private function to create the mail filter rules in maildrop or sieve format.
	*/
	private function mail_user_filter_get_rule($page_form) {

		global $app, $conf;

		$app->uses("getconf");
		$mailuser_rec = $app->db->queryOneRecord("SELECT server_id FROM mail_user WHERE mailuser_id = ?", $page_form->dataRecord["mailuser_id"]);
		$mail_config = $app->getconf->get_server_config($app->functions->intval($mailuser_rec["server_id"]), 'mail');

		// header values have no line breaks, header names only these characters
		$page_form->dataRecord["searchterm"] = str_replace(array("\r", "\n"), ' ', $page_form->dataRecord["searchterm"]);
		$page_form->dataRecord["source"] = preg_replace('/[^A-Za-z0-9_-]/', '', $page_form->dataRecord["source"]);

		if($mail_config['mail_filter_syntax'] == 'sieve') {

			// #######################################################
			// Filter in Sieve Syntax
			// #######################################################

			$content = '';
			$content .= '### BEGIN FILTER_ID:'.$page_form->id."\n";

			if($page_form->dataRecord["source"] == 'Header') {
				$parts = explode(':',trim($page_form->dataRecord["searchterm"]));
				$page_form->dataRecord["source"] = preg_replace('/[^A-Za-z0-9_-]/', '', array_shift($parts));
				$page_form->dataRecord["searchterm"] = trim(implode(':',$parts));
				unset($parts);
			}

			$address_headers = array('from', 'to', 'cc', 'bcc', 'reply-to', 'sender');
			$source_lower = strtolower($page_form->dataRecord["source"]);
			
			if($page_form->dataRecord["op"] == 'domain') {
				if(in_array($source_lower, $address_headers)) {
					$content .= 'if address :domain :is "'.$source_lower.'" "'.$this->sieve_string($page_form->dataRecord["searchterm"]).'" {'."\n";
				} else {
					$domain_escaped = $this->sieve_string(preg_quote($page_form->dataRecord["searchterm"], '/'));
					$content .= 'if header :regex "'.$source_lower.'" "@'.$domain_escaped.'(>|\\\\s|$)" {'."\n";
				}
			} elseif ($page_form->dataRecord["op"] == 'localpart') {
				if(in_array($source_lower, $address_headers)) {
					$content .= 'if address :localpart :is "'.$source_lower.'" "'.$this->sieve_string($page_form->dataRecord["searchterm"]).'" {'."\n";
				} else {
					$localpart_escaped = $this->sieve_string(preg_quote($page_form->dataRecord["searchterm"], '/'));
					$content .= 'if header :regex "'.$source_lower.'" "(^|<|\\\\s)'.$localpart_escaped.'@" {'."\n";
				}
			} elseif ($page_form->dataRecord["source"] == 'Size') {
				if(substr(trim($page_form->dataRecord["searchterm"]),-1) == 'k' || substr(trim($page_form->dataRecord["searchterm"]),-1) == 'K') {
					$unit = 'k';
				} else {
					$unit = 'm';
				}
				$content .= 'if size :over '.intval($page_form->dataRecord["searchterm"]).$unit.' {'."\n";
			} else {
				$searchterm_escaped = $this->sieve_string($page_form->dataRecord["searchterm"]);
				
				if($page_form->dataRecord["op"] == 'regex') {
					// Use :regex match type for regex operations
					// Note: Dovecot uses POSIX ERE which does not support inline flags like (?i)
					// For case-insensitive regex, use character classes like [aA][bB][cC]
					# if providing a regex, special chars must already be quoted as intended
					if($app->functions->is_valid_sieve_regex($page_form->dataRecord["searchterm"])) {
						$searchterm = $this->sieve_string($page_form->dataRecord["searchterm"], true);
						$content .= 'if header :regex "'.strtolower($page_form->dataRecord["source"]).'" ["'.$searchterm.'"] {'."\n";
					} else {
						// an invalid expression would stop the whole script, the rule never matches instead
						$content .= "if false {\n";
					}
				} elseif($page_form->dataRecord["op"] == 'contains') {
					// Use native :contains which is case-insensitive by default
					$content .= 'if header :contains "'.strtolower($page_form->dataRecord["source"]).'" "'.$searchterm_escaped.'" {'."\n";
				} elseif ($page_form->dataRecord["op"] == 'is') {
					// Use native :is which is case-insensitive by default
					$content .= 'if header :is "'.strtolower($page_form->dataRecord["source"]).'" "'.$searchterm_escaped.'" {'."\n";
				} elseif ($page_form->dataRecord["op"] == 'begins') {
					// Use :matches with wildcard for begins-with (case-insensitive by default)
					// Escape glob wildcards in searchterm
					$searchterm_glob = $this->sieve_string(str_replace(array('\\', '*', '?'), array('\\\\', '\\*', '\\?'), $page_form->dataRecord["searchterm"]));
					$content .= 'if header :matches "'.strtolower($page_form->dataRecord["source"]).'" "'.$searchterm_glob.'*" {'."\n";
				} elseif ($page_form->dataRecord["op"] == 'ends') {
					// Use :matches with wildcard for ends-with (case-insensitive by default)
					// Escape glob wildcards in searchterm
					$searchterm_glob = $this->sieve_string(str_replace(array('\\', '*', '?'), array('\\\\', '\\*', '\\?'), $page_form->dataRecord["searchterm"]));
					$content .= 'if header :matches "'.strtolower($page_form->dataRecord["source"]).'" "*'.$searchterm_glob.'" {'."\n";
				}
			}

			if($page_form->dataRecord["action"] == 'move') {
				$content .= '    fileinto "'.$this->sieve_string($page_form->dataRecord["target"]).'";' . "\n    stop;\n";
			} elseif ($page_form->dataRecord["action"] == 'keep') {
				$content .= "    keep;\n";
			} elseif ($page_form->dataRecord["action"] == 'stop') {
				$content .= "    stop;\n";
			} elseif ($page_form->dataRecord["action"] == 'reject') {
				$content .= '    reject "'.$this->sieve_string($page_form->dataRecord["target"]).'";' . "\n    stop;\n";
			} else {
				$content .= "    discard;\n    stop;\n";
			}

			$content .= "}\n";

			$content .= '### END FILTER_ID:'.$page_form->id."\n";

		} else {

			// #######################################################
			// Filter in Maildrop Syntax
			// #######################################################
			$content = '';
			$content .= '### BEGIN FILTER_ID:'.$page_form->id."\n";

			$TargetNoQuotes = $page_form->dataRecord["target"];
			$TargetQuotes = "\"$TargetNoQuotes\"";

			$TestChDirNoQuotes = '$DEFAULT/.'.$TargetNoQuotes;
			$TestChDirQuotes = "\"$TestChDirNoQuotes\"";

			$MailDirMakeNoQuotes = $TargetQuotes.' $DEFAULT';

			$EchoTargetFinal = $TargetNoQuotes;


			if($page_form->dataRecord["action"] == 'move') {

				$content .= "
`test -e ".$TestChDirQuotes." && exit 1 || exit 0`
if ( ".'$RETURNCODE'." != 1 )
{
	`maildirmake -f $MailDirMakeNoQuotes`
	`chmod -R 0700 ".$TestChDirQuotes."`
	`echo \"INBOX.$EchoTargetFinal\" >> ".'$DEFAULT'."/courierimapsubscribed`
}
";
			}

			$header = "if (/^".$page_form->dataRecord["source"].": ";
			$searchterm = preg_quote($page_form->dataRecord["searchterm"], '/');

			if($page_form->dataRecord["source"] == 'Size') {
				//* KB with the unit k, otherwise MB, as in the Sieve rule
				$unit = (strtolower(substr(trim($page_form->dataRecord["searchterm"]), -1)) == 'k') ? 1024 : 1048576;
				$content .= 'if ($SIZE > '.(intval($page_form->dataRecord["searchterm"]) * $unit).")\n";
			} elseif($page_form->dataRecord["op"] == 'domain') {
				$content .= $header.".*@".$searchterm."(>|\\s|$)/:h)\n";
			} elseif($page_form->dataRecord["op"] == 'localpart') {
				$content .= $header."(.*[<\\s])?".$searchterm."@/:h)\n";
			} elseif($page_form->dataRecord["op"] == 'regex') {
				//* the panel refuses regular expressions for maildrop servers, such a rule never matches
				$content .= "if (0)\n";
			} elseif($page_form->dataRecord["op"] == 'contains') {
				$content .= $header.".*".$searchterm."/:h)\n";
			} elseif ($page_form->dataRecord["op"] == 'is') {
				$content .= $header.$searchterm."$/:h)\n";
			} elseif ($page_form->dataRecord["op"] == 'begins') {
				$content .= $header.$searchterm."/:h)\n";
			} elseif ($page_form->dataRecord["op"] == 'ends') {
				$content .= $header.".*".$searchterm."$/:h)\n";
			}

			$content .= "{\n";
			$content .= "exception {\n";

			if($page_form->dataRecord["action"] == 'move') {
				$content .= 'ID' . "$page_form->id" . 'EndFolder = "$DEFAULT/.' . $page_form->dataRecord['target'] . '/"' . "\n";
				$content .= "xfilter \"/usr/bin/formail -A \\\"X-User-Mail-Filter-ID"."$page_form->id".": Yes\\\"\"" . "\n";
				$content .= "to ". '$ID' . "$page_form->id" . 'EndFolder' . "\n";
			} else {
				$content .= "to /dev/null\n";
			}

			$content .= "}\n";
			$content .= "}\n";

			//}

			$content .= '### END FILTER_ID:'.$page_form->id."\n";

		}

		return $content;
	}

	/*
		The value as the content of a Sieve string. With $raw the escapes of the value are kept
		(regular expressions), only a double quote or a backslash at the end without an escape gets one.
	*/
	private function sieve_string($value, $raw = false) {
		if(!$raw) return str_replace(array('\\', '"'), array('\\\\', '\\"'), $value);
		$out = '';
		$len = strlen($value);
		for($i = 0; $i < $len; $i++) {
			if($value[$i] == '\\') $out .= ($i + 1 < $len) ? '\\'.$value[++$i] : '\\\\';
			elseif($value[$i] == '"') $out .= '\\"';
			else $out .= $value[$i];
		}
		return $out;
	}


} // end class



?>
