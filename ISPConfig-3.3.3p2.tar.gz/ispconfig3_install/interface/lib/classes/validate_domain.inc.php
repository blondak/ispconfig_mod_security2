<?php

/*
Copyright (c) 2007, Till Brehm, projektfarm Gmbh
Copyright (c) 2012, Marius Cramer, pixcept KG
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.
    * Neither the name of ISPConfig nor the names of its contributors
      may be used to endorse or promote products derived from this software without
      specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

class validate_domain {

	function get_error($errmsg) {
		global $app;

		if(isset($app->tform->wordbook[$errmsg])) {
			return $app->tform->wordbook[$errmsg]."<br>\r\n";
		} else {
			return $errmsg."<br>\r\n";
		}
	}

	/* Validator function for domain (website) */
	function web_domain($field_name, $field_value, $validator) {
		global $app;

		if(empty($field_value)) return $this->get_error('domain_error_empty');

		// do not allow wildcards on website domains
		$result = $this->_regex_validate($field_value);
		if(!$result) return $this->get_error('domain_error_regex');

		$result = $this->_check_unique($field_value);
		if(!$result) return $this->get_error('domain_error_unique');
		if($this->_below_other_owner($field_value)) return $this->get_error('domain_error_unique');
		if($this->_is_server_hostname($field_value)) return $this->get_error('domain_error_unique');
		$child = $this->_refused_child_name($field_value);
		if($child != '') return $this->get_error($app->tform->lng('domain_error_unique').' '.$app->functions->htmlentities($app->functions->idn_decode($child)));

		$pattern = '/\.acme\.invalid$/';
		if(preg_match($pattern, $field_value)) return $this->get_error('domain_error_acme_invalid');
	}

	/* Validator function for sub domain */
	function sub_domain($field_name, $field_value, $validator) {
		if(empty($field_value)) return $this->get_error('domain_error_empty');

		$allow_wildcard = $this->_wildcard_limit();
		if($allow_wildcard == false && substr($field_value, 0, 2) === '*.') return $this->get_error('domain_error_wildcard');

		$result = $this->_regex_validate($field_value, $allow_wildcard);
		if(!$result) return $this->get_error('domain_error_regex');

		$result = $this->_check_unique($field_value);
		if(!$result) return $this->get_error('domain_error_unique');
		if($this->_below_other_owner($field_value)) return $this->get_error('domain_error_unique');
		if($this->_is_server_hostname($field_value)) return $this->get_error('domain_error_unique');

		$pattern = '/\.acme\.invalid$/';
		if(preg_match($pattern, $field_value)) return $this->get_error('domain_error_acme_invalid');
	}

	/* Validator function for alias domain */
	function alias_domain($field_name, $field_value, $validator) {
		if(empty($field_value)) return $this->get_error('domain_error_empty');

		// do not allow wildcards on alias domains
		$result = $this->_regex_validate($field_value);
		if(!$result) return $this->get_error('domain_error_regex');

		$result = $this->_check_unique($field_value);
		if(!$result) return $this->get_error('domain_error_unique');
		if($this->_below_other_owner($field_value)) return $this->get_error('domain_error_unique');
		if($this->_is_server_hostname($field_value)) return $this->get_error('domain_error_unique');

		$pattern = '/\.acme\.invalid$/';
		if(preg_match($pattern, $field_value)) return $this->get_error('domain_error_acme_invalid');
	}

	/* Validator function for checking the auto subdomain of a web/aliasdomain */
	function web_domain_autosub($field_name, $field_value, $validator) {
		global $app;
		if(empty($field_value) || $field_name != 'subdomain') return; // none set

		if(isset($app->remoting_lib->primary_id)) {
			$check_domain = $app->remoting_lib->dataRecord['domain'];
		} else {
			$check_domain = $_POST['domain'];
		}

		$app->uses('ini_parser,getconf');
		$settings = $app->getconf->get_global_config('domains');
		if ($settings['use_domain_module'] == 'y') {
			$sql = "SELECT domain_id, domain FROM domain WHERE domain_id = ?";
			$domain_check = $app->db->queryOneRecord($sql, $check_domain);
			if(!$domain_check) return;
			$check_domain = $domain_check['domain'];
		}

		$result = $this->_check_unique($field_value . '.' . $check_domain, true);
		if(!$result) return $this->get_error('domain_error_autosub');
	}

	/* Check apache directives */
	function web_apache_directives($field_name, $field_value, $validator) {
		// line breaks as the server writes them (\r\n and \r become \n), a line ending with a backslash continues on the next line
		return $this->_scan_directives('apache', preg_replace('/\\\\\n/', '', str_replace(array("\r\n", "\r"), "\n", (string)$field_value)), true);
	}

	/* Check nginx directives */
	function web_nginx_directives($field_name, $field_value, $validator) {
		// nginx does not care about line breaks, the patterns are matched against the whole text
		return $this->_scan_directives('nginx', $field_value, false);
	}

	/* Matches the directives against security/<server>_directives.blacklist(.custom), refuses them when the list can not be used */
	function _scan_directives($server, $field_value, $per_line) {
		global $app;

		if(trim($field_value) == '') return;
		$security_config = $app->getconf->get_security_config('ids');
		if($security_config[$server.'_directives_scan_enabled'] != 'yes') return;

		$blacklist_path = '/usr/local/ispconfig/security/'.$server.'_directives.blacklist';
		if(is_file($blacklist_path.'.custom')) $blacklist_path .= '.custom';
		if(!is_file($blacklist_path)) $blacklist_path = realpath(ISPC_ROOT_PATH.'/../security/'.$server.'_directives.blacklist');
		$regex = ($blacklist_path ? @file($blacklist_path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) : false);
		if(!is_array($regex) || count($regex) == 0) {
			$app->log('Directive blacklist '.$blacklist_path.' for '.$server.' can not be read or is empty, directives refused.', LOGLEVEL_ERROR);
			return $this->get_error($server.'_directive_blocked_error');
		}

		$directives = ($per_line ? explode("\n", $field_value) : array($field_value));
		$blocked_line = '';
		foreach($directives as $directive) {
			$directive = trim($directive);
			foreach($regex as $r) {
				if(trim($r) == '') continue;
				$result = @preg_match(trim($r), $directive, $match);
				if($result === false) {
					$app->log('Invalid pattern '.$r.' in directive blacklist '.$blacklist_path.', directives refused.', LOGLEVEL_ERROR);
					return $this->get_error($server.'_directive_blocked_error');
				}
				if($result) $blocked_line .= $app->functions->htmlentities(trim($per_line ? $directive : $match[0], " \t\r\n;{}")).'<br />';
			}
		}

		if($blocked_line != '') {
			return $this->get_error($server.'_directive_blocked_error').' '.$blocked_line;
		}
	}


	/* internal validator function to match regexp */
	function _regex_validate($domain_name, $allow_wildcard = false) {
		$pattern = '/^(?=.{1,255}$)' . ($allow_wildcard == true ? '(\*\.)?' : '') . '([\w\-]+\.)+[a-zA-Z0-9\-]{2,63}$/D';
		return preg_match($pattern, $domain_name);
	}

	/* check if the domain hostname is unique (keep in mind the auto subdomains!) */
	function _check_unique($domain_name, $only_domain = false) {
		global $app, $page;

		if(isset($app->remoting_lib->primary_id)) {
			$primary_id = $app->remoting_lib->primary_id;
			$domain = $app->remoting_lib->dataRecord;
		} else {
			$primary_id = $app->tform->primary_id;
			$domain = $page->dataRecord;
		}

		if($domain['ip_address'] == '' || $domain['ipv6_address'] == ''){
			if($domain['parent_domain_id'] > 0){
				$parent_domain = $app->db->queryOneRecord("SELECT * FROM web_domain WHERE domain_id = ?", $domain['parent_domain_id']);
				if(is_array($parent_domain) && !empty($parent_domain)){
					$domain['ip_address'] = $parent_domain['ip_address'];
					$domain['ipv6_address'] = $parent_domain['ipv6_address'];
				}
			}
		}

		// check if domain has alias/subdomains - if we move a web to another IP, make sure alias/subdomains are checked as well
		$aliassubdomains = $app->db->queryAllRecords("SELECT * FROM web_domain WHERE parent_domain_id = ? AND (type = 'alias' OR type = 'subdomain' OR type = 'vhostsubdomain')", $primary_id);
		$additional_sql1 = '';
		$additional_sql2 = '';
		$domain_params = array();
		if(is_array($aliassubdomains) && !empty($aliassubdomains)){
			foreach($aliassubdomains as $aliassubdomain){
				$additional_sql1 .= " OR d.domain = ?";
				$additional_sql2 .= " OR CONCAT(d.subdomain, '.', d.domain) = ?";
				$domain_params[] = $aliassubdomain['domain'];
			}
		}


		$qrystr = "SELECT d.domain_id, IF(d.parent_domain_id != 0 AND p.domain_id IS NOT NULL, p.ip_address, d.ip_address) as `ip_address`, IF(d.parent_domain_id != 0 AND p.domain_id IS NOT NULL, p.ipv6_address, d.ipv6_address) as `ipv6_address` FROM `web_domain` as d LEFT JOIN `web_domain` as p ON (p.domain_id = d.parent_domain_id) WHERE (d.domain = ?" . $additional_sql1 . ") AND d.server_id = ? AND d.domain_id != ?" . ($primary_id ? " AND d.parent_domain_id != ?" : "");
		$params = array_merge(array($domain_name), $domain_params, array($domain['server_id'], $primary_id, $primary_id));
		$checks = $app->db->queryAllRecords($qrystr, true, $params);
		if(is_array($checks) && !empty($checks)){
			foreach($checks as $check){
				if($domain['ip_address'] == '*') return false;
				if($check['ip_address'] == '*') return false;
				if($domain['ip_address'] != '' && $check['ip_address'] == $domain['ip_address']) return false;
				if($domain['ipv6_address'] != '' && $check['ipv6_address'] == $domain['ipv6_address']) return false;
			}
		}

		if($only_domain == false) {
			$qrystr = "SELECT d.domain_id, IF(d.parent_domain_id != 0 AND p.domain_id IS NOT NULL, p.ip_address, d.ip_address) as `ip_address`, IF(d.parent_domain_id != 0 AND p.domain_id IS NOT NULL, p.ipv6_address, d.ipv6_address) as `ipv6_address` FROM `web_domain` as d LEFT JOIN `web_domain` as p ON (p.domain_id = d.parent_domain_id) WHERE (CONCAT(d.subdomain, '.', d.domain) = ?" . $additional_sql2 . ") AND d.server_id = ? AND d.domain_id != ?" . ($primary_id ? " AND d.parent_domain_id != ?" : "");
			$params = array_merge(array($domain_name), $domain_params, array($domain['server_id'], $primary_id, $primary_id));
			$checks = $app->db->queryAllRecords($qrystr, true, $params);
			if(is_array($checks) && !empty($checks)){
				foreach($checks as $check){
					if($domain['ip_address'] == '*') return false;
					if($check['ip_address'] == '*') return false;
					if($domain['ip_address'] != '' && $check['ip_address'] == $domain['ip_address']) return false;
					if($domain['ipv6_address'] != '' && $check['ipv6_address'] == $domain['ipv6_address']) return false;
				}
			}
		}

		return true;
	}

	/* without the domain module, clients and resellers can not use the name of a website or child domain of another owner or a name below it */
	function _below_other_owner($domain_name) {
		global $app;

		if($_SESSION['s']['user']['typ'] == 'admin') return false;
		$app->uses('ini_parser,getconf');
		$settings = $app->getconf->get_global_config('domains');
		if($settings['use_domain_module'] == 'y') return false;

		if($app->tform->primary_id > 0) {
			//* a domain that already has this name keeps it
			$rec = $app->db->queryOneRecord("SELECT domain FROM web_domain WHERE domain_id = ?", $app->tform->primary_id);
			if(is_array($rec) && strtolower($rec['domain']) == strtolower($domain_name)) return false;
		}
		$name = strtolower(preg_replace('/^\*\./', '', $domain_name));
		$groups = array_map('intval', explode(',', $_SESSION['s']['user']['groups']));
		$rec = $app->db->queryOneRecord("SELECT domain_id FROM web_domain WHERE sys_groupid NOT IN ? AND (TRIM(LEADING '*.' FROM domain) = ? OR RIGHT(?, CHAR_LENGTH(TRIM(LEADING '*.' FROM domain)) + 1) = CONCAT('.', TRIM(LEADING '*.' FROM domain)))", $groups, $name, $name);
		return is_array($rec);
	}

	/* A website renamed in the panel renames its subdomains, vhost subdomains and vhost alias domains (sites_web_vhost_domain_plugin):
	   returns the first new child name that the checks of a website name refuse, or '' */
	function _refused_child_name($domain_name) {
		global $app;

		if(isset($app->remoting_lib->primary_id) || $app->tform->primary_id < 1) return '';
		$old = $app->db->queryOneRecord("SELECT domain FROM web_domain WHERE domain_id = ?", $app->tform->primary_id);
		$new = strtolower($app->functions->idn_encode($domain_name));
		if(!is_array($old) || $old['domain'] == $new) return '';
		$children = $app->db->queryAllRecords("SELECT domain FROM web_domain WHERE parent_domain_id = ? AND type IN ('subdomain', 'vhostsubdomain', 'vhostalias') AND domain LIKE ?", $app->tform->primary_id, '%.'.$old['domain']);
		foreach($children as $child) {
			$name = substr($child['domain'], 0, -strlen($old['domain'])).$new;
			if(!$this->_check_unique($name) || $this->_below_other_owner($name) || $this->_is_server_hostname($name)) return $name;
		}
		return '';
	}

	/* only the admin may use the host name of a server, the certificate of that name is the one of the server */
	function _is_server_hostname($domain_name) {
		global $app;

		if($_SESSION['s']['user']['typ'] == 'admin') return false;
		$app->uses('getconf');
		$name = strtolower(preg_replace('/^\*\./', '', $domain_name));
		foreach($app->db->queryAllRecords("SELECT server_id, server_name FROM server") as $rec) {
			$server_config = $app->getconf->get_server_config($rec['server_id'], 'server');
			if($name == strtolower($rec['server_name']) || (isset($server_config['hostname']) && $name == strtolower($server_config['hostname']))) return true;
		}
		return false;
	}

	/* check if the client may add wildcard domains */
	function _wildcard_limit() {
		global $app;

		if($_SESSION["s"]["user"]["typ"] != 'admin') {
			// Get the limits of the client
			$client_group_id = $app->functions->intval($_SESSION["s"]["user"]["default_group"]);
			$client = $app->db->queryOneRecord("SELECT limit_wildcard FROM sys_group, client WHERE sys_group.client_id = client.client_id and sys_group.groupid = ?", $client_group_id);

			if($client["limit_wildcard"] == 'y') return true;
			else return false;
		}
		return true; // admin may always add wildcard domain
	}

	/**
	 * Parses $expression to check if it is a valid shell glob pattern.
	 * Does not support extended glob matching syntax.
	 *
	 * @see https://www.gnu.org/software/bash/manual/html_node/Pattern-Matching.html
	 * @param string $expression
	 * @param string $allowed_chars regexp of allowed characters in expression. ? and * are always allowed
	 * @param string|null $allowed_brace_chars regexp of allowed characters in brace ([...]). Dash is always allowed. If empty, then $allowed_chars will be used
	 * @return bool
	 */
	private function validate_glob($expression, $allowed_chars = '/^.$/u', $allowed_brace_chars = null) {
		$escaping = false;
		$in_brace = false;
		$brace_content = [];
		$chars = preg_split('//u', $expression, -1, PREG_SPLIT_NO_EMPTY);
		foreach($chars as $i => $c) {
			if($in_brace) {
				// the first char after brace start can be a ].
				if(($c == ']' && empty($brace_content)) || $c != ']') {
					$brace_content[] = $c;
				} else {
					$in_brace = false;
					$last_is_dash = false;
					foreach($brace_content as $bi => $bc) {
						// dashes are always allowed
						if($bc == '-') {
							// ... but we consider consecutive dashes as invalid
							if($last_is_dash) {
								return false;
							}
							// ... and need to validate it as allowed char when it is first or last
							if(($bi == 0 || $bi == count($brace_content) - 1) && !preg_match($allowed_brace_chars ?: $allowed_chars, '-')) {
								return false;
							}
							$last_is_dash = true;
						} else {
							$last_is_dash = false;
							// negate chars are always allowed
							if($bi == 0 && ($bc == '^' || $bc == '!') && count($brace_content) > 1) {
								continue;
							}
							if(!preg_match($allowed_brace_chars ?: $allowed_chars, $bc)) {
								return false;
							}
						}
					}
				}
			} else {
				$peek = $i == count($chars) - 1 ? '' : $chars[$i + 1];
				if($c == '\\' && in_array($peek, ['[', ']', '*', '?'])) {
					$escaping = true;
					continue;
				} elseif($c == '[' && !$escaping) {
					$in_brace = true;
					$brace_content = [];
				} elseif($escaping || ($c != '?' && $c != '*')) {
					if(!preg_match($allowed_chars, $c)) {
						return false;
					}
				}
				$escaping = false;
			}
		}
		return !$in_brace && !$escaping;
	}

	/**
	 * Validates that input is a comma separated list of domain globs.
	 * Can be used for fnmatch() as input.
	 */
	function domain_glob_list($field_name, $field_value, $validator) {
		global $app;
		$allowempty = $validator['allowempty'] ?: 'n';
		$exceptions = $validator['exceptions'] ?: [];
		$allow_exception_as_substring = $validator['allow_exception_as_substring'] ?: 'y';
		if(!$field_value) {
			if($allowempty == 'y') {
				return '';
			}
			return $this->get_error($validator['errmsg']);
		}
		$parts = explode(',', $field_value);
		foreach($parts as $part) {
			$part = trim($part);
			// an empty part means there is a stray comma
			if(empty($part)) {
				return $this->get_error($validator['errmsg']);
			}
			// allow list placeholders that you will replace with real values at evaluation
			if(in_array($part, $exceptions, true)) {
				continue;
			}
			// optionally do not allow placeholders to be part of an expression
			if($allow_exception_as_substring == 'n') {
				foreach($exceptions as $exception) {
					if(strpos($part, $exception) !== false) {
						return $this->get_error($validator['errmsg']);
					}
				}
			}
			// A domain glob needs to:
			// * be a valid glob with only a-z0-9._- as characters
			// * have at least one dot in it
			// * not have two consecutive dots
			if(!$this->validate_glob($part, '/^[a-z0-9._-]$/ui') || strpos($part, '.') === false || strpos($part, '..') !== false) {
				return $this->get_error($validator['errmsg']);
			}
		}
		return '';
	}

}
