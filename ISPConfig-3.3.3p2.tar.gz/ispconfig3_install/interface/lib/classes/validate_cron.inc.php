<?php

/*
Copyright (c) 2007, Till Brehm, projektfarm Gmbh
Modified 2009, Marius Cramer, pixcept KG
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.
    * Neither the name of ISPConfig nor the names of its contributors
      may be used to endorse or promote products derived from this software without
      specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

class validate_cron {

	function get_error($errmsg) {
		global $app;

		if(isset($app->tform->wordbook[$errmsg])) {
			return $app->tform->wordbook[$errmsg]."<br>\r\n";
		} else {
			return $errmsg."<br>\r\n";
		}
	}

	/*
        Validator function to check if a given cron command is in correct form (url only).
    */
	function command_format($field_name, $field_value, $validator) {
		global $app, $page;

		if(preg_match("'^(\w+):\/\/'", $field_value, $matches)) {
			//* Add the {DOMAIN} placeholder to the validation process
			if(preg_match("/{DOMAIN}/", $field_value)) {

				if(isset($app->remoting_lib->primary_id)) {
					$cronjob = $app->remoting_lib->dataRecord;
				} else {
					$cronjob = $page->dataRecord;
				}

				if($cronjob['parent_domain_id'] > 0) {
					$parent_domain = $app->db->queryOneRecord("SELECT `domain` FROM `web_domain` WHERE `domain_id` = ?", $cronjob['parent_domain_id']);
					$trans = array(
						'{DOMAIN}' => $parent_domain['domain']
					);
				}

				$field_value = strtr($field_value, $trans);

			}

			$parsed = parse_url($field_value);

			if($parsed === false) return $this->get_error($validator['errmsg']);

			if($parsed["scheme"] != "http" && $parsed["scheme"] != "https") return $this->get_error($validator['errmsg']);
			if(preg_match("'^([a-z0-9][a-z0-9\-]{0,62}\.)+([A-Za-z0-9\-]{2,63})$'i", $parsed["host"]) == false) return $this->get_error($validator['errmsg']);



			if(strpos($field_value, '\\') !== false) {
				return $this->get_error($validator['errmsg']);
			}
		}

		if(strpos($field_value, "\n") !== false || strpos($field_value, "\r") !== false || strpos($field_value, chr(0)) !== false) {
			return $this->get_error($validator['errmsg']);
		}
	}

	function run_month_format($field_name, $field_value, $validator) {
		global $app;
		//* allow value @reboot in month field
		if($field_value != '@reboot') {
			return $this->run_time_format($field_name, $field_value, $validator);
		}
	}

	/*
		Validator function to check if a given cron time is in correct form.
	*/
	function run_time_format($field_name, $field_value, $validator) {
		global $app;

		//* check general form
		$is_ok = true;
		$field_value = str_replace(" ", "", $field_value); // spaces are not needed

		if(preg_match("'^[0-9\-\,\/\*]+$'", $field_value) == false) return $this->get_error($validator['errmsg']); // allowed characters are 0-9, comma, *, -, /
		elseif(preg_match("'[\-\,\/][\-\,\/]'", $field_value) == true) return $this->get_error($validator['errmsg']); // comma, - and / never stand together
		//* now split list and check each entry
		$time_list = explode(",", $field_value);
		if(count($time_list) < 1) return $this->get_error($validator['errmsg']);

		$max_entry = 0;
		$min_entry = 0;
		//* get maximum value of entry for each field type (name)
		switch($field_name) {
		case "run_min":
			$max_entry = 59;
			break;
		case "run_hour":
			$max_entry = 23;
			break;
		case "run_mday":
			$max_entry = 31;
			$min_entry = 1;
			break;
		case "run_month":
			$max_entry = 12;
			$min_entry = 1;
			break;
		case "run_wday":
			$max_entry = 7;
			break;
		}

		if($max_entry == 0) return $this->get_error('unknown_fieldtype_error');

		foreach($time_list as $entry) {
			//* possible value combinations:
			//* x               =>      ^(\d+)$
			//* x-y             =>      ^(\d+)\-(\d+)$
			//* x/y             =>      ^(\d+)\/([1-9]\d*)$
			//* x-y/z           =>      ^(\d+)\-(\d+)\/([1-9]\d*)$
			//* */x             =>      ^\*\/([1-9]\d*)$
			//* combined regex  =>      ^(\d+|\*)(\-(\d+))?(\/([1-9]\d*))?$

			if(preg_match("'^(((\d+)(\-(\d+))?)|\*)(\/([1-9]\d*))?$'", $entry, $matches) == false) {
				return $this->get_error($validator['errmsg']);
			}

			//* matches contains:
			//* 1       =>      * or value or x-y range
			//* 2       =>      unused
			//* 3       =>      value if [1] != *
			//* 4       =>      empty if no range was used
			//* 5       =>      2nd value of range if [1] != * and range was used
			//* 6       =>      empty if step was not used
			//* 7       =>      step

			//* check the values
			if($matches[1] == "*") {
				//* not to check
			} else {
				if($matches[3] < $min_entry || $matches[3] > $max_entry) {
					//* check if value is in allowed range
					return $this->get_error($validator['errmsg']);
				} elseif($matches[4] && ($matches[5] < $min_entry || $matches[5] > $max_entry || $matches[5] <= $matches[3])) {
					//* check if value is in allowed range and not less or equal to first value
					return $this->get_error($validator['errmsg']);
				}
			}
			if($matches[6] && ($matches[7] < 2 || $matches[7] > $max_entry - 1)) {
				//* check if step value is valid
				return $this->get_error($validator['errmsg']);
			}
		} //* end foreach entry loop
	}

	//* values of a cron time field as array keys
	private function field_values($field_value, $min_entry, $max_entry) {
		$values = array();
		foreach(explode(',', str_replace(' ', '', (string)$field_value)) as $entry) {
			if(!preg_match('/^(?:\*|(\d+)(?:-(\d+))?)(?:\/(\d+))?$/', $entry, $matches)) continue;
			$step = isset($matches[3]) ? max(1, (int)$matches[3]) : 1;
			if(isset($matches[1]) && $matches[1] !== '') {
				$from = (int)$matches[1];
				$to = (isset($matches[2]) && $matches[2] !== '') ? (int)$matches[2] : (isset($matches[3]) ? $max_entry : $from);
			} else {
				$from = $min_entry;
				$to = $max_entry;
			}
			for($v = $from; $v <= $to; $v += $step) $values[$v] = true;
		}
		return $values;
	}

	/*
		Shortest time in minutes between two runs of a cron job, PHP_INT_MAX when it does not run repeatedly.
	*/
	function min_interval($run_min, $run_hour, $run_mday, $run_month, $run_wday) {
		if(trim((string)$run_month) == '@reboot') return PHP_INT_MAX;

		$times = array();
		foreach(array_keys($this->field_values($run_hour, 0, 23)) as $hour) {
			foreach(array_keys($this->field_values($run_min, 0, 59)) as $minute) $times[] = $hour * 60 + $minute;
		}
		if(empty($times)) return 0;
		sort($times);
		$interval = PHP_INT_MAX;
		for($i = 1; $i < count($times); $i++) $interval = min($interval, $times[$i] - $times[$i - 1]);
		$day_span = end($times) - $times[0];

		$mdays = $this->field_values($run_mday, 1, 31);
		$months = $this->field_values($run_month, 1, 12);
		$wdays = $this->field_values($run_wday, 0, 7);
		if(isset($wdays[7])) $wdays[0] = true;
		//* cron runs on the day of month OR the day of week when both are restricted
		$any_day = (substr(trim((string)$run_mday), 0, 1) == '*' || substr(trim((string)$run_wday), 0, 1) == '*');

		//* eight years contain every day pattern twice, also February 29
		$last_day = null;
		for($day = 0; $day < 8 * 366; $day++) {
			list($mday, $month, $wday) = explode(' ', gmdate('j n w', gmmktime(0, 0, 0, 1, 1 + $day, 2000)));
			if(!isset($months[$month])) continue;
			$runs = $any_day ? (isset($mdays[$mday]) && isset($wdays[$wday])) : (isset($mdays[$mday]) || isset($wdays[$wday]));
			if(!$runs) continue;
			if($last_day !== null) $interval = min($interval, ($day - $last_day) * 1440 - $day_span);
			$last_day = $day;
		}
		return $interval;
	}

}
