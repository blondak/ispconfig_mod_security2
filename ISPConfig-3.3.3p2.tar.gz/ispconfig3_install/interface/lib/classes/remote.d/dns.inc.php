<?php

/*
Copyright (c) 2007 - 2016, Till Brehm, projektfarm Gmbh
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.
    * Neither the name of ISPConfig nor the names of its contributors
      may be used to endorse or promote products derived from this software without
      specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

--UPDATED 08.2009--
Full SOAP support for ISPConfig 3.1.4 b
Updated by Arkadiusz Roch & Artur Edelman
Copyright (c) Tri-Plex technology

--UPDATED 08.2013--
Migrated into new remote classes system
by Marius Cramer <m.cramer@pixcept.de>

*/

class remoting_dns extends remoting {
	// DNS Function --------------------------------------------------------------------------------------------------

	//* Create Zone with Template
	public function dns_templatezone_add($session_id, $client_id, $template_id, $domain, $ip, $ns1, $ns2, $email, $ipv6 = '') {
		global $app, $conf;

		if(!$this->checkPerm($session_id, 'dns_templatezone_add')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
		}

		$client_id = $app->functions->intval($client_id);

		// Get client group id
		$rec = $app->db->queryOneRecord("SELECT groupid FROM sys_group WHERE client_id = ?", $client_id);
		if(isset($rec['groupid'])) {
			$client_group_id = $app->functions->intval($rec['groupid']);
		} else {
			throw new SoapFault('no_group_found', 'There is no group for this client ID.');
			return false;
		}

		$app->uses('remoting_lib,dns_wizard');
		$app->remoting_lib->loadUserProfile($client_id);

		$data = [
			'client_group_id' => $client_group_id,
			'template_id' => $template_id,
			'domain' => $domain,
			'ip' => $ip,
			'ns1' => $ns1,
			'ns2' => $ns2,
			'email' => $email,
			'ipv6' => $ipv6,
		];
		//* The zone goes to the default DNS server of the client when it is one of the client's DNS servers
		$client = $app->db->queryOneRecord('SELECT default_dnsserver, dns_servers FROM client WHERE client_id = ?', $client_id);
		if(!$this->api_v1() && is_array($client) && in_array($client['default_dnsserver'], explode(',', (string)$client['dns_servers']))) {
			$data['server_id'] = $client['default_dnsserver'];
		}

		$create = $app->dns_wizard->create($data);

		if ($create == 'ok') {
			return true;
		} else {
			throw new SoapFault('dns_wizard_error', $create);
			return false;
		}
	}


	//* Get record details
	public function dns_zone_get($session_id, $primary_id) {
		global $app;

		if(!$this->checkPerm($session_id, 'dns_zone_get')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$app->uses('remoting_lib');
		$app->remoting_lib->loadFormDef('../dns/form/dns_soa.tform.php');
		return $app->remoting_lib->getDataRecord($primary_id);
	}

	//* Get slave zone details
	public function dns_slave_get($session_id, $primary_id) {
		global $app;

		if(!$this->checkPerm($session_id, 'dns_zone_get')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$app->uses('remoting_lib');
		$app->remoting_lib->loadFormDef('../dns/form/dns_slave.tform.php');
		return $app->remoting_lib->getDataRecord($primary_id);
	}


	//* Add a slave zone
	public function dns_slave_add($session_id, $client_id, $params) {
		if(!$this->checkPerm($session_id, 'dns_zone_add')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		return $this->insertQuery('../dns/form/dns_slave.tform.php', $client_id, $params);
	}

	//* Update a slave zone
	public function dns_slave_update($session_id, $client_id, $primary_id, $params) {
		if(!$this->checkPerm($session_id, 'dns_zone_update')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$affected_rows = $this->updateQuery('../dns/form/dns_slave.tform.php', $client_id, $primary_id, $params);
		return $affected_rows;
	}

	//* Delete a slave zone
	public function dns_slave_delete($session_id, $primary_id) {
		if(!$this->checkPerm($session_id, 'dns_zone_delete')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		return $this->deleteQuery('../dns/form/dns_slave.tform.php', $primary_id);
	}

	//* Get record id by origin
	public function dns_zone_get_id($session_id, $origin) {
		global $app;

		if(!$this->checkPerm($session_id, 'dns_zone_get_id')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}

		if(!preg_match('/^[\w\.\-]{1,64}\.[a-zA-Z0-9\-]{2,63}$/', $origin)){
			throw new SoapFault('no_domain_found', 'Invalid domain name.');
			return false;
		}

		$rec = $app->db->queryOneRecord("SELECT id FROM dns_soa WHERE origin = ? or origin = ?", $origin, $origin.'.');
		if(isset($rec['id'])) {
			return $app->functions->intval($rec['id']);
		} else {
			throw new SoapFault('no_domain_found', 'There is no domain ID with informed domain name.');
			return false;
		}
	}

	//* Add a record
	public function dns_zone_add($session_id, $client_id, $params) {
		if(!$this->checkPerm($session_id, 'dns_zone_add')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$params = $this->dns_zone_origin_dot($params);
		return $this->insertQuery('../dns/form/dns_soa.tform.php', $client_id, $params);
	}

	//* The zone name is stored with a trailing dot, as in the zone form
	private function dns_zone_origin_dot($params) {
		if(isset($params['origin']) && is_string($params['origin']) && $params['origin'] !== '' && substr($params['origin'], -1) != '.') $params['origin'] .= '.';
		return $params;
	}

	//* Update a record
	public function dns_zone_update($session_id, $client_id, $primary_id, $params) {
		global $app;

		if(!$this->checkPerm($session_id, 'dns_zone_update')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$params = $this->dns_zone_origin_dot($params);
		$old = $app->db->queryOneRecord('SELECT sys_userid, sys_groupid FROM dns_soa WHERE id = ?', $app->functions->intval($primary_id));
		$affected_rows = $this->updateQuery('../dns/form/dns_soa.tform.php', $client_id, $primary_id, $params);
		$new = $app->db->queryOneRecord('SELECT sys_userid, sys_groupid FROM dns_soa WHERE id = ?', $app->functions->intval($primary_id));
		if(is_array($old) && is_array($new) && ($old['sys_userid'] != $new['sys_userid'] || $old['sys_groupid'] != $new['sys_groupid'])) $this->dns_rr_zone_owner('zone', $primary_id);
		return $affected_rows;
	}

	//* Delete a record
	public function dns_zone_delete($session_id, $primary_id) {
		global $app;

		if(!$this->checkPerm($session_id, 'dns_zone_delete')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		//* the records of the zone go with it, as in the panel
		$records = $app->db->queryAllRecords('SELECT id FROM dns_rr WHERE zone = ?', $primary_id);
		foreach($records as $rec) {
			$app->db->datalogDelete('dns_rr', 'id', $rec['id']);
		}
		$affected_rows = $this->deleteQuery('../dns/form/dns_soa.tform.php', $primary_id);
		return $affected_rows;
	}

	// ----------------------------------------------------------------------------------------------------------------

	private function dns_rr_get($session_id, $primary_id, $rr_type = 'A') {
		global $app;

		$rr_type = strtolower($rr_type);
		if(!preg_match('/^[a-z]+$/', $rr_type)) {
			throw new SoapFault('permission denied', 'Invalid rr type');
		}

		if(!$this->checkPerm($session_id, 'dns_' . $rr_type . '_get')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
		}
		//* Only records of the type of the function
		$type = strtoupper($rr_type);
		if(is_object($primary_id)) $primary_id = get_object_vars($primary_id);
		if(is_array($primary_id)) $primary_id['type'] = $type;
		elseif($primary_id == -1) $primary_id = array('type' => $type);
		$app->uses('remoting_lib');
		$app->remoting_lib->loadFormDef('../dns/form/dns_' . $rr_type . '.tform.php');
		$record = $app->remoting_lib->getDataRecord($primary_id);
		if(!is_array($primary_id) && is_array($record) && strtoupper((string)$record['type']) !== $type) return null;
		return $record;
	}

	//* A stored record of another type than the one of the function is refused, returns the stored record
	private function dns_rr_check_type($primary_id, $rr_type) {
		global $app;
		$rec = $app->db->queryOneRecord('SELECT type, zone FROM dns_rr WHERE id = ?', $app->functions->intval($primary_id));
		if(is_array($rec) && strtoupper((string)$rec['type']) !== strtoupper($rr_type)) {
			throw new SoapFault('invalid_id', 'The record is not a '.strtoupper($rr_type).' record.');
		}
		return $rec;
	}

	//* A record is on the server of its zone
	private function dns_rr_zone_server($zone) {
		global $app;
		$soa = $app->db->queryOneRecord('SELECT server_id FROM dns_soa WHERE id = ?', $app->functions->intval($zone));
		if(!is_array($soa)) {
			throw new SoapFault('invalid_zone', 'The zone does not exist.');
		}
		return $soa['server_id'];
	}

	//* Records belong to the owner of their zone, as in the panel; $column 'id' for one record, 'zone' for all records of a zone
	private function dns_rr_zone_owner($column, $id) {
		global $app;

		if($this->api_v1()) return;
		$app->db->query('UPDATE dns_rr r, dns_soa s SET r.sys_userid = s.sys_userid, r.sys_groupid = s.sys_groupid WHERE r.?? = ? AND s.id = r.zone', $column, $app->functions->intval($id));
	}

	//* Add a record
	private function dns_rr_add($session_id, $client_id, $params, $update_serial=false, $rr_type = 'A') {
		$rr_type = strtolower($rr_type);
		if(!preg_match('/^[a-z]+$/', $rr_type)) {
			throw new SoapFault('permission denied', 'Invalid rr type');
		}

		if(!$this->checkPerm($session_id, 'dns_' . $rr_type . '_add')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
		}
		$params['type'] = strtoupper($rr_type);
		$params['server_id'] = $this->dns_rr_zone_server(isset($params['zone']) ? $params['zone'] : 0);
		$params = $this->dns_rr_stamp($params);
		$primary_id = $this->insertQuery('../dns/form/dns_' . $rr_type . '.tform.php', $client_id, $params);
		$this->dns_rr_zone_owner('id', $primary_id);
		if($update_serial) {
			$this->increase_serial($session_id, $client_id, $params);
		}
		return $primary_id;
	}

	//* The change time of a record: the current time unless a valid date time is sent
	private function dns_rr_stamp($params) {
		$stamp = (isset($params['stamp']) && is_string($params['stamp'])) ? date_create_from_format('Y-m-d H:i:s', $params['stamp']) : false;
		if($stamp === false || $stamp->format('Y-m-d H:i:s') !== $params['stamp']) $params['stamp'] = date('Y-m-d H:i:s');
		return $params;
	}

	//* Update a record
	private function dns_rr_update($session_id, $client_id, $primary_id, $params, $update_serial=false, $rr_type = 'A') {
		$rr_type = strtolower($rr_type);
		if(!preg_match('/^[a-z]+$/', $rr_type)) {
			throw new SoapFault('permission denied', 'Invalid rr type');
		}

		if(!$this->checkPerm($session_id, 'dns_' . $rr_type . '_update')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$rec = $this->dns_rr_check_type($primary_id, $rr_type);
		$params['type'] = strtoupper($rr_type);
		if(is_array($rec)) $params['server_id'] = $this->dns_rr_zone_server(isset($params['zone']) ? $params['zone'] : $rec['zone']);
		$params = $this->dns_rr_stamp($params);
		$affected_rows = $this->updateQuery('../dns/form/dns_' . $rr_type . '.tform.php', $this->api_v1() ? $client_id : 0, $primary_id, $params);
		$this->dns_rr_zone_owner('id', $primary_id);
		if($update_serial) {
			$this->increase_serial($session_id, $client_id, array('dns_rr_id' => $primary_id));
		}
		return $affected_rows;
	}

	//* Delete a record
	private function dns_rr_delete($session_id, $primary_id, $update_serial=false, $rr_type = 'A') {
		$rr_type = strtolower($rr_type);
		if(!preg_match('/^[a-z]+$/', $rr_type)) {
			throw new SoapFault('permission denied', 'Invalid rr type');
		}
		if(!$this->checkPerm($session_id, 'dns_' . $rr_type . '_delete')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
		}
		$this->dns_rr_check_type($primary_id, $rr_type);
		if($update_serial) {
			$this->increase_serial($session_id, 0, array('dns_rr_id' => $primary_id));
		}
		$affected_rows = $this->deleteQuery('../dns/form/dns_' . $rr_type . '.tform.php', $primary_id);
		return $affected_rows;
	}

	// ----------------------------------------------------------------------------------------------------------------

	//* Get record details
	public function dns_aaaa_get($session_id, $primary_id) {
		return $this->dns_rr_get($session_id, $primary_id, 'AAAA');
	}

	//* Add a record
	public function dns_aaaa_add($session_id, $client_id, $params, $update_serial=false) {
		return $this->dns_rr_add($session_id, $client_id, $params, $update_serial, 'AAAA');
	}

	//* Update a record
	public function dns_aaaa_update($session_id, $client_id, $primary_id, $params, $update_serial=false) {
		return $this->dns_rr_update($session_id, $client_id, $primary_id, $params, $update_serial, 'AAAA');
	}

	//* Delete a record
	public function dns_aaaa_delete($session_id, $primary_id, $update_serial=false) {
		return $this->dns_rr_delete($session_id, $primary_id, $update_serial, 'AAAA');
	}

	// ----------------------------------------------------------------------------------------------------------------

	//* Get record details
	public function dns_a_get($session_id, $primary_id) {
		return $this->dns_rr_get($session_id, $primary_id, 'A');
	}

	//* Add a record
	public function dns_a_add($session_id, $client_id, $params, $update_serial=false) {
		return $this->dns_rr_add($session_id, $client_id, $params, $update_serial, 'A');
	}

	//* Update a record
	public function dns_a_update($session_id, $client_id, $primary_id, $params, $update_serial=false) {
		return $this->dns_rr_update($session_id, $client_id, $primary_id, $params, $update_serial, 'A');
	}

	//* Delete a record
	public function dns_a_delete($session_id, $primary_id, $update_serial=false) {
		return $this->dns_rr_delete($session_id, $primary_id, $update_serial, 'A');
	}

	// ----------------------------------------------------------------------------------------------------------------

	//* Get record details
	public function dns_alias_get($session_id, $primary_id) {
		return $this->dns_rr_get($session_id, $primary_id, 'ALIAS');
	}

	//* Add a record
	public function dns_alias_add($session_id, $client_id, $params, $update_serial=false) {
		return $this->dns_rr_add($session_id, $client_id, $params, $update_serial, 'ALIAS');
	}

	//* Update a record
	public function dns_alias_update($session_id, $client_id, $primary_id, $params, $update_serial=false) {
		return $this->dns_rr_update($session_id, $client_id, $primary_id, $params, $update_serial, 'ALIAS');
	}

	//* Delete a record
	public function dns_alias_delete($session_id, $primary_id, $update_serial=false) {
		return $this->dns_rr_delete($session_id, $primary_id, $update_serial, 'ALIAS');
	}

	// ----------------------------------------------------------------------------------------------------------------

	//* Get record details
	public function dns_caa_get($session_id, $primary_id) {
		return $this->dns_rr_get($session_id, $primary_id, 'CAA');
	}

	//* Add a record
	public function dns_caa_add($session_id, $client_id, $params, $update_serial=false) {
		return $this->dns_rr_add($session_id, $client_id, $params, $update_serial, 'CAA');
	}

	//* Update a record
	public function dns_caa_update($session_id, $client_id, $primary_id, $params, $update_serial=false) {
		return $this->dns_rr_update($session_id, $client_id, $primary_id, $params, $update_serial, 'CAA');
	}

	//* Delete a record
	public function dns_caa_delete($session_id, $primary_id, $update_serial=false) {
		return $this->dns_rr_delete($session_id, $primary_id, $update_serial, 'CAA');
	}

	// ----------------------------------------------------------------------------------------------------------------

	//* Get record details
	public function dns_cname_get($session_id, $primary_id) {
		return $this->dns_rr_get($session_id, $primary_id, 'CNAME');
	}

	//* Add a record
	public function dns_cname_add($session_id, $client_id, $params, $update_serial=false) {
		return $this->dns_rr_add($session_id, $client_id, $params, $update_serial, 'CNAME');
	}

	//* Update a record
	public function dns_cname_update($session_id, $client_id, $primary_id, $params, $update_serial=false) {
		return $this->dns_rr_update($session_id, $client_id, $primary_id, $params, $update_serial, 'CNAME');
	}

	//* Delete a record
	public function dns_cname_delete($session_id, $primary_id, $update_serial=false) {
		return $this->dns_rr_delete($session_id, $primary_id, $update_serial, 'CNAME');
	}

	// ----------------------------------------------------------------------------------------------------------------

	//* Get record details
	public function dns_dname_get($session_id, $primary_id) {
		return $this->dns_rr_get($session_id, $primary_id, 'DNAME');
	}

	//* Add a record
	public function dns_dname_add($session_id, $client_id, $params, $update_serial=false) {
		return $this->dns_rr_add($session_id, $client_id, $params, $update_serial, 'DNAME');
	}

	//* Update a record
	public function dns_dname_update($session_id, $client_id, $primary_id, $params, $update_serial=false) {
		return $this->dns_rr_update($session_id, $client_id, $primary_id, $params, $update_serial, 'DNAME');
	}

	//* Delete a record
	public function dns_dname_delete($session_id, $primary_id, $update_serial=false) {
		return $this->dns_rr_delete($session_id, $primary_id, $update_serial, 'DNAME');
	}

	// ----------------------------------------------------------------------------------------------------------------

	//* Get record details
	public function dns_hinfo_get($session_id, $primary_id) {
		return $this->dns_rr_get($session_id, $primary_id, 'HINFO');
	}

	//* Add a record
	public function dns_hinfo_add($session_id, $client_id, $params, $update_serial=false) {
		return $this->dns_rr_add($session_id, $client_id, $params, $update_serial, 'HINFO');
	}

	//* Update a record
	public function dns_hinfo_update($session_id, $client_id, $primary_id, $params, $update_serial=false) {
		return $this->dns_rr_update($session_id, $client_id, $primary_id, $params, $update_serial, 'HINFO');
	}

	//* Delete a record
	public function dns_hinfo_delete($session_id, $primary_id, $update_serial=false) {
		return $this->dns_rr_delete($session_id, $primary_id, $update_serial, 'HINFO');
	}


	// ----------------------------------------------------------------------------------------------------------------

	//* Get record details
	public function dns_loc_get($session_id, $primary_id) {
		return $this->dns_rr_get($session_id, $primary_id, 'LOC');
	}

	//* Add a record
	public function dns_loc_add($session_id, $client_id, $params, $update_serial=false) {
		return $this->dns_rr_add($session_id, $client_id, $params, $update_serial, 'LOC');
	}

	//* Update a record
	public function dns_loc_update($session_id, $client_id, $primary_id, $params, $update_serial=false) {
		return $this->dns_rr_update($session_id, $client_id, $primary_id, $params, $update_serial, 'LOC');
	}

	//* Delete a record
	public function dns_loc_delete($session_id, $primary_id, $update_serial=false) {
		return $this->dns_rr_delete($session_id, $primary_id, $update_serial, 'LOC');
	}

	// ----------------------------------------------------------------------------------------------------------------

	//* Get record details
	public function dns_mx_get($session_id, $primary_id) {
		return $this->dns_rr_get($session_id, $primary_id, 'MX');
	}

	//* Add a record
	public function dns_mx_add($session_id, $client_id, $params, $update_serial=false) {
		return $this->dns_rr_add($session_id, $client_id, $params, $update_serial, 'MX');
	}

	//* Update a record
	public function dns_mx_update($session_id, $client_id, $primary_id, $params, $update_serial=false) {
		return $this->dns_rr_update($session_id, $client_id, $primary_id, $params, $update_serial, 'MX');
	}

	//* Delete a record
	public function dns_mx_delete($session_id, $primary_id, $update_serial=false) {
		return $this->dns_rr_delete($session_id, $primary_id, $update_serial, 'MX');
	}

	// ----------------------------------------------------------------------------------------------------------------

	//* Get record details
	public function dns_naptr_get($session_id, $primary_id) {
		return $this->dns_rr_get($session_id, $primary_id, 'NAPTR');
	}

	//* Add a record
	public function dns_naptr_add($session_id, $client_id, $params, $update_serial=false) {
		return $this->dns_rr_add($session_id, $client_id, $params, $update_serial, 'NAPTR');
	}

	//* Update a record
	public function dns_naptr_update($session_id, $client_id, $primary_id, $params, $update_serial=false) {
		return $this->dns_rr_update($session_id, $client_id, $primary_id, $params, $update_serial, 'NAPTR');
	}

	//* Delete a record
	public function dns_naptr_delete($session_id, $primary_id, $update_serial=false) {
		return $this->dns_rr_delete($session_id, $primary_id, $update_serial, 'NAPTR');
	}

	// ----------------------------------------------------------------------------------------------------------------

	//* Get record details
	public function dns_ns_get($session_id, $primary_id) {
		return $this->dns_rr_get($session_id, $primary_id, 'NS');
	}

	//* Add a record
	public function dns_ns_add($session_id, $client_id, $params, $update_serial=false) {
		return $this->dns_rr_add($session_id, $client_id, $params, $update_serial, 'NS');
	}

	//* Update a record
	public function dns_ns_update($session_id, $client_id, $primary_id, $params, $update_serial=false) {
		return $this->dns_rr_update($session_id, $client_id, $primary_id, $params, $update_serial, 'NS');
	}

	//* Delete a record
	public function dns_ns_delete($session_id, $primary_id, $update_serial=false) {
		return $this->dns_rr_delete($session_id, $primary_id, $update_serial, 'NS');
	}

	// ----------------------------------------------------------------------------------------------------------------

	//* Get record details
	public function dns_ds_get($session_id, $primary_id) {
		return $this->dns_rr_get($session_id, $primary_id, 'DS');
	}

	//* Add a record
	public function dns_ds_add($session_id, $client_id, $params, $update_serial=false) {
		return $this->dns_rr_add($session_id, $client_id, $params, $update_serial, 'DS');
	}

	//* Update a record
	public function dns_ds_update($session_id, $client_id, $primary_id, $params, $update_serial=false) {
		return $this->dns_rr_update($session_id, $client_id, $primary_id, $params, $update_serial, 'DS');
	}

	//* Delete a record
	public function dns_ds_delete($session_id, $primary_id, $update_serial=false) {
		return $this->dns_rr_delete($session_id, $primary_id, $update_serial, 'DS');
	}

	// ----------------------------------------------------------------------------------------------------------------

	//* Get record details
	public function dns_ptr_get($session_id, $primary_id) {
		return $this->dns_rr_get($session_id, $primary_id, 'PTR');
	}

	//* Add a record
	public function dns_ptr_add($session_id, $client_id, $params, $update_serial=false) {
		return $this->dns_rr_add($session_id, $client_id, $params, $update_serial, 'PTR');
	}

	//* Update a record
	public function dns_ptr_update($session_id, $client_id, $primary_id, $params, $update_serial=false) {
		return $this->dns_rr_update($session_id, $client_id, $primary_id, $params, $update_serial, 'PTR');
	}

	//* Delete a record
	public function dns_ptr_delete($session_id, $primary_id, $update_serial=false) {
		return $this->dns_rr_delete($session_id, $primary_id, $update_serial, 'PTR');
	}

	// ----------------------------------------------------------------------------------------------------------------

	//* Get record details
	public function dns_rp_get($session_id, $primary_id) {
		return $this->dns_rr_get($session_id, $primary_id, 'RP');
	}

	//* Add a record
	public function dns_rp_add($session_id, $client_id, $params, $update_serial=false) {
		return $this->dns_rr_add($session_id, $client_id, $params, $update_serial, 'RP');
	}

	//* Update a record
	public function dns_rp_update($session_id, $client_id, $primary_id, $params, $update_serial=false) {
		return $this->dns_rr_update($session_id, $client_id, $primary_id, $params, $update_serial, 'RP');
	}

	//* Delete a record
	public function dns_rp_delete($session_id, $primary_id, $update_serial=false) {
		return $this->dns_rr_delete($session_id, $primary_id, $update_serial, 'RP');
	}

	// ----------------------------------------------------------------------------------------------------------------

	//* Get record details
	public function dns_srv_get($session_id, $primary_id) {
		return $this->dns_rr_get($session_id, $primary_id, 'SRV');
	}

	//* Add a record
	public function dns_srv_add($session_id, $client_id, $params, $update_serial=false) {
		return $this->dns_rr_add($session_id, $client_id, $params, $update_serial, 'SRV');
	}

	//* Update a record
	public function dns_srv_update($session_id, $client_id, $primary_id, $params, $update_serial=false) {
		return $this->dns_rr_update($session_id, $client_id, $primary_id, $params, $update_serial, 'SRV');
	}

	//* Delete a record
	public function dns_srv_delete($session_id, $primary_id, $update_serial=false) {
		return $this->dns_rr_delete($session_id, $primary_id, $update_serial, 'SRV');
	}

	// ----------------------------------------------------------------------------------------------------------------

	//* Get record details
	public function dns_sshfp_get($session_id, $primary_id) {
		return $this->dns_rr_get($session_id, $primary_id, 'SSHFP');
	}

	//* Add a record
	public function dns_sshfp_add($session_id, $client_id, $params, $update_serial=false) {
		return $this->dns_rr_add($session_id, $client_id, $params, $update_serial, 'SSHFP');
	}

	//* Update a record
	public function dns_sshfp_update($session_id, $client_id, $primary_id, $params, $update_serial=false) {
		return $this->dns_rr_update($session_id, $client_id, $primary_id, $params, $update_serial, 'SSHFP');
	}

	//* Delete a record
	public function dns_sshfp_delete($session_id, $primary_id, $update_serial=false) {
		return $this->dns_rr_delete($session_id, $primary_id, $update_serial, 'SSHFP');
	}

	// ----------------------------------------------------------------------------------------------------------------

	//* Get record details
	public function dns_tlsa_get($session_id, $primary_id) {
		return $this->dns_rr_get($session_id, $primary_id, 'TLSA');
	}

	//* Add a record
	public function dns_tlsa_add($session_id, $client_id, $params, $update_serial=false) {
		return $this->dns_rr_add($session_id, $client_id, $params, $update_serial, 'TLSA');
	}

	//* Update a record
	public function dns_tlsa_update($session_id, $client_id, $primary_id, $params, $update_serial=false) {
		return $this->dns_rr_update($session_id, $client_id, $primary_id, $params, $update_serial, 'TLSA');
	}

	//* Delete a record
	public function dns_tlsa_delete($session_id, $primary_id, $update_serial=false) {
		return $this->dns_rr_delete($session_id, $primary_id, $update_serial, 'TLSA');
	}

	// ----------------------------------------------------------------------------------------------------------------

	//* Get record details
	public function dns_txt_get($session_id, $primary_id) {
		return $this->dns_rr_get($session_id, $primary_id, 'TXT');
	}

	//* Add a record
	public function dns_txt_add($session_id, $client_id, $params, $update_serial=false) {
		return $this->dns_rr_add($session_id, $client_id, $params, $update_serial, 'TXT');
	}

	//* Update a record
	public function dns_txt_update($session_id, $client_id, $primary_id, $params, $update_serial=false) {
		return $this->dns_rr_update($session_id, $client_id, $primary_id, $params, $update_serial, 'TXT');
	}

	//* Delete a record
	public function dns_txt_delete($session_id, $primary_id, $update_serial=false) {
		return $this->dns_rr_delete($session_id, $primary_id, $update_serial, 'TXT');
	}

	/**
	 * Get all DNS zone by user
	 *@author Julio Montoya <gugli100@gmail.com> BeezNest 2010
	 */


	public function dns_zone_get_by_user($session_id, $client_id, $server_id) {
		global $app;
		if(!$this->checkPerm($session_id, 'dns_zone_get')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		if (!empty($client_id) && !empty($server_id)) {
			$server_id      = $app->functions->intval($server_id);
			$client_id      = $app->functions->intval($client_id);
			$sql            = "SELECT id, origin FROM dns_soa d INNER JOIN sys_user s on(d.sys_groupid = s.default_group) WHERE client_id = ? AND server_id = ?";
			$result         = $app->db->queryAllRecords($sql, $client_id, $server_id);
			return          $result;
		}
		return false;
	}



  //* Get All DNS Zones Templates by etruel and thom
	public function dns_templatezone_get_all($session_id) {
		global $app, $conf;
	  if(!$this->checkPerm($session_id, 'dns_templatezone_add')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
	  }
		$sql ="SELECT * FROM dns_template";
		$result = $app->db->queryAllRecords($sql);
		if(isset($result)) {
			return $result;
		}
		else {
			throw new SoapFault('template_id_error', 'There is no DNS templates.');
			return false;
		}
	}

	/**
	 *  Get all dns records for a zone
	 * @param  int  session id
	 * @param  int  dns zone id
	 * @author Sebastian Mogilowski <sebastian@mogilowski.net> 2011
	 */
	public function dns_rr_get_all_by_zone($session_id, $zone_id) {
		global $app;
		if(!$this->checkPerm($session_id, 'dns_zone_get')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$sql    = "SELECT * FROM dns_rr WHERE zone = ?";
		$result = $app->db->queryAllRecords($sql, $zone_id);
		return $result;
	}

	/**
	 * Changes DNS zone status
	 * @param  int  session id
	 * @param int  dns soa id
	 * @param string status active or inactive string
	 * @author Julio Montoya <gugli100@gmail.com> BeezNest 2010
	 */
	public function dns_zone_set_status($session_id, $primary_id, $status) {
		global $app;
		if(!$this->checkPerm($session_id, 'dns_zone_set_status')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		if(in_array($status, array('active', 'inactive'))) {
			if ($status == 'active') {
				$status = 'Y';
			} else {
				$status = 'N';
			}
			//* write the change through the datalog, answer 1 when the status changed
			$zone = $app->db->queryOneRecord("SELECT active FROM dns_soa WHERE id = ?", $primary_id);
			if(!is_array($zone) || $zone['active'] == $status) return 0;
			$app->db->datalogUpdate('dns_soa', array('active' => $status), 'id', $primary_id);
			return 1;
		} else {
			throw new SoapFault('status_undefined', 'The status is not available');
			return false;
		}
	}

	/*
	* Set DNSSec Algo and activate it if needed.
	*
	* @param int      session id
	* @param int      client id
	* @param string   algorithm 'NSEC3RSASHA1', 'ECDSAP256SHA256' or 'NSEC3RSASHA1,ECDSAP256SHA256' string
	* @param boolean  update serial
	*
	* @author Tom Albers <kovoks@kovoks.nl> KovoKs B.V. 2023
	*/

	public function dns_zone_set_dnssec($session_id, $client_id, $primary_id, $algo, $update_serial=false) {
		global $app;
		if(!$this->checkPerm($session_id, 'dns_zone_set_status')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}

		if(!in_array($algo, ['NSEC3RSASHA1', 'ECDSAP256SHA256', 'NSEC3RSASHA1,ECDSAP256SHA256'])) {
			throw new SoapFault('permission_denied', 'You are not using a valid algorithm for this function.');
			return false;
		}
		$params["dnssec_wanted"] = "Y";
		$params["dnssec_algo"] = $algo;
		$old = $app->db->queryOneRecord('SELECT sys_userid, sys_groupid FROM dns_soa WHERE id = ?', $app->functions->intval($primary_id));
		$affected_rows = $this->updateQuery('../dns/form/dns_soa.tform.php', $client_id, $primary_id, $params);
		$new = $app->db->queryOneRecord('SELECT sys_userid, sys_groupid FROM dns_soa WHERE id = ?', $app->functions->intval($primary_id));
		if(is_array($old) && is_array($new) && ($old['sys_userid'] != $new['sys_userid'] || $old['sys_groupid'] != $new['sys_groupid'])) $this->dns_rr_zone_owner('zone', $primary_id);
		if($update_serial) {
			$this->increase_serial($session_id, $client_id, ["zone" => $primary_id]);

		}
		return $affected_rows;
	}


	//* Raises the serial of the zone of a record, part of the record function (no permission for the zone functions needed)
	private function increase_serial($session_id, $client_id, $params) {
		global $app;
		if(!isset($params['zone']) && isset($params['dns_rr_id'])) {
			$tmp = $app->db->queryOneRecord('SELECT zone FROM dns_rr WHERE id = ?',$params['dns_rr_id']);
			$params['zone'] = $tmp['zone'];
			unset($tmp);
		}
		$soa = $app->db->queryOneRecord('SELECT id, serial FROM dns_soa WHERE id = ?', $app->functions->intval($params['zone']));
		if(!is_array($soa)) return;
		$app->uses('validate_dns');
		$app->db->datalogUpdate('dns_soa', array('serial' => $app->validate_dns->increase_serial($soa['serial'])), 'id', $soa['id']);
	}
}
