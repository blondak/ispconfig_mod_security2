<?php

/*
Copyright (c) 2007 - 2013, Till Brehm, projektfarm Gmbh
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.
    * Neither the name of ISPConfig nor the names of its contributors
      may be used to endorse or promote products derived from this software without
      specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

--UPDATED 08.2009--
Full SOAP support for ISPConfig 3.1.4 b
Updated by Arkadiusz Roch & Artur Edelman
Copyright (c) Tri-Plex technology

--UPDATED 08.2013--
Migrated into new remote classes system
by Marius Cramer <m.cramer@pixcept.de>

*/

class remoting_sites extends remoting {
	// Website functions ---------------------------------------------------------------------------------------

	//* Get cron details
	public function sites_cron_get($session_id, $cron_id)
	{
		global $app;

		if(!$this->checkPerm($session_id, 'sites_cron_get')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$app->uses('remoting_lib');
		$app->remoting_lib->loadFormDef('../sites/form/cron.tform.php');
		return $app->remoting_lib->getDataRecord($cron_id);
	}

	//* Add a cron record
	public function sites_cron_add($session_id, $client_id, $params)
	{
		if(!$this->checkPerm($session_id, 'sites_cron_add')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		return $this->insertQuery('../sites/form/cron.tform.php', $client_id, $params);
	}

	//* Update cron record
	public function sites_cron_update($session_id, $client_id, $cron_id, $params)
	{
		if(!$this->checkPerm($session_id, 'sites_cron_update')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$affected_rows = $this->updateQuery('../sites/form/cron.tform.php', $client_id, $cron_id, $params);
		return $affected_rows;
	}

	//* Delete cron record
	public function sites_cron_delete($session_id, $cron_id)
	{
		if(!$this->checkPerm($session_id, 'sites_cron_delete')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$affected_rows = $this->deleteQuery('../sites/form/cron.tform.php', $cron_id);
		return $affected_rows;
	}

	// ----------------------------------------------------------------------------------------------------------

	//* Get record details
	public function sites_database_get($session_id, $primary_id)
	{
		global $app;

		if(!$this->checkPerm($session_id, 'sites_database_get')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$app->uses('remoting_lib');
		$app->remoting_lib->loadFormDef('../sites/form/database.tform.php');
		return $app->remoting_lib->getDataRecord($primary_id);
	}

	/* TODO: secure queries! */
	//* Add a record
	public function sites_database_add($session_id, $client_id, $params)
	{
		global $app;

		if(!$this->checkPerm($session_id, 'sites_database_add')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}

		//* Check for duplicates
		$tmp = $app->db->queryOneRecord("SELECT count(database_id) as dbnum FROM web_database WHERE database_name = ? AND server_id = ?", $params['database_name'], $params["server_id"]);
		if($tmp['dbnum'] > 0) {
			throw new SoapFault('database_name_error_unique', 'There is already a database with that name on the same server.');
			return false;
		}

		$this->check_database_users($params);

		$sql = $this->insertQueryPrepare('../sites/form/database.tform.php', $client_id, $params);
		if($sql !== false) {
			$app->uses('sites_database_plugin');

			$this->id = 0;
			$this->dataRecord = $params;

			$retval = $this->insertQueryExecute($sql, $params);
			$app->sites_database_plugin->processDatabaseInsert($this);

			// set correct values for backup_interval and backup_copies
			if(isset($params['backup_interval']) || isset($params['backup_copies'])){
				$sql_set = array();
				if(isset($params['backup_interval'])) $sql_set[] = "backup_interval = '".$app->db->quote($params['backup_interval'])."'";
				if(isset($params['backup_copies'])) $sql_set[] = "backup_copies = ".$app->functions->intval($params['backup_copies']);
				$this->updateQueryExecute("UPDATE web_database SET ".implode(', ', $sql_set)." WHERE database_id = ".$retval, $retval, $params);
			}

			return $retval;
		}

		return false;
	}

	//* Update a record
	public function sites_database_update($session_id, $client_id, $primary_id, $params)
	{
		global $app;

		if(!$this->checkPerm($session_id, 'sites_database_update')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}

		$this->check_database_users($params, $primary_id);

		$sql = $this->updateQueryPrepare('../sites/form/database.tform.php', $this->child_client_id($client_id), $primary_id, $params);
		if($sql !== false) {
			$app->uses('sites_database_plugin');

			$this->id = $primary_id;
			$this->dataRecord = $params;
			$app->sites_database_plugin->processDatabaseUpdate($this);
			$retval = $this->updateQueryExecute($sql, $primary_id, $params);

			// set correct values for backup_interval and backup_copies
			if(isset($params['backup_copies'])){
				$sql_set = array();
				if(isset($params['backup_copies'])) $sql_set[] = "backup_copies = ".$app->functions->intval($params['backup_copies']);
				$this->updateQueryExecute($app->db->_build_query_string("UPDATE web_database SET ".implode(', ', $sql_set)." WHERE database_id = ?", $primary_id), $primary_id, $params);
			}

			return $retval;
		}

		return false;
	}

	//* Updates of child records keep the owner of the record (remote API v1: the given client becomes the owner)
	private function child_client_id($client_id) {
		global $conf;

		return (isset($conf['remote_api_version']) && $conf['remote_api_version'] < 2) ? $client_id : 0;
	}

	//* The database users of a database belong to the client of its website, as in the panel
	private function check_database_users($params, $primary_id = 0) {
		global $app, $conf;

		if(isset($conf['remote_api_version']) && $conf['remote_api_version'] < 2) return;
		$rec = $primary_id > 0 ? $app->db->queryOneRecord('SELECT parent_domain_id, database_user_id, database_ro_user_id FROM web_database WHERE database_id = ?', $primary_id) : array();
		if(!is_array($rec)) $rec = array();
		foreach(array('parent_domain_id', 'database_user_id', 'database_ro_user_id') as $key) {
			if(isset($params[$key])) $rec[$key] = $params[$key];
		}
		if(empty($rec['parent_domain_id'])) return;
		$web = $app->db->queryOneRecord('SELECT sys_groupid FROM web_domain WHERE domain_id = ?', $rec['parent_domain_id']);
		foreach(array('database_user_id', 'database_ro_user_id') as $key) {
			if(empty($rec[$key])) continue;
			$user = $app->db->queryOneRecord('SELECT sys_groupid FROM web_database_user WHERE database_user_id = ?', $rec[$key]);
			if(!is_array($web) || !is_array($user) || $user['sys_groupid'] != $web['sys_groupid']) {
				throw new SoapFault('database_client_differs', 'The client of the parent web and the database do not match.');
			}
		}
	}

	//* Delete a record
	public function sites_database_delete($session_id, $primary_id)
	{
		global $app;
		if(!$this->checkPerm($session_id, 'sites_database_delete')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}

		$app->uses('sites_database_plugin');
		$app->sites_database_plugin->processDatabaseDelete($primary_id);

		$affected_rows = $this->deleteQuery('../sites/form/database.tform.php', $primary_id);
		return $affected_rows;
	}

	// ----------------------------------------------------------------------------------------------------------

	//* Get record details
	public function sites_database_user_get($session_id, $primary_id)
	{
		global $app;

		if(!$this->checkPerm($session_id, 'sites_database_user_get')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$app->uses('remoting_lib');
		$app->remoting_lib->loadFormDef('../sites/form/database_user.tform.php');
		return $app->remoting_lib->getDataRecord($primary_id);
	}

	//* Add a record
	public function sites_database_user_add($session_id, $client_id, $params)
	{
		if(!$this->checkPerm($session_id, 'sites_database_user_add')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}

		$params = $this->database_user_password_hashes($params);
		return $this->insertQuery('../sites/form/database_user.tform.php', $client_id, $params);
	}

	//* Copy a sent plain password into the SHA2 and PostgreSQL password fields, as the panel form does (not the stored hash sent back)
	private function database_user_password_hashes($params, $old_rec = array()) {
		if(isset($params['database_password']) && $params['database_password'] !== '' && (!isset($params['_ispconfig_pw_crypted']) || $params['_ispconfig_pw_crypted'] != 1)
			&& (!isset($old_rec['database_password']) || $params['database_password'] !== $old_rec['database_password'])) {
			$params['database_password_sha2'] = $params['database_password'];
			$params['database_password_postgres'] = $params['database_password'];
		}
		return $params;
	}

	//* Update a record
	public function sites_database_user_update($session_id, $client_id, $primary_id, $params)
	{
		global $app;

		if(!$this->checkPerm($session_id, 'sites_database_user_update')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$app->uses('remoting_lib');
		$app->remoting_lib->loadFormDef('../sites/form/database_user.tform.php');
		$old_rec = $app->remoting_lib->getDataRecord($primary_id);

		$params = $this->database_user_password_hashes($params, $old_rec);
		$result = $this->updateQuery('../sites/form/database_user.tform.php', $client_id, $primary_id, $params);

		$new_rec = $app->remoting_lib->getDataRecord($primary_id);

		$records = $app->db->queryAllRecords("SELECT DISTINCT server_id FROM web_database WHERE database_user_id = ? UNION SELECT DISTINCT server_id FROM web_database WHERE database_ro_user_id = ?", $primary_id, $primary_id);
		foreach($records as $rec) {
			$tmp_rec = $new_rec;
			$tmp_rec['server_id'] = $rec['server_id'];
			$app->remoting_lib->datalogSave('UPDATE', $primary_id, $old_rec, $tmp_rec);
		}
		unset($new_rec);
		unset($old_rec);
		unset($records);

		return $result;
	}

	//* Delete a record
	public function sites_database_user_delete($session_id, $primary_id)
	{
		global $app;

		if(!$this->checkPerm($session_id, 'sites_database_user_delete')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}

		//$app->db->datalogDelete('web_database_user', 'database_user_id', $primary_id);
		$affected_rows = $this->deleteQuery('../sites/form/database_user.tform.php', $primary_id);

		$records = $app->db->queryAllRecords("SELECT database_id FROM web_database WHERE database_user_id = ?", $primary_id);
		foreach($records as $rec) {
			$app->db->datalogUpdate('web_database', array('database_user_id' => null), 'database_id', $rec['database_id']);

		}
		$records = $app->db->queryAllRecords("SELECT database_id FROM web_database WHERE database_ro_user_id = ?", $primary_id);
		foreach($records as $rec) {
			$app->db->datalogUpdate('web_database', array('database_ro_user_id' => null), 'database_id', $rec['database_id']);
		}

		return $affected_rows;
	}

	// ----------------------------------------------------------------------------------------------------------

	//* Get record details
	public function sites_ftp_user_get($session_id, $primary_id)
	{
		global $app;

		if(!$this->checkPerm($session_id, 'sites_ftp_user_get')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$app->uses('remoting_lib');
		$app->remoting_lib->loadFormDef('../sites/form/ftp_user.tform.php');
		return $app->remoting_lib->getDataRecord($primary_id);
	}

	//* Add a record
	public function sites_ftp_user_add($session_id, $client_id, $params)
	{
		if(!$this->checkPerm($session_id, 'sites_ftp_user_add')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		return $this->insertQuery('../sites/form/ftp_user.tform.php', $client_id, $params);
	}

	//* Update a record
	public function sites_ftp_user_update($session_id, $client_id, $primary_id, $params)
	{
		if(!$this->checkPerm($session_id, 'sites_ftp_user_update')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$affected_rows = $this->updateQuery('../sites/form/ftp_user.tform.php', $client_id, $primary_id, $params);
		return $affected_rows;
	}

	//* Delete a record
	public function sites_ftp_user_delete($session_id, $primary_id)
	{
		if(!$this->checkPerm($session_id, 'sites_ftp_user_delete')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$affected_rows = $this->deleteQuery('../sites/form/ftp_user.tform.php', $primary_id);
		return $affected_rows;
	}

	//* Get server for an ftp user
	public function sites_ftp_user_server_get($session_id, $ftp_user)
	{
		global $app;

		if(!$this->checkPerm($session_id, 'sites_ftp_user_server_get')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}

		$data = $app->db->queryOneRecord("SELECT server_id FROM ftp_user WHERE username = ?", $ftp_user);
		//file_put_contents('/tmp/test.txt', serialize($data));
		if(!isset($data['server_id'])) return false;

		$server = $this->server_get($session_id, $data['server_id'], 'server');
		//file_put_contents('/tmp/test2.txt', serialize($server));

		return $server;
	}

	// ----------------------------------------------------------------------------------------------------------

	//* Get record details
	public function sites_shell_user_get($session_id, $primary_id)
	{
		global $app;

		if(!$this->checkPerm($session_id, 'sites_shell_user_get')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$app->uses('remoting_lib');
		$app->remoting_lib->loadFormDef('../sites/form/shell_user.tform.php');
		return $app->remoting_lib->getDataRecord($primary_id);
	}

	//* Add a record
	public function sites_shell_user_add($session_id, $client_id, $params)
	{
		if(!$this->checkPerm($session_id, 'sites_shell_user_add')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		//* no chroot is stored as 'no'
		if(!isset($params['chroot']) || $params['chroot'] == '') $params['chroot'] = 'no';
		return $this->insertQuery('../sites/form/shell_user.tform.php', $client_id, $params);
	}

	//* Update a record
	public function sites_shell_user_update($session_id, $client_id, $primary_id, $params)
	{
		if(!$this->checkPerm($session_id, 'sites_shell_user_update')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		//* no chroot is stored as 'no'
		if(isset($params['chroot']) && $params['chroot'] == '') $params['chroot'] = 'no';
		$affected_rows = $this->updateQuery('../sites/form/shell_user.tform.php', $client_id, $primary_id, $params);
		return $affected_rows;
	}

	//* Delete a record
	public function sites_shell_user_delete($session_id, $primary_id)
	{
		if(!$this->checkPerm($session_id, 'sites_shell_user_delete')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$affected_rows = $this->deleteQuery('../sites/form/shell_user.tform.php', $primary_id);
		return $affected_rows;
	}

	// ----------------------------------------------------------------------------------------------------------

	//* Get record details
	public function sites_web_domain_get($session_id, $primary_id)
	{
		global $app;

		if(!$this->checkPerm($session_id, 'sites_web_domain_get')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		return $this->web_domain_get_type('../sites/form/web_vhost_domain.tform.php', $primary_id, 'vhost');
	}

	//* Add a record
	public function sites_web_domain_add($session_id, $client_id, $params, $readonly = false)
	{
		global $app;
		if(!$this->checkPerm($session_id, 'sites_web_domain_add')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}

		if(!isset($params['client_group_id']) or (isset($params['client_group_id']) && empty($params['client_group_id']))) {
			$rec = $app->db->queryOneRecord("SELECT groupid FROM sys_group WHERE client_id = ?", $client_id);
			$params['client_group_id'] = $rec['groupid'];
		}

		//* Set a few params to "not empty" values which get overwritten by the sites_web_vhost_domain_plugin
		if($params['document_root'] == '') $params['document_root'] = '-';
		if($params['system_user'] == '') $params['system_user'] = '-';
		if($params['system_group'] == '') $params['system_group'] = '-';
		if($params['log_retention'] == '') $params['log_retention'] = 30;
		if(isset($params['subdomain']) && $params['subdomain'] === '') $params['subdomain'] = 'none';

		if($params['vhost_type'] == '') $params['vhost_type'] = 'name';
		if($params['ip_address'] == '') $params['ip_address'] = '*';

		//* Set a few defaults for nginx servers
		if($params['pm_max_children'] == '') $params['pm_max_children'] = 10;
		if($params['pm_start_servers'] == '') $params['pm_start_servers'] = 2;
		if($params['pm_min_spare_servers'] == '') $params['pm_min_spare_servers'] = 1;
		if($params['pm_max_spare_servers'] == '') $params['pm_max_spare_servers'] = 5;
		if(!isset($params['php_fpm_use_socket'])) $params['php_fpm_use_socket'] = 'y';

		$domain_id = $this->insertQuery('../sites/form/web_vhost_domain.tform.php', $client_id, $params, 'sites:web_vhost_domain:on_after_insert');
		if (in_array($readonly, array(true, 1, '1', 'y', 'yes', 'true'), true))
			$app->db->query("UPDATE web_domain SET `sys_userid` = '1' WHERE domain_id = ?", $domain_id);
		return $domain_id;
	}

	//* Update a record
	public function sites_web_domain_update($session_id, $client_id, $primary_id, $params)
	{
		if(!$this->checkPerm($session_id, 'sites_web_domain_update')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$this->check_web_domain_type($primary_id, 'vhost');
		$params['type'] = 'vhost';

		if(isset($params['subdomain']) && $params['subdomain'] === '') $params['subdomain'] = 'none';
		$params = $this->web_domain_update_defaults($params);

		$affected_rows = $this->updateQuery('../sites/form/web_vhost_domain.tform.php', $client_id, $primary_id, $params);
		return $affected_rows;
	}

	//* Delete a record
	public function sites_web_domain_delete($session_id, $primary_id)
	{
		global $app;

		if(!$this->checkPerm($session_id, 'sites_web_domain_delete')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$this->check_existing_web_domain_type($primary_id, 'vhost');
		$app->uses('tools_sites');
		$app->tools_sites->delete_web_domain_children($primary_id);
		$affected_rows = $this->deleteQuery('../sites/form/web_vhost_domain.tform.php', $primary_id);
		return $affected_rows;
	}

	//* An alias or subdomain belongs to the group of its website, as in the panel (remote API v1: unchanged)
	private function child_domain_parent_group($primary_id) {
		global $app, $conf;

		if(isset($conf['remote_api_version']) && $conf['remote_api_version'] < 2) return;
		$rec = $app->db->queryOneRecord('SELECT parent.sys_groupid FROM web_domain child, web_domain parent WHERE child.domain_id = ? AND parent.domain_id = child.parent_domain_id', $app->functions->intval($primary_id));
		if(is_array($rec)) $app->db->query('UPDATE web_domain SET sys_groupid = ? WHERE domain_id = ?', $rec['sys_groupid'], $app->functions->intval($primary_id));
	}

	//* The stored type of a web_domain record, '' when it does not exist
	private function web_domain_type($primary_id) {
		global $app;
		$rec = $app->db->queryOneRecord('SELECT type FROM web_domain WHERE domain_id = ?', $app->functions->intval($primary_id));
		return is_array($rec) ? $rec['type'] : '';
	}

	//* The child and vhost domain forms take their variant from the session, like the panel pages set it
	//* (remote API v1: the alias domain and website variants)
	private function web_form_variant($key, $type) {
		if(!$this->api_v1()) $_SESSION['s']['var'][$key] = $type;
	}

	//* An update gives log_retention and the PHP-FPM values of nginx their defaults only when they are sent empty,
	//* values that are not sent keep the stored ones (remote API v1: they get the defaults too)
	private function web_domain_update_defaults($params) {
		foreach(array('log_retention' => 30, 'pm_max_children' => 10, 'pm_start_servers' => 2, 'pm_min_spare_servers' => 1, 'pm_max_spare_servers' => 5) as $key => $value) {
			if(isset($params[$key]) ? $params[$key] == '' : $this->api_v1()) $params[$key] = $value;
		}
		return $params;
	}

	//* Refuses the id of a web_domain record of another type
	private function check_web_domain_type($primary_id, $type) {
		if($this->web_domain_type($primary_id) !== $type) {
			throw new SoapFault('invalid_id', 'The ID is not the ID of a web domain record of the type '.$type.'.');
		}
	}

	//* Delete and set_status refuse an existing web_domain record of another type, an id that does not exist changes nothing
	//* as before (remote API v1: not checked)
	private function check_existing_web_domain_type($primary_id, $type) {
		if(!$this->api_v1() && $this->web_domain_type($primary_id) !== '') $this->check_web_domain_type($primary_id, $type);
	}

	//* Returns only web_domain records of the given type (remote API v1: records of any type)
	private function web_domain_get_type($formdef_file, $primary_id, $type) {
		global $app, $conf;

		$app->uses('remoting_lib');
		$app->remoting_lib->loadFormDef($formdef_file);
		if(!isset($conf['remote_api_version']) || $conf['remote_api_version'] >= 2) {
			if(is_object($primary_id)) $primary_id = get_object_vars($primary_id);
			if(is_array($primary_id)) $primary_id['type'] = $type;
			elseif(is_numeric($primary_id) && $primary_id == -1) $primary_id = array('type' => $type);
			elseif(is_numeric($primary_id) && $primary_id > 0 && $this->web_domain_type($primary_id) !== $type) return array();
		}
		return $app->remoting_lib->getDataRecord($primary_id);
	}

	// ----------------------------------------------------------------------------------------------------------

	//* Get record details
	public function sites_web_vhost_aliasdomain_get($session_id, $primary_id)
	{
		global $app;

		if(!$this->checkPerm($session_id, 'sites_web_aliasdomain_get')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$this->web_form_variant('vhostdomain_type', 'aliasdomain');
		return $this->web_domain_get_type('../sites/form/web_vhost_domain.tform.php', $primary_id, 'vhostalias');
	}

	//* Add a record
	public function sites_web_vhost_aliasdomain_add($session_id, $client_id, $params)
	{
		global $app;
		if(!$this->checkPerm($session_id, 'sites_web_aliasdomain_add')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$this->web_form_variant('vhostdomain_type', 'aliasdomain');

		//* Set a few params to "not empty" values which get overwritten by the sites_web_domain_plugin
		if($params['document_root'] == '') $params['document_root'] = '-';
		if($params['system_user'] == '') $params['system_user'] = '-';
		if($params['system_group'] == '') $params['system_group'] = '-';
		if($params['log_retention'] == '') $params['log_retention'] = 30;
		if(isset($params['subdomain']) && $params['subdomain'] === '') $params['subdomain'] = 'none';

		//* Set a few defaults for nginx servers
		if($params['pm_max_children'] == '') $params['pm_max_children'] = 10;
		if($params['pm_start_servers'] == '') $params['pm_start_servers'] = 2;
		if($params['pm_min_spare_servers'] == '') $params['pm_min_spare_servers'] = 1;
		if($params['pm_max_spare_servers'] == '') $params['pm_max_spare_servers'] = 5;
		if(!isset($params['php_fpm_use_socket'])) $params['php_fpm_use_socket'] = 'y';

		if(!$this->api_v1()) $params['type'] = 'vhostalias';
		$domain_id = $this->insertQuery('../sites/form/web_vhost_domain.tform.php', $client_id, $params, 'sites:web_vhost_domain:on_after_insert');
		return $domain_id;
	}

	//* Update a record
	public function sites_web_vhost_aliasdomain_update($session_id, $client_id, $primary_id, $params)
	{
		if(!$this->checkPerm($session_id, 'sites_web_aliasdomain_update')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$this->web_form_variant('vhostdomain_type', 'aliasdomain');
		$this->check_web_domain_type($primary_id, 'vhostalias');
		$params['type'] = 'vhostalias';

		if(isset($params['subdomain']) && $params['subdomain'] === '') $params['subdomain'] = 'none';
		$params = $this->web_domain_update_defaults($params);

		$affected_rows = $this->updateQuery('../sites/form/web_vhost_domain.tform.php', $this->child_client_id($client_id), $primary_id, $params, 'sites:web_vhost_domain:on_after_update');
		return $affected_rows;
	}

	//* Delete a record
	public function sites_web_vhost_aliasdomain_delete($session_id, $primary_id)
	{
		global $app;

		if(!$this->checkPerm($session_id, 'sites_web_aliasdomain_delete')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$this->web_form_variant('vhostdomain_type', 'aliasdomain');
		$this->check_existing_web_domain_type($primary_id, 'vhostalias');
		$app->uses('tools_sites');
		$app->tools_sites->delete_web_domain_children($primary_id);
		$affected_rows = $this->deleteQuery('../sites/form/web_vhost_domain.tform.php', $primary_id);
		return $affected_rows;
	}

	// ----------------------------------------------------------------------------------------------------------

	//* Get record details
	public function sites_web_vhost_subdomain_get($session_id, $primary_id)
	{
		global $app;

		if(!$this->checkPerm($session_id, 'sites_web_subdomain_get')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$this->web_form_variant('vhostdomain_type', 'subdomain');
		return $this->web_domain_get_type('../sites/form/web_vhost_domain.tform.php', $primary_id, 'vhostsubdomain');
	}

	//* Add a record
	public function sites_web_vhost_subdomain_add($session_id, $client_id, $params)
	{
		global $app;
		if(!$this->checkPerm($session_id, 'sites_web_subdomain_add')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$this->web_form_variant('vhostdomain_type', 'subdomain');

		//* Set a few params to "not empty" values which get overwritten by the sites_web_domain_plugin
		if($params['document_root'] == '') $params['document_root'] = '-';
		if($params['system_user'] == '') $params['system_user'] = '-';
		if($params['system_group'] == '') $params['system_group'] = '-';
		if($params['log_retention'] == '') $params['log_retention'] = 30;
		if(isset($params['subdomain']) && $params['subdomain'] === '') $params['subdomain'] = 'none';

		//* Set a few defaults for nginx servers
		if($params['pm_max_children'] == '') $params['pm_max_children'] = 10;
		if($params['pm_start_servers'] == '') $params['pm_start_servers'] = 2;
		if($params['pm_min_spare_servers'] == '') $params['pm_min_spare_servers'] = 1;
		if($params['pm_max_spare_servers'] == '') $params['pm_max_spare_servers'] = 5;
		if(!isset($params['php_fpm_use_socket'])) $params['php_fpm_use_socket'] = 'y';

		if(!$this->api_v1()) $params['type'] = 'vhostsubdomain';
		$domain_id = $this->insertQuery('../sites/form/web_vhost_domain.tform.php', $client_id, $params, 'sites:web_vhost_domain:on_after_insert');
		return $domain_id;
	}

	//* Update a record
	public function sites_web_vhost_subdomain_update($session_id, $client_id, $primary_id, $params)
	{
		if(!$this->checkPerm($session_id, 'sites_web_subdomain_update')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$this->web_form_variant('vhostdomain_type', 'subdomain');
		$this->check_web_domain_type($primary_id, 'vhostsubdomain');
		$params['type'] = 'vhostsubdomain';

		if(isset($params['subdomain']) && $params['subdomain'] === '') $params['subdomain'] = 'none';
		$params = $this->web_domain_update_defaults($params);

		$affected_rows = $this->updateQuery('../sites/form/web_vhost_domain.tform.php', $this->child_client_id($client_id), $primary_id, $params, 'sites:web_vhost_domain:on_after_update');
		return $affected_rows;
	}

	//* Delete a record
	public function sites_web_vhost_subdomain_delete($session_id, $primary_id)
	{
		global $app;

		if(!$this->checkPerm($session_id, 'sites_web_subdomain_delete')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$this->web_form_variant('vhostdomain_type', 'subdomain');
		$this->check_existing_web_domain_type($primary_id, 'vhostsubdomain');
		$app->uses('tools_sites');
		$app->tools_sites->delete_web_domain_children($primary_id);
		$affected_rows = $this->deleteQuery('../sites/form/web_vhost_domain.tform.php', $primary_id);
		return $affected_rows;
	}

	// -----------------------------------------------------------------------------------------------

	//* Get record details
	public function sites_web_aliasdomain_get($session_id, $primary_id)
	{
		global $app;

		if(!$this->checkPerm($session_id, 'sites_web_aliasdomain_get')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		return $this->web_domain_get_type('../sites/form/web_childdomain.tform.php', $primary_id, 'alias');
	}

	//* Add a record
	public function sites_web_aliasdomain_add($session_id, $client_id, $params)
	{
		if(!$this->checkPerm($session_id, 'sites_web_aliasdomain_add')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		if(!$this->api_v1()) $params['type'] = 'alias';
		return $this->insertQuery('../sites/form/web_childdomain.tform.php', $client_id, $params);
	}

	//* Update a record
	public function sites_web_aliasdomain_update($session_id, $client_id, $primary_id, $params)
	{
		if(!$this->checkPerm($session_id, 'sites_web_aliasdomain_update')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$this->check_web_domain_type($primary_id, 'alias');
		$params['type'] = 'alias';
		$affected_rows = $this->updateQuery('../sites/form/web_childdomain.tform.php', $this->child_client_id($client_id), $primary_id, $params);
		$this->child_domain_parent_group($primary_id);
		return $affected_rows;
	}

	//* Delete a record
	public function sites_web_aliasdomain_delete($session_id, $primary_id)
	{
		if(!$this->checkPerm($session_id, 'sites_web_aliasdomain_delete')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$this->check_existing_web_domain_type($primary_id, 'alias');
		$affected_rows = $this->deleteQuery('../sites/form/web_childdomain.tform.php', $primary_id);
		return $affected_rows;
	}

	// ----------------------------------------------------------------------------------------------------------

	//* Get record details
	public function sites_web_subdomain_get($session_id, $primary_id)
	{
		global $app;

		if(!$this->checkPerm($session_id, 'sites_web_subdomain_get')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$this->web_form_variant('childdomain_type', 'subdomain');
		return $this->web_domain_get_type('../sites/form/web_childdomain.tform.php', $primary_id, 'subdomain');
	}

	//* Add a record
	public function sites_web_subdomain_add($session_id, $client_id, $params)
	{
		if(!$this->checkPerm($session_id, 'sites_web_subdomain_add')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$this->web_form_variant('childdomain_type', 'subdomain');
		if(!$this->api_v1()) $params['type'] = 'subdomain';
		return $this->insertQuery('../sites/form/web_childdomain.tform.php', $client_id, $params);
	}

	//* Update a record
	public function sites_web_subdomain_update($session_id, $client_id, $primary_id, $params)
	{
		if(!$this->checkPerm($session_id, 'sites_web_subdomain_update')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$this->web_form_variant('childdomain_type', 'subdomain');
		$this->check_web_domain_type($primary_id, 'subdomain');
		$params['type'] = 'subdomain';
		$affected_rows = $this->updateQuery('../sites/form/web_childdomain.tform.php', $this->child_client_id($client_id), $primary_id, $params);
		$this->child_domain_parent_group($primary_id);
		return $affected_rows;
	}

	//* Delete a record
	public function sites_web_subdomain_delete($session_id, $primary_id)
	{
		if(!$this->checkPerm($session_id, 'sites_web_subdomain_delete')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$this->web_form_variant('childdomain_type', 'subdomain');
		$this->check_existing_web_domain_type($primary_id, 'subdomain');
		$affected_rows = $this->deleteQuery('../sites/form/web_childdomain.tform.php', $primary_id);
		return $affected_rows;
	}

	// ----------------------------------------------------------------------------------------------------------

	//* Get record details
	public function sites_web_folder_get($session_id, $primary_id)
	{
		global $app;

		if(!$this->checkPerm($session_id, 'sites_web_folder_get')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$app->uses('remoting_lib');
		$app->remoting_lib->loadFormDef('../sites/form/web_folder.tform.php');
		return $app->remoting_lib->getDataRecord($primary_id);
	}

	//* A folder is protected once per website and a user exists once per folder, like in the panel (remote API v1: not checked)
	private function web_folder_unique($table, $index, $parent_column, $column, $primary_id, $params, $message) {
		global $app;
		if($this->api_v1()) return;
		$primary_id = $app->functions->intval($primary_id);
		$stored = $primary_id > 0 ? $app->db->queryOneRecord('SELECT ?? AS parent, ?? AS value FROM ?? WHERE ?? = ?', $parent_column, $column, $table, $index, $primary_id) : array();
		if(!is_array($stored)) return;
		$parent = isset($params[$parent_column]) ? $params[$parent_column] : (isset($stored['parent']) ? $stored['parent'] : null);
		$value = isset($params[$column]) ? $params[$column] : (isset($stored['value']) ? $stored['value'] : null);
		if($parent === null || $value === null) return;
		$rec = $app->db->queryOneRecord('SELECT ?? FROM ?? WHERE ?? = ? AND ?? = ? AND ?? != ?', $index, $table, $parent_column, $parent, $column, $value, $index, $primary_id);
		if(is_array($rec)) throw new SoapFault('data_processing_error', $message);
	}

	//* Add a record
	public function sites_web_folder_add($session_id, $client_id, $params)
	{
		if(!$this->checkPerm($session_id, 'sites_web_folder_add')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$this->web_folder_unique('web_folder', 'web_folder_id', 'parent_domain_id', 'path', 0, $params, 'error_folder_already_protected_txt');
		return $this->insertQuery('../sites/form/web_folder.tform.php', $client_id, $params);
	}

	//* Update a record
	public function sites_web_folder_update($session_id, $client_id, $primary_id, $params)
	{
		if(!$this->checkPerm($session_id, 'sites_web_folder_update')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$this->web_folder_unique('web_folder', 'web_folder_id', 'parent_domain_id', 'path', $primary_id, $params, 'error_folder_already_protected_txt');
		$affected_rows = $this->updateQuery('../sites/form/web_folder.tform.php', $client_id, $primary_id, $params);
		return $affected_rows;
	}

	//* Delete a record
	public function sites_web_folder_delete($session_id, $primary_id)
	{
		global $app;
		if(!$this->checkPerm($session_id, 'sites_web_folder_delete')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}

		// Delete all users that belong to this folder. - taken from web_folder_delete.php
		$records = $app->db->queryAllRecords("SELECT web_folder_user_id FROM web_folder_user WHERE web_folder_id = ?", $primary_id);
		foreach($records as $rec) {
			$this->deleteQuery('../sites/form/web_folder_user.tform.php', $rec['web_folder_user_id']);
			//$app->db->datalogDelete('web_folder_user','web_folder_user_id',$rec['web_folder_user_id']);
		}
		unset($records);

		$affected_rows = $this->deleteQuery('../sites/form/web_folder.tform.php', $primary_id);
		return $affected_rows;
	}

	// -----------------------------------------------------------------------------------------------

	//* Get record details
	public function sites_web_folder_user_get($session_id, $primary_id)
	{
		global $app;

		if(!$this->checkPerm($session_id, 'sites_web_folder_user_get')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$app->uses('remoting_lib');
		$app->remoting_lib->loadFormDef('../sites/form/web_folder_user.tform.php');
		return $app->remoting_lib->getDataRecord($primary_id);
	}

	//* Add a record
	public function sites_web_folder_user_add($session_id, $client_id, $params)
	{
		if(!$this->checkPerm($session_id, 'sites_web_folder_user_add')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$this->web_folder_unique('web_folder_user', 'web_folder_user_id', 'web_folder_id', 'username', 0, $params, 'error_user_exists_already_txt');
		return $this->insertQuery('../sites/form/web_folder_user.tform.php', $client_id, $params);
	}

	//* Update a record
	public function sites_web_folder_user_update($session_id, $client_id, $primary_id, $params)
	{
		if(!$this->checkPerm($session_id, 'sites_web_folder_user_update')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$this->web_folder_unique('web_folder_user', 'web_folder_user_id', 'web_folder_id', 'username', $primary_id, $params, 'error_user_exists_already_txt');
		$affected_rows = $this->updateQuery('../sites/form/web_folder_user.tform.php', $client_id, $primary_id, $params);
		return $affected_rows;
	}

	//* Delete a record
	public function sites_web_folder_user_delete($session_id, $primary_id)
	{
		if(!$this->checkPerm($session_id, 'sites_web_folder_user_delete')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$affected_rows = $this->deleteQuery('../sites/form/web_folder_user.tform.php', $primary_id);
		return $affected_rows;
	}

	/**
	 * Gets sites by $sys_userid & $sys_groupid
	 * @param int  session id
	 * @param int  user id
	 * @param array list of groups
	 * @return mixed array with sites by user
	 * @author Julio Montoya <gugli100@gmail.com> BeezNest 2010
	 */


	public function client_get_sites_by_user($session_id, $sys_userid, $sys_groupid) {
		global $app;
		if(!$this->checkPerm($session_id, 'client_get_sites_by_user')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$sys_userid  = $app->functions->intval($sys_userid);
		$sys_groupid = explode(',', $sys_groupid);
		$new_group = array();
		foreach($sys_groupid as $group_id) {
			$new_group[] = $app->functions->intval( $group_id);
		}
		$group_list = implode(',', $new_group);
		$sql ="SELECT domain, domain_id, document_root, active FROM web_domain WHERE ( (sys_userid = $sys_userid  AND sys_perm_user LIKE '%r%') OR (sys_groupid IN ($group_list) AND sys_perm_group LIKE '%r%') OR  sys_perm_other LIKE '%r%') AND type = 'vhost'";
		$result = $app->db->queryAllRecords($sql);
		if(isset($result)) {
			return $result;
		} else {
			throw new SoapFault('no_client_found', 'There is no site for this user');
			return false;
		}
	}



	/**
	 * Change domains status
	 * @param int  session id
	 * @param int  site id
	 * @param string active or inactive string
	 * @return mixed false if error
	 * @author Julio Montoya <gugli100@gmail.com> BeezNest 2010
	 */
	public function sites_web_domain_set_status($session_id, $primary_id, $status) {
		global $app;
		if(!$this->checkPerm($session_id, 'sites_web_domain_set_status')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		if(in_array($status, array('active', 'inactive'))) {
			if ($status == 'active') {
				$status = 'y';
			} else {
				$status = 'n';
			}
			$this->check_existing_web_domain_type($primary_id, 'vhost');
			$app->remoting_lib->loadFormDef('../sites/form/web_vhost_domain.tform.php');
			$params = $app->remoting_lib->getDataRecord($primary_id);
			$params['active'] = $status;

			$affected_rows = $this->updateQuery('../sites/form/web_vhost_domain.tform.php', 0, $primary_id, $params);
			return $affected_rows;
		} else {
			throw new SoapFault('status_undefined', 'The status is not available');
			return false;
		}
	}

	/**
	 * Get all databases by user
	 * @author Julio Montoya <gugli100@gmail.com> BeezNest 2010
	 */
	public function sites_database_get_all_by_user($session_id, $client_id)
	{
		global $app;
		if(!$this->checkPerm($session_id, 'sites_database_get')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$client_id = $app->functions->intval($client_id);
		$sql = "SELECT d.database_id, d.database_name, d.database_user_id, d.database_ro_user_id, du.database_user, du.database_password FROM web_database d LEFT JOIN web_database_user du ON (du.database_user_id = d.database_user_id) INNER JOIN sys_group g ON (g.groupid = d.sys_groupid) WHERE g.client_id = ?";
		$all = $app->db->queryAllRecords($sql, $client_id);
		return $all;
	}

	//** backup functions -----------------------------------------------------------------------------------
	public function sites_web_domain_backup_list($session_id, $site_id = null)
	{
		global $app;

		if(!$this->checkPerm($session_id, 'sites_web_domain_backup')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}

		$result = $app->db->queryAllRecords("SELECT * FROM web_backup".(($site_id != null)?' WHERE parent_domain_id = ?':''), $site_id);
		return $result;
	}

	//* Backup download and restoration by Abdi Joseph
	public function sites_web_domain_backup($session_id, $primary_id, $action_type)
	{
		global $app;

		if(!$this->checkPerm($session_id, 'sites_web_domain_backup')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}

		if(!preg_match('/^\d+$/', (string)$primary_id)) {
			throw new SoapFault('invalid_backup_id', 'Invalid backup_id');
			return false;
		}
		$primary_id = (int)$primary_id;

		//*Set variables
		$backup_record = $app->db->queryOneRecord("SELECT * FROM `web_backup` WHERE `backup_id`= ?", $primary_id);
		$server_id = $backup_record['server_id'];

		//*Set default action state
		$action_state = "pending";
		$tstamp = time();

		//* Basic validation of variables
		if ($server_id <= 0) {
			throw new SoapFault('invalid_backup_id', "Invalid or non existant backup_id $primary_id");
			return false;
		}

		if ($action_type != 'backup_download' and $action_type != 'backup_restore' and $action_type != 'backup_delete') {
			throw new SoapFault('invalid_action', "Invalid action_type $action_type");
			return false;
		}

		//* Validate instance
		$instance_record = $app->db->queryOneRecord("SELECT * FROM `sys_remoteaction` WHERE `action_param`= ? and `action_type`= ? and `action_state`= ?", $primary_id, $action_type, 'pending');
		if ($instance_record['action_id'] >= 1) {
			throw new SoapFault('duplicate_action', "There is already a pending $action_type action");
			return false;
		}

		//* Save the record
		if ($app->db->query("INSERT INTO `sys_remoteaction` SET `server_id` = ?, `tstamp` = ?, `action_type` = ?, `action_param` = ?, `action_state` = ?", $server_id, $tstamp, $action_type, $primary_id, $action_state)) {
			return true;
		} else {
			return false;
		}
	}

	//** quota functions -----------------------------------------------------------------------------------
	public function quota_get_by_user($session_id, $client_id)
	{
		global $app;
		$app->uses('quota_lib');

		if(!$this->checkPerm($session_id, 'quota_get_by_user')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}

		return $app->quota_lib->get_quota_data($client_id, false);
	}

	public function trafficquota_get_by_user($session_id, $client_id, $lastdays = 0)
	{
		global $app;
		$app->uses('quota_lib');

		if(!$this->checkPerm($session_id, 'trafficquota_get_by_user')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		if ($client_id != null)
			$client_id = $app->functions->intval($client_id);

		return $app->quota_lib->get_trafficquota_data($client_id, $lastdays);
	}

	public function ftptrafficquota_data($session_id, $client_id, $lastdays = 0)
	{
		global $app;
		$app->uses('quota_lib');

		if(!$this->checkPerm($session_id, 'trafficquota_get_by_user')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		if ($client_id != null)
			$client_id = $app->functions->intval($client_id);

		return $app->quota_lib->get_ftptrafficquota_data($client_id, $lastdays);
	}

	public function databasequota_get_by_user($session_id, $client_id)
	{
		global $app;
		$app->uses('quota_lib');

		if(!$this->checkPerm($session_id, 'databasequota_get_by_user')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}

		return $app->quota_lib->get_databasequota_data($client_id, false);
	}

	// ----------------------------------------------------------------------------------------------------------

	//* Get record details
	public function sites_webdav_user_get($session_id, $primary_id)
	{
		global $app;

		if(!$this->checkPerm($session_id, 'sites_webdav_user_get')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$app->uses('remoting_lib');
		$app->remoting_lib->loadFormDef('../sites/form/webdav_user.tform.php');
		return $app->remoting_lib->getDataRecord($primary_id);
	}

	//* Add a record
	public function sites_webdav_user_add($session_id, $client_id, $params)
	{
		if(!$this->checkPerm($session_id, 'sites_webdav_user_add')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		return $this->insertQuery('../sites/form/webdav_user.tform.php', $client_id, $params);
	}

	//* Update a record
	public function sites_webdav_user_update($session_id, $client_id, $primary_id, $params)
	{
		if(!$this->checkPerm($session_id, 'sites_webdav_user_update')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		$affected_rows = $this->updateQuery('../sites/form/webdav_user.tform.php', $client_id, $primary_id, $params);
		return $affected_rows;
	}

	//* Delete a record
	public function sites_webdav_user_delete($session_id, $primary_id)
	{
		global $app;
		if(!$this->checkPerm($session_id, 'sites_webdav_user_delete')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}

		$affected_rows = $this->deleteQuery('../sites/form/webdav_user.tform.php', $primary_id);
		return $affected_rows;
	}


}

?>
