<?php

/*
Copyright (c) 2026, Till Brehm, projektfarm Gmbh
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.
    * Neither the name of ISPConfig nor the names of its contributors
      may be used to endorse or promote products derived from this software without
      specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

class validate_mail {

	function get_error($errmsg) {
		global $app;

		if(isset($app->tform->wordbook[$errmsg])) {
			return $app->tform->wordbook[$errmsg]."<br>\r\n";
		} else {
			return $errmsg."<br>\r\n";
		}
	}

	//* The mail settings of the server of the mailbox domain
	private function mailbox_config() {
		global $app;

		$record = isset($app->remoting_lib->primary_id) ? $app->remoting_lib->dataRecord : $app->tform_actions->dataRecord;
		$domain = $app->db->queryOneRecord("SELECT server_id FROM mail_domain WHERE domain = ?", (string)substr((string)strrchr((string)$record['email'], '@'), 1));
		$app->uses('getconf');
		return $app->getconf->get_server_config(is_array($domain) ? $domain['server_id'] : (isset($record['server_id']) ? $record['server_id'] : 0), 'mail');
	}

	//* An absolute path without empty, . or .. parts, wildcards and control characters
	private function is_clean_path($path) {
		$path = rtrim((string)$path, '/');
		if(substr($path, 0, 1) != '/' || strpos($path, '*') !== false || preg_match('/[\x00-\x1F\x7F]/', $path)) return false;
		foreach(explode('/', substr($path, 1)) as $part) {
			if($part == '' || $part == '.' || $part == '..') return false;
		}
		return true;
	}

	//* The maildir lies below the mail home or below the fixed part of the maildir path of the server, as the server checks it
	function maildir($field_name, $field_value, $validator) {
		if($this->is_clean_path($field_value)) {
			$mail_config = $this->mailbox_config();
			$maildir = rtrim($field_value, '/');
			$fixed = substr($mail_config['maildir_path'], 0, strcspn($mail_config['maildir_path'], '['));
			foreach(array(rtrim($mail_config['homedir_path'], '/').'/', substr($fixed, 0, (int)strrpos($fixed, '/') + 1)) as $base) {
				if(strlen($base) > 1 && strpos($maildir, $base) === 0 && strlen($maildir) > strlen($base)) return;
			}
		}
		return $this->get_error($validator['errmsg']);
	}

	function homedir($field_name, $field_value, $validator) {
		if(!$this->is_clean_path($field_value)) return $this->get_error($validator['errmsg']);
	}

	//* A list of email addresses, separated by comma, semicolon or space
	function email_list($field_name, $field_value, $validator) {
		if((string)$field_value === '') return;
		foreach(preg_split('/[,;\s]+/', trim($field_value)) as $target) {
			if($target == '' || filter_var($target, FILTER_VALIDATE_EMAIL) === false) return $this->get_error($validator['errmsg']);
		}
	}

	//* The source of a white- or blacklist entry: a host name or IP address (client) or an address, user@, @domain or domain
	function wblist_source($field_name, $field_value, $validator) {
		global $app;

		$record = isset($app->remoting_lib->primary_id) ? $app->remoting_lib->dataRecord : $app->tform_actions->dataRecord;
		$regex = (isset($record['type']) && $record['type'] == 'client') ? '/^[A-Za-z0-9.:_-]{1,253}$/D' : '/^[^@\x00-\x20\x7F"\\\\]{0,253}@?[A-Za-z0-9.-]{0,253}$/D';
		if(!preg_match($regex, (string)$field_value)) return $this->get_error($validator['errmsg']);
	}

}
