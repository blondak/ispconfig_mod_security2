<?php

/*
Copyright (c) 2007, Till Brehm, projektfarm Gmbh
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.
    * Neither the name of ISPConfig nor the names of its contributors
      may be used to endorse or promote products derived from this software without
      specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

class getconf {

	private $config;
	private $security_config;

	public function get_server_config($server_id, $section = '') {
		global $app;

		if(!isset($this->config[$server_id])) {
			$app->uses('ini_parser');
			$server_id = $app->functions->intval($server_id);
			$server = $app->db->queryOneRecord('SELECT config FROM server WHERE server_id = ?', $server_id);
			$this->config[$server_id] = $app->ini_parser->parse_ini_string(stripslashes($server['config']));
		}
		return ($section == '') ? $this->config[$server_id] : $this->config[$server_id][$section];
	}

	public function get_global_config($section = '') {
		global $app;

		if(!isset($this->config['global'])) {
			$app->uses('ini_parser');
			$tmp = $app->db->queryOneRecord('SELECT config FROM sys_ini WHERE sysini_id = 1');
			$this->config['global'] = $app->ini_parser->parse_ini_string(stripslashes($tmp['config']));
		}
		return ($section == '') ? $this->config['global'] : $this->config['global'][$section];
	}

	/*
	 * The config columns in the server and sys_ini tables are stored escaped
	 * (tform::encode() quotes the section that is being saved). get_server_config()
	 * and get_global_config() unescape the whole blob for reading. Code that writes
	 * a modified config back with ini_parser::get_ini_string() must start from the
	 * raw column instead, otherwise every section that is not being edited loses
	 * one level of escaping on each save (e.g. backslashes in smtp_pass).
	 * Values that are added to the returned array must be escaped with $app->db->quote().
	 */
	public function get_server_config_raw($server_id) {
		global $app;

		$app->uses('ini_parser');
		$server_id = $app->functions->intval($server_id);
		$server = $app->db->queryOneRecord('SELECT config FROM server WHERE server_id = ?', $server_id);
		return $app->ini_parser->parse_ini_string($server['config']);
	}

	public function get_global_config_raw() {
		global $app;

		$app->uses('ini_parser');
		$tmp = $app->db->queryOneRecord('SELECT config FROM sys_ini WHERE sysini_id = 1');
		return $app->ini_parser->parse_ini_string($tmp['config']);
	}
	
	// Function has been moved to $app->get_security_config($section)
	public function get_security_config($section = '') {
		global $app;
		
		if(is_array($this->security_config)) {
			return ($section == '') ? $this->security_config : $this->security_config[$section];
		} else {
			$app->uses('ini_parser');
			$security_config_path = '/usr/local/ispconfig/security/security_settings.ini';
			if(!is_readable($security_config_path)) $security_config_path = realpath(ISPC_ROOT_PATH.'/../security/security_settings.ini');
			$this->security_config = $app->ini_parser->parse_ini_string(file_get_contents($security_config_path));

			return ($section == '') ? $this->security_config : $this->security_config[$section];
		}
	}

}

?>
