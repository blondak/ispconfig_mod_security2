<?php

/*
Copyright (c) 2026, Till Brehm, ISPConfig UG
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.
    * Neither the name of ISPConfig nor the names of its contributors
      may be used to endorse or promote products derived from this software without
      specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

/* Validators for paths and host names of the server and system settings, every field passes its own errmsg */
class validate_server_config {

	function get_error($errmsg) {
		global $app;

		if(isset($app->tform->wordbook[$errmsg])) {
			return $app->tform->wordbook[$errmsg]."<br>\r\n";
		} else {
			return $errmsg."<br>\r\n";
		}
	}

	/* One path: absolute (relative: no leading '/' or '-'), characters a-z A-Z 0-9 . _ / -, no '..' segment, not only '/' */
	private function path_ok($path, $relative) {
		if(strlen($path) > 255 || !preg_match('@^[a-zA-Z0-9._/-]+$@D', $path)) return false;
		if($relative) {
			if($path[0] == '/' || $path[0] == '-') return false;
		} elseif($path[0] != '/' || trim($path, '/') === '') {
			return false;
		}
		return !in_array('..', explode('/', $path), true);
	}

	/*
		Path or list of paths. Options: 'allow_empty', 'relative', 'separator' (':' or ' ', every element is checked),
		'mixed' (list elements may also be plain names without '/'), 'placeholders' (the allowed placeholders, e.g.
		array('[domain]'), each checked as 'x'; or placeholder => value it is checked as, e.g. '[website_path]' => '/x').
	*/
	function path($field_name, $field_value, $validator) {
		$field_value = (string)$field_value;
		if($field_value === '' && !empty($validator['allow_empty'])) return '';
		if(isset($validator['placeholders']) && is_array($validator['placeholders'])) {
			foreach($validator['placeholders'] as $placeholder => $value) {
				if(is_int($placeholder)) $field_value = str_replace($value, 'x', $field_value);
				else $field_value = str_replace($placeholder, $value, $field_value);
			}
		}
		$elements = (isset($validator['separator']) && $validator['separator'] !== '') ? explode($validator['separator'], $field_value) : array($field_value);
		foreach($elements as $element) {
			$relative = !empty($validator['relative']) || (!empty($validator['mixed']) && strpos($element, '/') === false);
			if(!$this->path_ok($element, $relative)) return $this->get_error($validator['errmsg']);
		}
		return '';
	}

	/* Host name or IP address. Options: 'allow_empty', 'port' (also 'host:port', '[host]', '[host]:port', '[ipv6]:port') */
	function host($field_name, $field_value, $validator) {
		$field_value = (string)$field_value;
		if($field_value === '' && !empty($validator['allow_empty'])) return '';
		$host = $field_value;
		$port = '';
		if(!empty($validator['port'])) {
			if(preg_match('/^\[([^\[\]]+)\](?::([0-9]{1,5}))?$/D', $field_value, $m)) {
				$host = $m[1];
				$port = isset($m[2]) ? $m[2] : '';
			} elseif(preg_match('/^([^:]+):([0-9]{1,5})$/D', $field_value, $m)) {
				$host = $m[1];
				$port = $m[2];
			}
			if($port !== '' && ($port < 1 || $port > 65535)) return $this->get_error($validator['errmsg']);
		}
		if(filter_var($host, FILTER_VALIDATE_IP) === false && filter_var($host, FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME) === false) {
			return $this->get_error($validator['errmsg']);
		}
		return '';
	}

}
