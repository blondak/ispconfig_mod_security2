<?php
/*
Copyright (c) 2026, Till Brehm, projektfarm Gmbh
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.
    * Neither the name of ISPConfig nor the names of its contributors
      may be used to endorse or promote products derived from this software without
      specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

//* The records that are deleted together with a mail domain or a mailbox (panel and remote API)
class tools_mail {

	//* $domain: the mail_domain record that is about to be deleted
	function delete_mail_domain_records($domain) {
		global $app;

		$name = $domain['domain'];
		$server_id = $app->functions->intval($domain['server_id']);

		// the forwardings of this domain and the aliases of the domain's owner to it
		$records = $app->db->queryAllRecords("SELECT forwarding_id as id FROM mail_forwarding WHERE (source like ? AND server_id = ?) OR (destination like ? AND type != 'forward' AND sys_groupid = ?)", '%@' . $name, $server_id, '%@' . $name, $domain['sys_groupid']);
		foreach($records as $rec) {
			$app->db->datalogDelete('mail_forwarding', 'forwarding_id', $rec['id']);
		}

		// the fetchmail accounts that deliver into this domain
		$records = $app->db->queryAllRecords("SELECT mailget_id as id FROM mail_get WHERE destination like ? AND server_id = ?", '%@' . $name, $server_id);
		foreach($records as $rec) {
			$app->db->datalogDelete('mail_get', 'mailget_id', $rec['id']);
		}

		// the mailboxes of this domain with their filters
		$records = $app->db->queryAllRecords("SELECT mailuser_id as id FROM mail_user WHERE email like ? AND server_id = ?", '%@' . $name, $server_id);
		foreach($records as $rec) {
			$filters = $app->db->queryAllRecords("SELECT filter_id FROM mail_user_filter WHERE mailuser_id = ?", $rec['id']);
			foreach($filters as $filter) {
				$app->db->datalogDelete('mail_user_filter', 'filter_id', $filter['filter_id']);
			}
			$app->db->datalogDelete('mail_user', 'mailuser_id', $rec['id']);
		}

		// the spamfilter users of this domain with their white- and blacklist entries
		$records = $app->db->queryAllRecords("SELECT id FROM spamfilter_users WHERE email like ? AND server_id = ?", '%@' . $name, $server_id);
		foreach($records as $rec) {
			$wblists = $app->db->queryAllRecords("SELECT wblist_id FROM spamfilter_wblist WHERE rid = ?", $rec['id']);
			foreach($wblists as $wblist) {
				$app->db->datalogDelete('spamfilter_wblist', 'wblist_id', $wblist['wblist_id']);
			}
			$app->db->datalogDelete('spamfilter_users', 'id', $rec['id']);
		}

		// the mailing lists of this domain
		$records = $app->db->queryAllRecords("SELECT mailinglist_id FROM mail_mailinglist WHERE domain = ? AND server_id = ?", $name, $server_id);
		foreach($records as $rec) {
			$app->db->datalogDelete('mail_mailinglist', 'mailinglist_id', $rec['mailinglist_id']);
		}
	}

	//* $mailuser: the mail_user record that is about to be deleted
	function delete_mail_user_records($mailuser) {
		global $app;

		// the spamfilter user of the mailbox with its white- and blacklist entries
		$tmp_user = $app->db->queryOneRecord("SELECT id FROM spamfilter_users WHERE email = ?", $mailuser['email']);
		if(is_array($tmp_user) && isset($tmp_user['id'])) {
			$tmp_wblists = $app->db->queryAllRecords("SELECT wblist_id FROM spamfilter_wblist WHERE rid = ?", $tmp_user['id']);
			if(is_array($tmp_wblists)) {
				foreach($tmp_wblists as $tmp) {
					$app->db->datalogDelete('spamfilter_wblist', 'wblist_id', $tmp['wblist_id']);
				}
			}
			$app->db->datalogDelete('spamfilter_users', 'id', $tmp_user['id']);
		}

		// the filters of the mailbox
		$tmp_filters = $app->db->queryAllRecords("SELECT filter_id FROM mail_user_filter WHERE mailuser_id = ?", $mailuser['mailuser_id']);
		if(is_array($tmp_filters)) {
			foreach($tmp_filters as $tmp) {
				$app->db->datalogDelete('mail_user_filter', 'filter_id', $tmp['filter_id']);
			}
		}

		// the fetchmail accounts that deliver into this mailbox
		$tmp_mailgets = $app->db->queryAllRecords("SELECT mailget_id FROM mail_get WHERE destination = ?", $mailuser['email']);
		if(is_array($tmp_mailgets)) {
			foreach($tmp_mailgets as $tmp) {
				$app->db->datalogDelete('mail_get', 'mailget_id', $tmp['mailget_id']);
			}
		}
	}
}
