<?php

/*
Copyright (c) 2008, Till Brehm, projektfarm Gmbh
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.
    * Neither the name of ISPConfig nor the names of its contributors
      may be used to endorse or promote products derived from this software without
      specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

class custom_datasource {

	function master_templates($field, $record) {
		global $app, $conf;
		$records = $app->db->queryAllRecords("SELECT template_id,template_name FROM client_template WHERE template_type ='m' and ".$app->tform->getAuthSQL('r'));
		$records_new[0] = $app->lng('Custom');
		foreach($records as $rec) {
			$key = $rec['template_id'];
			$records_new[$key] = $rec['template_name'];
		}
		return $records_new;
	}

	function dns_servers($field, $record) {
		global $app, $conf;

		if($_SESSION["s"]["user"]["typ"] == 'user') {
			// Get the limits of the client
			$client_group_id = $app->functions->intval($_SESSION["s"]["user"]["default_group"]);
			$client = $app->db->queryOneRecord("SELECT dns_servers FROM sys_group, client WHERE sys_group.client_id = client.client_id and sys_group.groupid = ?", $client_group_id);
			$sql = "SELECT server_id,server_name FROM server WHERE server_id in (?)";
		} else {
			$sql = "SELECT server_id,server_name FROM server WHERE dns_server = 1 ORDER BY server_name AND mirror_server_id = 0";
		}
		$records = $app->db->queryAllRecords($sql, $client['dns_servers']);
		$records_new = array();
		if(is_array($records)) {
			foreach($records as $rec) {
				$key = $rec['server_id'];
				$records_new[$key] = $rec['server_name'];
			}
		}
		return $records_new;
	}

	function slave_dns_servers($field, $record) {
		global $app, $conf;

		if($_SESSION["s"]["user"]["typ"] == 'user') {
			// Get the limits of the client
			$client_group_id = $app->functions->intval($_SESSION["s"]["user"]["default_group"]);
			$client = $app->db->queryOneRecord("SELECT default_slave_dnsserver FROM sys_group, client WHERE sys_group.client_id = client.client_id and sys_group.groupid = ?", $client_group_id);
			$sql = "SELECT server_id,server_name FROM server WHERE server_id = ?";
		} else {
			$sql = "SELECT server_id,server_name FROM server WHERE dns_server = 1 AND mirror_server_id = 0 ORDER BY server_name";
		}
		$records = $app->db->queryAllRecords($sql, $client['default_slave_dnsserver']);
		$records_new = array();
		if(is_array($records)) {
			foreach($records as $rec) {
				$key = $rec['server_id'];
				$records_new[$key] = $rec['server_name'];
			}
		}
		return $records_new;
	}

	function webdav_domains($field, $record) {
		global $app, $conf;

		$servers = $app->db->queryAllRecords("SELECT * FROM server WHERE active = 1 AND mirror_server_id = 0");
		$server_ids = array();
		$app->uses('getconf');
		if(is_array($servers) && !empty($servers)){
			foreach($servers as $server){
				$web_config = $app->getconf->get_server_config($server['server_id'], 'web');
				if($web_config['server_type'] != 'nginx') $server_ids[] = $server['server_id'];
			}
		}
		if(count($server_ids) == 0) return array();
		$records = $app->db->queryAllRecords("SELECT web_domain.domain_id, CONCAT(web_domain.domain, ' :: ', server.server_name) AS parent_domain FROM web_domain, server WHERE web_domain.type = 'vhost' AND web_domain.server_id IN ? AND web_domain.server_id = server.server_id AND ".$app->tform->getAuthSQL('r', 'web_domain')." ORDER BY web_domain.domain", $server_ids);

		$records_new = array();
		if(is_array($records)) {
			foreach($records as $rec) {
				$key = $rec['domain_id'];
				$records_new[$key] = $rec['parent_domain'];
			}
		}
		return $records_new;
	}


	function client_servers($field, $record) {
		global $app, $conf;

		$server_type = $field['name'];

		switch($server_type) {
		case 'default_mailserver':
			$field = 'mail_server';
			break;
		case 'default_webserver':
			$field = 'web_server';
			break;
		case 'default_dnsserver':
			$field = 'dns_server';
			break;
		case 'default_slave_dnsserver':
			$field = 'dns_server';
			break;
		case 'default_fileserver':
			$field = 'file_server';
			break;
		case 'default_dbserver':
			$field = 'db_server';
			break;
		case 'default_vserverserver':
			$field = 'vserver_server';
			break;
		case 'mail_servers':
			$field = 'mail_server';
			break;
		case 'web_servers':
			$field = 'web_server';
			break;
		case 'dns_servers':
			$field = 'dns_server';
			break;
		case 'db_servers':
			$field = 'db_server';
			break;
		case 'default_xmppserver':
			$field = 'xmpp_server';
			break;
		case 'xmpp_servers':
			$field = 'xmpp_server';
			break;
		default:
			$field = 'web_server';
			break;
		}

		if($_SESSION["s"]["user"]["typ"] == 'user') {
			// Get the limits of the client
			$client_group_id = $app->functions->intval($_SESSION["s"]["user"]["default_group"]);
			$sql = "SELECT $server_type as server_id FROM sys_group, client WHERE sys_group.client_id = client.client_id and sys_group.groupid = ?";
			$client = $app->db->queryOneRecord($sql, $client_group_id);
			if($client['server_id'] > 0) {
				///* Select the available servers for the client
				$clientservers = explode(',',$client['server_id']);
				$sql = "SELECT server_id,server_name FROM server WHERE server_id IN ? ORDER BY server_name";
				$records = $app->db->queryAllRecords($sql,$clientservers);
			} else {
				//* Not able to find the clients defaults, use this as fallback and add a warning message to the log
				$app->log('Unable to find default server for client in custom_datasource.inc.php', 1);
				$sql = "SELECT server_id,server_name FROM server WHERE ?? = 1 AND mirror_server_id = 0 ORDER BY server_name";
				$records = $app->db->queryAllRecords($sql, $field);
			}
		} else {
			//* The logged in user is admin, so we show him all available servers of a specific type.
			$sql = "SELECT server_id,server_name FROM server WHERE ?? = 1 AND mirror_server_id = 0 ORDER BY server_name";
			$records = $app->db->queryAllRecords($sql, $field);
		}

		
		$records_new = array();
		if(is_array($records)) {
			foreach($records as $rec) {
				$key = $rec['server_id'];
				$records_new[$key] = $rec['server_name'];
			}
		}
		return $records_new;
	}

	//* sites module

	//* IPv4 addresses of a website: the wildcard and the IPs of its server that the client may use
	function web_domain_ipv4($field, $record) {
		return $this->web_domain_ips('IPv4', $record);
	}

	//* IPv6 addresses of a website: none and the IPs of its server that the client may use
	function web_domain_ipv6($field, $record) {
		return $this->web_domain_ips('IPv6', $record);
	}

	//* PHP versions of a website: the active versions of its server for its PHP mode that the client may use, 0 is the default PHP of the server
	function web_domain_php_versions($field, $record) {
		global $app;

		$server_id = $this->web_domain_server_id($record);
		$app->uses('getconf');
		$web_config = $app->getconf->get_server_config($server_id, 'web');
		$server_type = !empty($web_config['server_type']) ? $web_config['server_type'] : 'apache';
		$php = isset($record['php']) ? $record['php'] : $this->web_domain_stored($record, 'php');
		if($php === null) $php = $web_config['php_handler'];
		if($server_type == 'nginx' && $php == 'fast-cgi') $php = 'php-fpm';

		$default = array(0 => $web_config['php_default_name']);
		if($php == 'php-fpm' || ($php == 'hhvm' && $server_type == 'nginx')) {
			$sql = "php_fpm_init_script != '' AND php_fpm_ini_dir != '' AND php_fpm_pool_dir != ''";
		} elseif($php == 'fast-cgi') {
			$sql = "php_fastcgi_binary != '' AND php_fastcgi_ini_dir != ''";
		} else {
			// the other PHP modes have no versions
			return $default;
		}
		$records = $app->db->queryAllRecords("SELECT server_php_id, name, sortprio FROM server_php WHERE ".$sql." AND server_id = ? AND client_id IN ? AND active = 'y' ORDER BY sortprio, server_php_id DESC", $server_id, $this->web_domain_client_ids($record));

		// the default PHP comes before the versions with a sort priority > 0, unless it is hidden
		if(!empty($web_config['php_default_hide']) && $web_config['php_default_hide'] != 'n') $default = array();
		$versions = array();
		if(is_array($records)) {
			foreach($records as $rec) {
				if($rec['sortprio'] > 0 && !empty($default)) {
					$versions = $versions + $default;
					$default = array();
				}
				$versions[$rec['server_php_id']] = $rec['name'];
			}
		}
		return $versions + $default;
	}

	//* Directive snippets of a website (0 = none): the active snippets for the web server type of its server that clients may see
	function web_domain_directive_snippets($field, $record) {
		return $this->web_domain_snippets($record, false);
	}

	//* Directive snippets for folders of a website: like web_domain_directive_snippets, but only snippets with a {FOLDER} placeholder
	function web_domain_folder_directive_snippets($field, $record) {
		return $this->web_domain_snippets($record, true);
	}

	private function web_domain_snippets($record, $folder) {
		global $app;

		$app->uses('getconf');
		$web_config = $app->getconf->get_server_config($this->web_domain_server_id($record), 'web');
		$server_type = !empty($web_config['server_type']) ? $web_config['server_type'] : 'apache';
		$records = $app->db->queryAllRecords("SELECT directive_snippets_id, name FROM directive_snippets WHERE customer_viewable = 'y' AND active = 'y'".($folder ? " AND snippet LIKE '%{FOLDER}%'" : '')." AND type = ? ORDER BY name ASC", $server_type);
		$snippets = array(0 => '-');
		if(is_array($records)) {
			foreach($records as $rec) $snippets[$rec['directive_snippets_id']] = $rec['name'];
		}
		return $snippets;
	}

	private function web_domain_ips($ip_type, $record) {
		global $app;

		$server_id = $this->web_domain_server_id($record);
		if($ip_type == 'IPv4') {
			$app->uses('getconf');
			$web_config = $app->getconf->get_server_config($server_id, 'web');
			$ips = ($web_config['enable_ip_wildcard'] == 'y') ? array('*' => '*') : array();
		} else {
			$ips = array('' => '');
		}

		// the admin may use all IPs of the server
		$sql = "SELECT ip_address FROM server_ip WHERE server_id = ? AND ip_type = ? AND virtualhost = 'y'";
		if($_SESSION['s']['user']['typ'] == 'admin') {
			$records = $app->db->queryAllRecords($sql, $server_id, $ip_type);
		} else {
			$records = $app->db->queryAllRecords($sql." AND client_id IN ?", $server_id, $ip_type, $this->web_domain_client_ids($record));
		}
		if(is_array($records)) {
			foreach($records as $rec) $ips[$rec['ip_address']] = $rec['ip_address'];
		}

		// subdomains and alias domains of a website have the IP of the website
		if(isset($record['type']) && ($record['type'] == 'vhostsubdomain' || $record['type'] == 'vhostalias') && isset($record['parent_domain_id'])) {
			$parent = $app->db->queryOneRecord("SELECT ip_address, ipv6_address FROM web_domain WHERE domain_id = ?", $app->functions->intval($record['parent_domain_id']));
			if(is_array($parent)) {
				$ip = ($ip_type == 'IPv4') ? $parent['ip_address'] : $parent['ipv6_address'];
				$ips[$ip] = $ip;
			}
		}
		return $ips;
	}

	//* The server of a website: the submitted or stored one, the one of the parent website, for a new website the server that the form selects first
	private function web_domain_server_id($record) {
		global $app;

		if(isset($record['server_id']) && $app->functions->intval($record['server_id']) > 0) return $app->functions->intval($record['server_id']);
		$server_id = $this->web_domain_stored($record, 'server_id');
		if($server_id !== null) return $app->functions->intval($server_id);
		// a new subdomain or alias domain is on the server of its website
		if(isset($record['parent_domain_id']) && $app->functions->intval($record['parent_domain_id']) > 0) {
			$tmp = $app->db->queryOneRecord("SELECT server_id FROM web_domain WHERE domain_id = ?", $app->functions->intval($record['parent_domain_id']));
			if(is_array($tmp)) return $app->functions->intval($tmp['server_id']);
		}

		if($_SESSION['s']['user']['typ'] != 'admin') {
			$client = $app->db->queryOneRecord("SELECT client.web_servers FROM sys_group, client WHERE sys_group.client_id = client.client_id AND sys_group.groupid = ?", $_SESSION['s']['user']['default_group']);
			$tmp = $app->db->queryOneRecord("SELECT server_id FROM server WHERE server_id IN ? ORDER BY server_id", explode(',', $client['web_servers']));
		} else {
			$app->uses('getconf');
			$settings = $app->getconf->get_global_config('sites');
			if($app->functions->intval($settings['default_webserver']) > 0) return $app->functions->intval($settings['default_webserver']);
			$tmp = $app->db->queryOneRecord("SELECT server_id FROM server WHERE web_server = 1 ORDER BY server_name LIMIT 0,1");
		}
		return is_array($tmp) ? $app->functions->intval($tmp['server_id']) : 0;
	}

	//* The clients whose IPs and PHP versions a website may use: 0 (all clients), the logged in client and the client of the website
	private function web_domain_client_ids($record) {
		global $app;

		$client_ids = array(0);
		if($_SESSION['s']['user']['typ'] != 'admin') $client_ids[] = $app->functions->intval($_SESSION['s']['user']['client_id']);

		if(isset($record['client_group_id']) && $app->functions->intval($record['client_group_id']) > 0) {
			$group_id = $record['client_group_id'];
		} elseif(isset($record['sys_groupid']) && $app->functions->intval($record['sys_groupid']) > 0) {
			$group_id = $record['sys_groupid'];
		} else {
			$group_id = $this->web_domain_stored($record, 'sys_groupid');
			// a new subdomain or alias domain belongs to the client of its website
			if($group_id === null && isset($record['parent_domain_id']) && $app->functions->intval($record['parent_domain_id']) > 0) {
				$tmp = $app->db->queryOneRecord("SELECT sys_groupid FROM web_domain WHERE domain_id = ?", $app->functions->intval($record['parent_domain_id']));
				if(is_array($tmp)) $group_id = $tmp['sys_groupid'];
			}
		}
		if($group_id !== null && $app->auth->is_allowed_client_group_id($group_id)) {
			$tmp = $app->db->queryOneRecord("SELECT client_id FROM sys_group WHERE groupid = ?", $app->functions->intval($group_id));
			if(is_array($tmp)) $client_ids[] = $app->functions->intval($tmp['client_id']);
		}
		return array_unique($client_ids);
	}

	//* A column of the stored website, null for a new website
	private function web_domain_stored($record, $column) {
		global $app;

		if(!isset($record['domain_id']) || $app->functions->intval($record['domain_id']) < 1) return null;
		$tmp = $app->db->queryOneRecord("SELECT ?? AS value FROM web_domain WHERE domain_id = ?", $column, $app->functions->intval($record['domain_id']));
		return is_array($tmp) ? $tmp['value'] : null;
	}

	//* mail module

	//* Spamfilter policies that the current user may use
	function mail_spamfilter_policies($field, $record) {
		global $app;

		$records = $app->db->queryAllRecords("SELECT id, policy_name FROM spamfilter_policy WHERE ".$app->tform->getAuthSQL('r')." ORDER BY policy_name");
		$records_new = array();
		if(is_array($records)) {
			foreach($records as $rec) {
				$records_new[$rec['id']] = $rec['policy_name'];
			}
		}
		return $records_new;
	}

	//* Servers of a spamfilter user: all mail servers for the admin, the servers of the own mail domains for other users,
	//* limited to the domain of the email field when it contains one
	function mail_spamfilter_user_servers($field, $record) {
		global $app;

		if($_SESSION["s"]["user"]["typ"] == 'admin') {
			$records = $app->db->queryAllRecords("SELECT server_id, server_name FROM server WHERE mail_server = 1 AND mirror_server_id = 0 ORDER BY server_name");
		} else {
			$sql = "SELECT DISTINCT server.server_id, server.server_name FROM server, mail_domain WHERE server.server_id = mail_domain.server_id AND server.mirror_server_id = 0 AND ".$app->tform->getAuthSQL('r', 'mail_domain');
			$email = isset($record['email']) && !is_array($record['email']) ? strtolower($app->functions->idn_encode(trim($record['email']))) : '';
			if(strpos($email, '@') !== false) {
				$records = $app->db->queryAllRecords($sql." AND mail_domain.domain = ? ORDER BY server.server_name", substr(strrchr($email, '@'), 1));
			} else {
				$records = $app->db->queryAllRecords($sql." ORDER BY server.server_name");
			}
		}
		$records_new = array();
		if(is_array($records)) {
			foreach($records as $rec) {
				$records_new[$rec['server_id']] = $rec['server_name'];
			}
		}
		return $records_new;
	}

	//* client module

	//* Additional client templates the user may read
	function client_additional_templates($field, $record) {
		global $app;

		$records = $app->db->queryAllRecords("SELECT template_id,template_name FROM client_template WHERE template_type = 'a' AND ".$app->tform->getAuthSQL('r')." ORDER BY template_name ASC");
		$records_new = array();
		if(is_array($records)) {
			foreach($records as $rec) {
				$records_new[$rec['template_id']] = $rec['template_name'];
			}
		}
		return $records_new;
	}

	//* Resellers the admin can assign a client to, 0 = no reseller
	function client_resellers($field, $record) {
		global $app;

		//* Not the client itself; its current reseller is listed also when it is no reseller any more
		$client_id = isset($record['client_id']) ? $app->functions->intval($record['client_id']) : 0;
		$tmp = $client_id > 0 ? $app->db->queryOneRecord('SELECT parent_client_id FROM client WHERE client_id = ?', $client_id) : null;
		$parent_id = is_array($tmp) ? $app->functions->intval($tmp['parent_client_id']) : 0;
		$records = $app->db->queryAllRecords("SELECT client.client_id, CONCAT(IF(client.company_name != '', CONCAT(client.company_name, ' :: '), ''), client.contact_name, ' (', client.username, IF(client.customer_no != '', CONCAT(', ', client.customer_no), ''), ')') as contactname FROM sys_group, client WHERE sys_group.client_id = client.client_id AND sys_group.client_id > 0 AND client.client_id != ? AND (client.limit_client != 0 OR client.client_id = ?) ORDER BY client.company_name, client.contact_name, sys_group.name", $client_id, $parent_id);
		$records_new = array(0 => '- '.$app->tform->lng('none_txt').' -');
		if(is_array($records)) {
			foreach($records as $rec) {
				$records_new[$rec['client_id']] = $rec['contactname'];
			}
		}
		return $records_new;
	}

	//* admin module

	//* Servers that the server of the record can mirror: all other servers that are not a mirror of it
	function admin_mirror_servers($field, $record) {
		global $app;

		$server_id = isset($record['server_id']) ? $app->functions->intval($record['server_id']) : 0;
		$records = $app->db->queryAllRecords("SELECT server_id, server_name FROM server WHERE server_id != ? AND mirror_server_id != ? ORDER BY server_name", $server_id, $server_id);
		$records_new = array();
		if(is_array($records)) {
			foreach($records as $rec) {
				$records_new[$rec['server_id']] = $rec['server_name'];
			}
		}
		return $records_new;
	}

	//* Mirror servers for an IP mapping
	function admin_ip_map_servers($field, $record) {
		global $app;

		$records = $app->db->queryAllRecords("SELECT server_id, server_name FROM server WHERE mirror_server_id > 0 ORDER BY server_name");
		$records_new = array();
		if(is_array($records)) {
			foreach($records as $rec) {
				$records_new[$rec['server_id']] = $rec['server_name'];
			}
		}
		return $records_new;
	}

	//* Source IPs for an IP mapping: the IPv4 virtual host addresses of the web servers that are not a mirror
	function admin_ip_map_source_ips($field, $record) {
		global $app;

		$records = $app->db->queryAllRecords("SELECT server_ip.ip_address, CONCAT(server_ip.ip_address,' :: [', server.server_name, ']') AS source FROM server_ip, server WHERE (server_ip.server_id = server.server_id AND server.web_server =1 AND mirror_server_id = 0 AND virtualhost = 'y' AND IP_TYPE = 'IPv4')");
		$records_new = array();
		if(is_array($records)) {
			foreach($records as $rec) {
				$records_new[$rec['ip_address']] = $rec['source'];
			}
		}
		return $records_new;
	}

	//* help, tools, vm and mailuser modules

	//* Sender of a support message: the logged in user
	function help_support_message_senders($field, $record) {
		return array($_SESSION['s']['user']['userid'] => $_SESSION['s']['user']['username']);
	}

	//* OpenVZ templates of a virtual server: all templates for the admin, the template of the client limit for other users (0 = all)
	function vm_openvz_templates($field, $record) {
		global $app;

		$template_id = 0;
		if($_SESSION['s']['user']['typ'] != 'admin') {
			$client = $app->db->queryOneRecord("SELECT client.limit_openvz_vm_template_id FROM sys_group, client WHERE sys_group.client_id = client.client_id AND sys_group.groupid = ?", $app->functions->intval($_SESSION['s']['user']['default_group']));
			if(is_array($client)) $template_id = $app->functions->intval($client['limit_openvz_vm_template_id']);
		}
		if($template_id == 0) {
			$records = $app->db->queryAllRecords("SELECT template_id, template_name FROM openvz_template ORDER BY template_name");
		} else {
			$records = $app->db->queryAllRecords("SELECT template_id, template_name FROM openvz_template WHERE template_id = ? ORDER BY template_name", $template_id);
		}
		$records_new = array();
		if(is_array($records)) {
			foreach($records as $rec) {
				$records_new[$rec['template_id']] = $rec['template_name'];
			}
		}
		return $records_new;
	}

	//* IP addresses of a virtual server: the not reserved IPs of its server that are free or used by the virtual server
	function vm_openvz_vm_ips($field, $record) {
		return $this->vm_openvz_ips($record, "(vm_id = 0 OR vm_id = ?)");
	}

	//* Additional IP addresses of a virtual server: the not reserved IPs of its server that are free or additional IPs of the virtual server
	function vm_openvz_vm_additional_ips($field, $record) {
		return $this->vm_openvz_ips($record, "(vm_id = 0 OR (vm_id = ? AND additional = 'y'))");
	}

	private function vm_openvz_ips($record, $vm_sql) {
		global $app;

		$vm_id = isset($record['vm_id']) ? $app->functions->intval($record['vm_id']) : 0;
		$server_id = isset($record['server_id']) && !is_array($record['server_id']) ? $app->functions->intval($record['server_id']) : 0;
		// the server of the stored virtual server, for a new one the server that the form selects first
		if($server_id < 1 && $vm_id > 0) {
			$tmp = $app->db->queryOneRecord("SELECT server_id FROM openvz_vm WHERE vm_id = ?", $vm_id);
		} elseif($server_id < 1) {
			$tmp = $app->db->queryOneRecord("SELECT server_id FROM server WHERE vserver_server = 1 AND mirror_server_id = 0 ORDER BY server_name LIMIT 0,1");
		}
		if($server_id < 1) $server_id = is_array($tmp) ? $app->functions->intval($tmp['server_id']) : 0;

		$records = $app->db->queryAllRecords("SELECT ip_address FROM openvz_ip WHERE reserved = 'n' AND ".$vm_sql." AND server_id = ? ORDER BY ip_address", $vm_id, $server_id);
		$ips = array();
		if(is_array($records)) {
			foreach($records as $rec) {
				$ips[$rec['ip_address']] = $rec['ip_address'];
			}
		}
		return $ips;
	}

	//* Spamfilter policies that a mailbox user may use: the policies that the owner of the mailbox may read
	function mailuser_spamfilter_policies($field, $record) {
		global $app;

		$mailuser = $app->db->queryOneRecord("SELECT sys_groupid FROM mail_user WHERE mailuser_id = ?", $app->functions->intval($_SESSION['s']['user']['mailuser_id']));
		$user = is_array($mailuser) ? $app->db->queryOneRecord("SELECT userid, typ, `groups` FROM sys_user WHERE default_group = ?", $mailuser['sys_groupid']) : null;
		if(is_array($user) && $user['typ'] == 'admin') {
			$auth_sql = '1';
		} elseif(is_array($user) && $user['userid'] > 0 && $user['groups'] != '') {
			$auth_sql = $app->tform->getAuthSQL('r', '', $user['userid'], $user['groups']);
		} else {
			$auth_sql = "sys_perm_other LIKE '%r%'";
		}
		$records = $app->db->queryAllRecords("SELECT id, policy_name FROM spamfilter_policy WHERE ".$auth_sql." ORDER BY policy_name");
		$records_new = array();
		if(is_array($records)) {
			foreach($records as $rec) {
				$records_new[$rec['id']] = $rec['policy_name'];
			}
		}
		return $records_new;
	}

}

?>
