<?php

/*
Copyright (c) 2007, Till Brehm, projektfarm Gmbh
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.
    * Neither the name of ISPConfig nor the names of its contributors
      may be used to endorse or promote products derived from this software without
      specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

/*
    DNS validation
*/

class validate_dns {

	function increase_serial($serial){
		global $app, $conf;

		// increase serial
		$serial_date = $app->functions->intval(substr($serial, 0, 8));
		$count = $app->functions->intval(substr($serial, 8, 2));
		$current_date = date("Ymd");
		if($serial_date >= $current_date){
			$count += 1;
			if ($count > 99) {
				$serial_date += 1;
				$count = 0;
			}
			$count = str_pad($count, 2, "0", STR_PAD_LEFT);
			$new_serial = $serial_date.$count;
		} else {
			$new_serial = $current_date.'01';
		}
		return $new_serial;
	}

	/* A value of a zone file line may not contain a line break */
	function validate_no_line_break($field_name, $field_value, $validator) {
		global $app;

		if(strpbrk((string)$field_value, "\r\n") === false) return '';
		return $this->invalid_value($field_name);
	}

	/* TXT data is written into the zone file inside quotes: quotes and backslashes in it are escaped, several strings are separated by spaces (a" "b) */
	function validate_txt_data($field_name, $field_value, $validator) {
		if(preg_match('/^"(?:[^"\\\\]++|\\\\.)*+"(?:\s++"(?:[^"\\\\]++|\\\\.)*+")*+$/sD', '"'.$field_value.'"')) return '';
		return $this->invalid_value($field_name);
	}

	/* CAA data: flags, tag and the value, quoted without quotes and backslashes or as one plain word */
	function validate_caa_data($field_name, $field_value, $validator) {
		if(preg_match('/^(0|128) [a-zA-Z0-9]{1,15} (?:"[^"\\\\]*"|[^\s"\\\\();]+)$/D', (string)$field_value)) return '';
		return $this->invalid_value($field_name);
	}

	/* allow-update list of a zone: comma separated IP addresses or networks, key <name>, ACL names (any, none, localhost, ...), each optionally negated with ! */
	function validate_update_acl($field_name, $field_value, $validator) {
		foreach(preg_split('/[,;]/', (string)$field_value) as $entry) {
			if(trim($entry) === '') continue;
			$entry = preg_replace('/^!\s*/', '', trim($entry));
			if(preg_match('/^(?:key[ \t]+("?)[A-Za-z0-9._-]{1,255}\1|(?!key$)[A-Za-z][A-Za-z0-9._-]{0,254})$/D', $entry)) continue;
			if($entry === '' || $this->validate_ip($field_name, $entry, array('allowempty' => 'n', 'errmsg' => 'update_acl_txt')) !== '') return $this->invalid_value($field_name);
		}
		return '';
	}

	/* The error text for an invalid value of a field */
	private function invalid_value($field_name) {
		global $app;

		$label = (isset($app->tform) && isset($app->tform->wordbook[$field_name.'_txt'])) ? $app->tform->wordbook[$field_name.'_txt'] : $field_name;
		return sprintf($app->lng('err_invalid_option'), $label)."<br />\r\n";
	}

	/* Without the domain module, clients and resellers can not use the name of a primary or secondary zone of another owner, or a name below or above it */
	function zone_of_other_owner($origin) {
		global $app;

		if($_SESSION['s']['user']['typ'] == 'admin') return false;
		$app->uses('ini_parser,getconf');
		$settings = $app->getconf->get_global_config('domains');
		if($settings['use_domain_module'] == 'y') return false;
		$origin = strtolower(rtrim((string)$origin, '.')).'.';
		$groups = array_map('intval', explode(',', $_SESSION['s']['user']['groups']));
		foreach(array('dns_soa', 'dns_slave') as $table) {
			$rec = $app->db->queryOneRecord("SELECT id FROM ?? WHERE sys_groupid NOT IN ? AND (origin = ? OR RIGHT(?, CHAR_LENGTH(origin) + 1) = CONCAT('.', origin) OR RIGHT(origin, ?) = ?)",
				$table, $groups, $origin, $origin, strlen($origin) + 1, '.'.$origin);
			if(is_array($rec)) return true;
		}
		return false;
	}

	/* Validator for the name of a primary or secondary zone, see zone_of_other_owner() */
	function validate_zone_owner($field_name, $field_value, $validator) {
		global $app;

		if(!$this->zone_of_other_owner($field_value)) return '';
		if($app->tform->primary_id > 0) {
			//* a zone that already has this name keeps it
			$rec = $app->db->queryOneRecord("SELECT ?? FROM ?? WHERE ?? = ?", $field_name, $app->tform->formDef['db_table'], $app->tform->formDef['db_table_idx'], $app->tform->primary_id);
			if(is_array($rec) && strtolower(rtrim($rec[$field_name], '.')) == strtolower(rtrim($field_value, '.'))) return '';
		}
		return sprintf($app->lng('err_invalid_option'), $app->tform->wordbook[$field_name.'_txt'])."<br />\r\n";
	}

	function validate_ip($field_name, $field_value, $validator) {
		global $app;

		$errorMessage = '';

		if($validator['allowempty'] != 'y') $validator['allowempty'] = 'n';
		if($validator['allowempty'] == 'y' && $field_value == '') {
			//* Do nothing
		} elseif ($field_value == 'any' && $field_name != "also_notify") {
			//* Do nothing
		} else {
			//* Check if its a IPv4 or IPv6 address/range
			if(isset($validator['separator']) && $validator['separator'] != '') {
				//* When the field may contain several IP addresses, split them by the char defined as separator
				$field_value_array = explode($validator['separator'], $field_value);
			} else {
				$field_value_array[] = $field_value;
			}
			// Check if it's a valid input
			foreach($field_value_array as $field_value) {
				// Check if the IP is valid without range
				$subnet = '';
				$ip = trim($field_value);
				if(strpos($ip, '/') !== false) {
					list($ip, $subnet) = explode('/', $ip, 2);
					$ip = trim($ip);
				}
				if(function_exists('filter_var')) {
						if(!filter_var($ip, FILTER_VALIDATE_IP)) {
						$errmsg = $validator['errmsg'];
						$errorMessage .= $app->tform->lng($errmsg)."<br />\r\n";
					}
				} else $this->errorMessage .= "function filter_var missing <br />\r\n";
				// Check if the range is valid
				if ($subnet !== '' && filter_var($ip, FILTER_VALIDATE_IP)) {
					$max = filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) ? 128 : 32;
					//* BIND takes no networks in also-notify and only network addresses (no host bits) in address match lists
					if ($field_name == 'also_notify' || !ctype_digit($subnet) || $subnet < 1 || $subnet > $max) {
						$errmsg = $validator['errmsg'];
						$errorMessage .= $app->tform->lng($errmsg)."<br />\r\n";
					} else {
						$bits = '';
						foreach(str_split(inet_pton($ip)) as $byte) $bits .= str_pad(decbin(ord($byte)), 8, '0', STR_PAD_LEFT);
						if(strpos(substr($bits, (int)$subnet), '1') !== false) {
							$errmsg = $validator['errmsg'];
							$errorMessage .= $app->tform->lng($errmsg)."<br />\r\n";
						}
					}
				}
			}
		}
		return $errorMessage;
	}

	/* Clients and resellers can use only public IP addresses (no private, loopback, link-local or reserved ones), the format is checked by ISIP */
	function validate_public_ip($field_name, $field_value, $validator) {
		global $app;

		if($_SESSION['s']['user']['typ'] == 'admin') return '';
		foreach(explode(',', (string)$field_value) as $ip) {
			$ip = trim($ip);
			if(filter_var($ip, FILTER_VALIDATE_IP) && !filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) return $app->tform->lng($validator['errmsg'])."<br />\r\n";
		}
		return '';
	}

}
