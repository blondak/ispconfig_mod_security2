<?php

/*
Copyright (c) 2007 - 2011, Till Brehm, projektfarm Gmbh
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.
    * Neither the name of ISPConfig nor the names of its contributors
      may be used to endorse or promote products derived from this software without
      specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

--UPDATED 08.2009--
Full SOAP support for ISPConfig 3.1.4 b
Updated by Arkadiusz Roch & Artur Edelman
Copyright (c) Tri-Plex technology

*/

class remoting {

	//* remote session timeout in seconds
	private $session_timeout = 1800;

	public $oldDataRecord;
	public $dataRecord;
	public $id;

	private $_methods = array();

	/*
	These variables shall stay global.
	Please do not make them private variables.

	private $app;
    private $conf;
    */

	public function __construct($methods = array())
	{
		global $app;
		$app->uses('remoting_lib');

		$this->_methods = $methods;
	}

	//* remote login function
	public function login($username, $password, $client_login = false)
	{
		global $app, $conf;

		// Maintenance mode
		if($app->is_under_maintenance()){
			throw new SoapFault('maintenance_mode', 'This ISPConfig installation is currently under maintenance. We should be back shortly. Thank you for your patience.');
			return false;
		}

		if(empty($username)) {
			throw new SoapFault('login_username_empty', 'The login username is empty.');
			return false;
		}

		if(empty($password)) {
			throw new SoapFault('login_password_empty', 'The login password is empty.');
			return false;
		}

		//* Delete old remoting sessions
		$sql = "DELETE FROM remote_session WHERE tstamp < UNIX_TIMESTAMP()";
		$app->db->query($sql);
		
		//* Check for max. login attempts
		if(!$app->auth->login_attempt(10, 5)) {
			throw new SoapFault('login_failure_limit', 'The login failure limit has been reached.');
			return false;
		}

		if($client_login == true) {
			//* Client logins (sys_user accounts) are not supported, the remote API is an admin level API for remote users only.
			throw new SoapFault('client_login_failed', 'The login failed. Client logins are not supported by the remote API.');
			return false;
		} else {
			$sql = "SELECT * FROM remote_user WHERE remote_username = ?";
			$remote_user = $app->db->queryOneRecord($sql, (string)$username);
			if($remote_user) {
				//* The address check runs before the password check, a refused address gets the same answer as a wrong password
				$allowed_ips = array();
				if (trim($remote_user['remote_ips']) != '') {
					$allowed_ips = explode(',',$remote_user['remote_ips']);
					foreach($allowed_ips as $i => $allowed) {
						if(!filter_var($allowed, FILTER_VALIDATE_IP)) {
							// get the ip for a hostname
							unset($allowed_ips[$i]);
							$temp=dns_get_record($allowed, DNS_A+DNS_AAAA);
							if(is_array($temp) && !empty($temp)) {
								foreach($temp as $t) {
									if(isset($t['ip'])) $allowed_ips[] = $t['ip'];
									if(isset($t['ipv6'])) $allowed_ips[] = $t['ipv6'];
								}
								unset($temp);
							}
						}
					}
				}
				$allowed_ips=array_unique($allowed_ips);
				$ip = $_SERVER['REMOTE_ADDR'];
				//* Without remote access only this server may log in; with remote access the address list decides (an empty list allows every address)
				$remote_allowed = ($remote_user['remote_access'] != 'y' && ($ip == '::1' || $ip == '127.0.0.1'));
				if(!$remote_allowed && $remote_user['remote_access'] == 'y') {
					if(trim($remote_user['remote_ips']) == '') {
						$remote_allowed=true;
					} else {
						$ip_bin = inet_pton($ip);
						foreach($allowed_ips as $allowed) {
							if($ip_bin == inet_pton(trim($allowed))) {
								$remote_allowed=true;
								break;
							}
						}
					}
				}
				//* Only passwords encrypted with crypt are accepted
				if(substr($remote_user['remote_password'], 0, 1) !== '$' || !hash_equals($remote_user['remote_password'], crypt(stripslashes($password), $remote_user['remote_password']))) {
					$remote_user = null;
				} elseif(!$remote_allowed) {
					$app->auth_log('Failed remote API login for user \''. $remote_user['remote_username'] .'\' from '. $ip .' at '. date('Y-m-d H:i:s') .': the address is not allowed');
					$remote_user = null;
				}
			} else {
				// same time as the password check of a known user
				$app->auth->crypt_password($password);
			}
			if($remote_user && $remote_user['remote_userid'] > 0) {
				//* Create a remote user session
				// session id must begin with a char, not digit, to avoid mysql type confusion abuse
				$remote_session = substr(str_shuffle('abcdefghijklmnopqrstuvwxyz'),0,1).bin2hex(random_bytes(20));
				$remote_userid = $remote_user['remote_userid'];
				$remote_functions = $remote_user['remote_functions'];
				$tstamp = time() + $this->session_timeout;
				$sql = 'INSERT INTO remote_session (remote_session,remote_userid,remote_functions,tstamp,remote_ip'
					.') VALUES (?, ?, ?, ?, ?)';
				$app->db->query($sql, $remote_session,$remote_userid,$remote_functions,$tstamp, $ip);
				
				//* A successful login does not count as attempt
				$app->auth->login_attempt_success();
				
				return $remote_session;
			} else {
				throw new SoapFault('login_failed', 'The login failed. Username or password wrong.');
				return false;
			}
		}

	}

	//* remote logout function
	public function logout($session_id)
	{
		global $app;

		if(empty($session_id)) {
			throw new SoapFault('session_id_empty', 'The SessionID is empty.');
			return false;
		}

		$sql = "DELETE FROM remote_session WHERE remote_session = ?";
		if($app->db->query($sql, (string)$session_id) != false) {
			return true;
		} else {
			return false;
		}
	}

	//** protected functions -----------------------------------------------------------------------------------

	//* true when config.inc.php selects the behaviour of remote API version 1
	protected function api_v1() {
		global $conf;
		return isset($conf['remote_api_version']) && $conf['remote_api_version'] < 2;
	}

	protected function klientadd($formdef_file, $reseller_id, $params)
	{
		global $app;

		//* Load the form definition
		$app->remoting_lib->loadFormDef($formdef_file);

		//* load the user profile of the client
		$app->remoting_lib->loadUserProfile($reseller_id);

		$params = $this->unset_empty_selects($params);

		//* Get the SQL query
		$sql = $app->remoting_lib->getSQL($params, 'INSERT', 0);

		//* Check if no system user with that username exists
		$username = $params["username"];
		$tmp = $app->db->queryOneRecord("SELECT count(userid) as number FROM sys_user WHERE username = ?", $username);
		if($tmp['number'] > 0) $app->remoting_lib->errorMessage .= "Duplicate username<br />";

		//* Stop on error while preparing the sql query
		if($app->remoting_lib->errorMessage != '') {
			throw new SoapFault('data_processing_error', $app->remoting_lib->errorMessage);
			return false;
		}

		//* Execute the SQL query
		$app->db->query($sql);
		if($app->db->errorMessage != '') {
			throw new SoapFault('database_error', $app->db->errorMessage . ' '.$sql);
			return false;
		}
		if ( isset($params['_primary_id'] ))
			$insert_id = $params['_primary_id'];
		else
			$insert_id = $app->db->insertID();


		//* Stop on error while executing the sql query
		if($app->remoting_lib->errorMessage != '') {
			throw new SoapFault('data_processing_error', $app->remoting_lib->errorMessage);
			return false;
		}

		$this->id = $insert_id;
		$this->dataRecord = $params;

		$app->plugin->raiseEvent('client:' . (isset($params['limit_client']) && $params['limit_client'] > 0 ? 'reseller' : 'client') . ':on_after_insert', $this);

		/*
		if($app->db->errorMessage != '') {
			throw new SoapFault('database_error', $app->db->errorMessage . ' '.$sql);
			return false;
		}
		*/

		/* copied from the client_edit php */
		$app->uses('functions');
		$app->functions->generate_ssh_key($this->id, $username);



		//$app->uses('tform');
		//* Save changes to Datalog
		if($app->remoting_lib->formDef["db_history"] == 'yes') {
			$new_rec = $app->remoting_lib->getDataRecord($insert_id);
			$app->remoting_lib->datalogSave('INSERT', $insert_id, array(), $new_rec);
			$app->remoting_lib->ispconfig_sysuser_add($params, $insert_id);

			if($reseller_id) {
				$client_group = $app->db->queryOneRecord("SELECT * FROM sys_group WHERE client_id = ?", $insert_id);
				$reseller_user = $app->db->queryOneRecord("SELECT * FROM sys_user WHERE client_id = ?", $reseller_id);
				$app->auth->add_group_to_user($reseller_user['userid'], $client_group['groupid']);
				$app->db->query("UPDATE client SET parent_client_id = ? WHERE client_id = ?", $reseller_id, $insert_id);
			}

		}
		return $insert_id;
	}

	//* an empty value of a select field without an empty option is handled like a field that is not sent (loaded form)
	private function unset_empty_selects($params)
	{
		global $app;

		if(!is_array($params)) return $params;
		foreach($app->remoting_lib->formDef['fields'] as $key => $field) {
			if(!isset($params[$key]) || $params[$key] !== '' || !in_array($field['formtype'], array('SELECT', 'RADIO'))) continue;
			$options = $app->remoting_lib->getFieldOptions($field, $params, '', true);
			if(is_array($options) && !array_key_exists('', $options)) unset($params[$key]);
		}
		return $params;
	}

	protected function insertQuery($formdef_file, $client_id, $params, $event_identifier = '')
	{
		$sql = $this->insertQueryPrepare($formdef_file, $client_id, $params);
		if($sql !== false) return $this->insertQueryExecute($sql, $params, $event_identifier);
		else return false;
	}

	protected function insertQueryPrepare($formdef_file, $client_id, $params)
	{
		global $app;

		$app->uses('remoting_lib');

		//* load the user profile of the client
		$app->remoting_lib->loadUserProfile($client_id);

		//* Load the form definition
		$app->remoting_lib->loadFormDef($formdef_file);

		$params = $this->unset_empty_selects($params);

		//* Get the SQL query
		$sql = $app->remoting_lib->getSQL($params, 'INSERT', 0);
		if($app->remoting_lib->errorMessage != '') {
			throw new SoapFault('data_processing_error', $app->remoting_lib->errorMessage);
			return false;
		}
		$app->log('Executed insertQueryPrepare', LOGLEVEL_DEBUG);
		return $sql;
	}

	protected function insertQueryExecute($sql, $params, $event_identifier = '')
	{
		global $app;

		$app->uses('remoting_lib');

		$app->db->query($sql);

		if($app->db->errorMessage != '') {
			throw new SoapFault('database_error', $app->db->errorMessage . ' '.$sql);
			return false;
		}

		if ( isset($params['_primary_id'] ))
			$insert_id = $params['_primary_id'];
		else
			$insert_id = $app->db->insertID();

		// set a few values for compatibility with tform actions, mostly used by plugins
		$this->id = $insert_id;
		$this->dataRecord = $params;
		$app->log('Executed insertQueryExecute, raising events now if any: ' . $event_identifier, LOGLEVEL_DEBUG);
		if($event_identifier != '') $app->plugin->raiseEvent($event_identifier, $this);

		//$app->uses('tform');
		//* Save changes to Datalog
		if($app->remoting_lib->formDef["db_history"] == 'yes') {
			$new_rec = $app->remoting_lib->getDataRecord($insert_id);
			$app->remoting_lib->datalogSave('INSERT', $insert_id, array(), $new_rec);
		}
		return $insert_id;
	}

	protected function updateQuery($formdef_file, $client_id, $primary_id, $params, $event_identifier = '')
	{
		global $app;

		$sql = $this->updateQueryPrepare($formdef_file, $client_id, $primary_id, $params);
		if($sql !== false) return $this->updateQueryExecute($sql, $primary_id, $params, $event_identifier);
		else return false;
	}

	protected function updateQueryPrepare($formdef_file, $client_id, $primary_id, $params)
	{
		global $app;

		//* The ID is used in SQL queries and handed to plugins, so it must be a positive integer.
		$primary_id = $app->functions->intval($primary_id);
		if($primary_id < 1) {
			throw new SoapFault('invalid_id', 'The ID has to be > 0.');
		}

		$app->uses('remoting_lib');

		//* load the user profile of the client
		$app->remoting_lib->loadUserProfile($client_id);

		//* Load the form definition
		$app->remoting_lib->loadFormDef($formdef_file);

		//* get old record and merge with params, so only new values have to be set in $params
               $old_rec = $app->remoting_lib->getDataRecord($primary_id, $client_id);

		foreach ($app->remoting_lib->formDef['fields'] as $fieldName => $fieldConf)
        {
            //* the stored hash sent back unchanged keeps the password, it is not hashed again
            if ($fieldConf['formtype'] === 'PASSWORD' && isset($params[$fieldName], $old_rec[$fieldName]) && $params[$fieldName] !== '' && $params[$fieldName] === $old_rec[$fieldName]) {
                unset($params[$fieldName]);
            }
            if ($fieldConf['formtype'] === 'PASSWORD' && empty($params[$fieldName])) {
                unset($old_rec[$fieldName]);
            }
        }

		$params = $app->functions->array_merge($old_rec,$params);

		//* stored values of the fields the form names are kept when they are sent back unchanged, also when they fail a check
		$app->remoting_lib->stored_values = isset($app->remoting_lib->formDef['keep_stored_values']) ? array_intersect_key((array)$old_rec, array_flip($app->remoting_lib->formDef['keep_stored_values'])) : null;

		//* Get the SQL query
		$sql = $app->remoting_lib->getSQL($params, 'UPDATE', $primary_id);

		// throw new SoapFault('debug', $sql);
		if($app->remoting_lib->errorMessage != '') {
			throw new SoapFault('data_processing_error', $app->remoting_lib->errorMessage);
			return false;
		}

		return $sql;
	}

	protected function updateQueryExecute($sql, $primary_id, $params, $event_identifier = '')
	{
		global $app;

		//* The ID is used in SQL queries and handed to plugins, so it must be a positive integer.
		$primary_id = $app->functions->intval($primary_id);
		if($primary_id < 1) {
			throw new SoapFault('invalid_id', 'The ID has to be > 0.');
		}

		$app->uses('remoting_lib');

		$old_rec = $app->remoting_lib->getDataRecord($primary_id);

		// set a few values for compatibility with tform actions, mostly used by plugins
		$this->oldDataRecord = $old_rec;
		$this->id = $primary_id;
		//* the plugins get the whole record, also when only some fields are sent
		$this->dataRecord = $app->functions->array_merge((array)$old_rec, $params);

		$app->db->query($sql);

		if($app->db->errorMessage != '') {
			throw new SoapFault('database_error', $app->db->errorMessage . ' '.$sql);
			return false;
		}

		$affected_rows = $app->db->affectedRows();
		$app->log('Executed updateQueryExecute, raising events now if any: ' . $event_identifier, LOGLEVEL_DEBUG);

		if($event_identifier != '') $app->plugin->raiseEvent($event_identifier, $this);

		//* Save changes to Datalog
		if($app->remoting_lib->formDef["db_history"] == 'yes') {
			$new_rec = $app->remoting_lib->getDataRecord($primary_id);
			$app->remoting_lib->datalogSave('UPDATE', $primary_id, $old_rec, $new_rec);
		}

		return $affected_rows;
	}

	protected function deleteQuery($formdef_file, $primary_id, $event_identifier = '')
	{
		global $app;

		//* The ID is used in SQL queries and handed to plugins, so it must be a positive integer.
		$primary_id = $app->functions->intval($primary_id);
		if($primary_id < 1) {
			throw new SoapFault('invalid_id', 'The ID has to be > 0.');
		}

		$app->uses('remoting_lib');

		//* load the user profile of the client
		$app->remoting_lib->loadUserProfile(0);

		//* Load the form definition
		$app->remoting_lib->loadFormDef($formdef_file);

		$old_rec = $app->remoting_lib->getDataRecord($primary_id);

		// set a few values for compatibility with tform actions, mostly used by plugins
		$this->oldDataRecord = $old_rec;
		$this->id = $primary_id;
		$this->dataRecord = $old_rec;
		$app->log('Executed deleteQuery, raising events now if any: ' . $event_identifier, LOGLEVEL_DEBUG);
		//$this->dataRecord = $params;

		//* Get the SQL query
		$sql = $app->remoting_lib->getDeleteSQL($primary_id);
		$app->db->errorMessage = '';
		$app->db->query($sql);
		$affected_rows = $app->db->affectedRows();

		if($app->db->errorMessage != '') {
			throw new SoapFault('database_error', $app->db->errorMessage . ' '.$sql);
			return false;
		}

		if($event_identifier != '') {
			$app->plugin->raiseEvent($event_identifier, $this);
		}

		//* Save changes to Datalog
		if($app->remoting_lib->formDef["db_history"] == 'yes') {
			$app->remoting_lib->datalogSave('DELETE', $primary_id, $old_rec, array());
		}


		return $affected_rows;
	}


	protected function checkPerm($session_id, $function_name)
	{
		global $app;
		$dobre=array();
		$session = $this->getSession($session_id);
		if(!$session){
			return false;
		}

		//* Client login sessions are not supported
		if($session['client_login'] == 1) {
			$app->log("REMOTE-LIB DENY: ".$session_id ." /". $function_name, LOGLEVEL_WARN);
			return false;
		}

		$dobre= str_replace(';', ',', $session['remote_functions']);
		$check = in_array($function_name, explode(',', $dobre) );
		if(!$check) {
			$app->log("REMOTE-LIB DENY: ".$session_id ." /". $function_name, LOGLEVEL_WARN);
		}
		return $check;
	}

	//* Admin permission of security_settings.ini, a remote user counts as the superadmin
	protected function checkSecurityPermission($permission)
	{
		global $app;
		$app->uses('getconf');
		$security_config = $app->getconf->get_security_config('permissions');
		if(!isset($security_config[$permission]) || !in_array($security_config[$permission], array('yes', 'superadmin'), true)) {
			$app->log("REMOTE-LIB DENY: security setting ".$permission, LOGLEVEL_WARN);
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
		}
	}

	//* Checks a value for the server or system settings like the settings form does, returns the value to store
	protected function checkConfigValue($formdef_file, $section, $key, $value, $stored_config, $server_id = 0)
	{
		global $app, $conf;

		if(!preg_match('/^\w+$/D', $section) || !preg_match('/^\w+$/D', $key)) {
			throw new SoapFault('invalid_function_parameter', 'Invalid function parameter.');
		}
		if(isset($conf['remote_api_version']) && $conf['remote_api_version'] < 2) return $value;

		//* the fields of the section's own tab (some keys exist in several tabs)
		include $formdef_file;
		if(!isset($form['tabs'][$section]['fields'][$key])) return $value;
		$field = $form['tabs'][$section]['fields'][$key];

		$app->uses('remoting_lib,tform');
		$app->remoting_lib->errorMessage = '';
		//* only strings and numbers are stored, anything else is stored as empty string
		$value = (is_string($value) || is_numeric($value)) ? (string)$value : '';
		if(isset($field['filters']) && is_array($field['filters'])) $value = $app->remoting_lib->filterField($key, $value, $field['filters'], 'SAVE');
		if(isset($stored_config[$section][$key]) && $value === (string)$stored_config[$section][$key]) return $value;

		//* custom validators read the edited server from tform
		$app->tform->primary_id = $server_id;
		if(isset($field['validators']) && is_array($field['validators'])) $app->remoting_lib->validateField($key, $value, $field['validators']);
		if(in_array($field['formtype'], array('SELECT', 'RADIO', 'CHECKBOX')) && isset($field['value']) && is_array($field['value'])) {
			$options = ($field['formtype'] == 'CHECKBOX') ? array_values($field['value']) : array_keys($field['value']);
			if(!in_array($value, array_map('strval', $options), true)) $app->remoting_lib->errorMessage .= sprintf($app->lng('err_invalid_option'), $key)."\r\n";
		}
		if($app->remoting_lib->errorMessage != '') {
			throw new SoapFault('data_processing_error', $app->remoting_lib->errorMessage);
		}
		return $value;
	}


	protected function getSession($session_id)
	{
		global $app;

		if(empty($session_id)) {
			throw new SoapFault('session_id_empty', 'The SessionID is empty.');
			return false;
		}
		
		if(!is_string($session_id)) {
			throw new SoapFault('session_id_nostring', 'Wrong SessionID datatype.');
			return false;
		}
		
		$ip_md5 = $app->auth->login_attempt_key();
		$sql = "SELECT SUM(`times`) AS `times` FROM `attempts_login` WHERE `ip`= ? AND  `login_time` > (NOW() - INTERVAL 5 MINUTE)";
		$alreadyfailed = $app->db->queryOneRecord($sql, $ip_md5);

		if($alreadyfailed['times'] >= 10) {
			throw new SoapFault('session_failure_limit', 'The Session failure limit has been reached.');
			return false;
		}

		$sql = "SELECT * FROM remote_session WHERE remote_session = ? AND tstamp >= UNIX_TIMESTAMP()";
		$session = $app->db->queryOneRecord($sql, (string)$session_id);
		
		if(!is_array($session)) {
			$app->auth->login_attempt(10, 5);
			throw new SoapFault('session_does_not_exist', 'The Session is expired or does not exist.');
			return false;
		}
		
		$ip = $_SERVER['REMOTE_ADDR'];
		if($session['remote_ip'] != $ip) {
			throw new SoapFault('session_ip_mismatch', 'Session IP mismatch.');
			return false;
		}
		
		if($session['remote_userid'] > 0) {
			return $session;
		} else {
			$app->auth->login_attempt(10, 5);
			throw new SoapFault('session_does_not_exist', 'The Session is expired or does not exist.');
			return false;
		}
	}

	public function server_get($session_id, $server_id = null, $section ='') {
		global $app;
		if(!$this->checkPerm($session_id, 'server_get')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		if (!empty($session_id)) {
			if(!empty($server_id)) {
				$app->uses('remoting_lib , getconf');
				$section_config =  $app->getconf->get_server_config($server_id, $section);
				return $section_config;
			} else {
				$servers = array();
				$sql = "SELECT server_id FROM server WHERE 1";
				$all = $app->db->queryAllRecords($sql);
				foreach($all as $s) {
					$servers[$s['server_id']] = $app->getconf->get_server_config($s['server_id'], $section);
				}
				unset($all);
				unset($s);
				return $servers;
			}
		} else {
			return false;
		}
	}

	/**
	    Gets a list of all servers
	    @param int session_id
	    @param int server_name
	    @author Marius Cramer <m.cramer@pixcept.de> 2014
    */
	public function server_get_all($session_id)
    {
        global $app;
		if(!$this->checkPerm($session_id, 'server_get')) {
        	throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
            return false;
		}
		if (!empty($session_id)) {
			$sql = "SELECT server_id, server_name FROM server WHERE 1";
			$servers = $app->db->queryAllRecords($sql);
			return $servers;
		} else {
			return false;
		}
	}

	/**
	 * Get a list of functions
	 * @param  int  session id
	 * @return mixed array of the available functions
	 * @author Julio Montoya <gugli100@gmail.com> BeezNest 2010
	 */


	public function get_function_list($session_id)
	{
		if(!$this->checkPerm($session_id, 'get_function_list')) {
			throw new SoapFault('permission_denied', 'You do not have the permissions to access this function.');
			return false;
		}
		return $this->_methods;
	}

}

?>
