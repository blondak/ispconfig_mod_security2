<?php

/*
Copyright (c) 2007, Till Brehm, projektfarm Gmbh
Copyright (c) 2021, Jesse Norell <jesse@kci.net>
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.
    * Neither the name of ISPConfig nor the names of its contributors
      may be used to endorse or promote products derived from this software without
      specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

class validate_mail_transport {

	function get_error($errmsg) {
		global $app;

		if(isset($app->tform->wordbook[$errmsg])) {
			return $app->tform->wordbook[$errmsg]."<br>\r\n";
		} else {
			return $errmsg."<br>\r\n";
		}
	}

	/* Validator function for checking that the 'domain' is not already set as mail_domain */
	function validate_isnot_maildomain($field_name, $field_value, $validator) {
		global $app, $conf;

		if(isset($app->remoting_lib->primary_id)) {
			$id = $app->remoting_lib->primary_id;
			$server_id = $app->remoting_lib->dataRecord['server_id'];
		} else {
			$id = $app->tform->primary_id;
			$server_id = $app->tform_actions->dataRecord['server_id'];
		}

		// Only error if the domain exists as mail_domain on the same server
		$sql = "SELECT domain_id, domain FROM mail_domain WHERE domain = ? AND server_id = ? AND domain_id != ?";
		$domain_check = $app->db->queryOneRecord($sql, $field_value, $server_id, $id);

		if($domain_check) return $this->get_error('domain_is_maildomain');

	}

	/* Validator function for checking that the 'domain' is not already set as mail_transport */
	function validate_isnot_mailtransport($field_name, $field_value, $validator) {
		global $app, $conf;

		if(isset($app->remoting_lib->primary_id)) {
			$id = $app->remoting_lib->primary_id;
		} else {
			$id = $app->tform->primary_id;
		}

		$sql = "SELECT transport_id, domain FROM mail_transport WHERE domain = ? AND transport_id != ?";
		$domain_check = $app->db->queryOneRecord($sql, $field_value, $id);

		if($domain_check) return $this->get_error('domain_is_transport');

	}

	/* Validator function for checking the 'domain' of a mail transport */
	function validate_domain($field_name, $field_value, $validator) {
		global $app, $conf;

		if(isset($app->remoting_lib->primary_id)) {
			$id = $app->remoting_lib->primary_id;
			$server_id = $app->remoting_lib->dataRecord['server_id'];
		} else {
			$id = $app->tform->primary_id;
			$server_id = $app->tform_actions->dataRecord['server_id'];
		}

		// mail_transport.domain (could also be an email address) must be unique per server
		$sql = "SELECT transport_id, domain FROM mail_transport WHERE domain = ? AND server_id = ? AND transport_id != ?";
		$domain_check = $app->db->queryOneRecord($sql, $field_value, $server_id, $id);

		if($domain_check) return $this->get_error('domain_error_unique');
	}

	/* Validator function for the transport: one line "name:nexthop"; in the panel the nexthop format of the type, type custom only for admins */
	function validate_transport($field_name, $field_value, $validator) {
		global $app;

		if(!preg_match('/^[A-Za-z0-9._-]*(?::[^\x00-\x1F\x7F]*)?$/D', $field_value)) return $this->get_error('transport_error_format');
		if(isset($app->remoting_lib->primary_id)) return;

		$parts = explode(':', $field_value, 2);
		if(!isset($parts[1])) $parts[0] = 'custom';
		if(in_array($parts[0], array('smtp', 'uucp', 'slow'))) {
			//* empty, host, [host] or [IPv6 address], each with an optional port
			if(!preg_match('/^(?:(?:\[[A-Za-z0-9.:-]{1,253}\]|[A-Za-z0-9.-]{1,253})(?::\d{1,5})?)?$/D', $parts[1])) return $this->get_error('transport_error_format');
		} elseif($parts[0] == '') {
			if($parts[1] != '') return $this->get_error('transport_error_format');
		} elseif($parts[0] != 'error' && $_SESSION['s']['user']['typ'] != 'admin') {
			return $this->get_error('transport_error_custom');
		}
	}

	/* Validator function for checking that the 'domain' of a mail transport is a domain of the user or a subdomain of it */
	function validate_own_domain($field_name, $field_value, $validator) {
		global $app;

		// admins and the remote API may route any domain
		if($_SESSION['s']['user']['typ'] == 'admin') return;

		$domain = strtolower($field_value);
		if(strpos($domain, '*') !== false) return $this->get_error('domain_error_owner');
		if(strpos($domain, '@') !== false) $domain = substr($domain, strrpos($domain, '@') + 1);
		$domain = ltrim($domain, '.');
		if($domain == '') return $this->get_error('domain_error_owner');

		//* the domain itself and all parent domains
		$names = array();
		$parts = explode('.', $domain);
		while(!empty($parts)) {
			$names[] = implode('.', $parts);
			array_shift($parts);
		}
		$groups = array_map('intval', explode(',', $_SESSION['s']['user']['groups']));

		$queries = array(
			"SELECT domain_id FROM mail_domain WHERE sys_groupid IN ? AND domain IN ?",
			"SELECT domain_id FROM web_domain WHERE sys_groupid IN ? AND type IN ('vhost','alias','subdomain','vhostsubdomain','vhostalias') AND TRIM(LEADING '*.' FROM domain) IN ?",
			"SELECT id FROM dns_soa WHERE sys_groupid IN ? AND TRIM(TRAILING '.' FROM origin) IN ?"
		);
		$app->uses('ini_parser,getconf');
		$settings = $app->getconf->get_global_config('domains');
		if($settings['use_domain_module'] == 'y') $queries[] = "SELECT domain_id FROM domain WHERE sys_groupid IN ? AND domain IN ?";

		foreach($queries as $sql) {
			if(is_array($app->db->queryOneRecord($sql, $groups, $names))) return;
		}
		return $this->get_error('domain_error_owner');
	}

}
