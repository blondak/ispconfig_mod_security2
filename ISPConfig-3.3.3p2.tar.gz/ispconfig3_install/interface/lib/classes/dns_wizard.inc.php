<?php
/*
Copyright (c) 2023, Adam Biciste <adam@freshost.cz>
All rights reserved.

Copyright (c) 2008, Till Brehm, projektfarm Gmbh
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.
    * Neither the name of ISPConfig nor the names of its contributors
      may be used to endorse or promote products derived from this software without
      specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

class dns_wizard
{
	//* Validator of the DNS template text: known sections, known zone settings and records with all columns
	public function check_template($field_name, $field_value, $validator) {
		global $app;

		$zone_keys = array('origin', 'ns', 'mbox', 'refresh', 'retry', 'expire', 'minimum', 'ttl', 'xfer', 'also_notify', 'update_acl', 'dnssec_wanted', 'dnssec_algo');
		$section = '';
		$error_lines = array();
		foreach(explode("\n", (string)$field_value) as $line_number => $row) {
			$row = trim($row);
			if($row == '') continue;
			if($row == '[ZONE]') {
				$section = 'zone';
			} elseif($row == '[DNS_RECORDS]') {
				$section = 'dns_records';
			} elseif(substr($row, 0, 1) == '[') {
				$section = '';
				$error_lines[] = $line_number + 1;
			} elseif($section == 'zone') {
				$parts = explode('=', $row, 2);
				if(count($parts) != 2 || !in_array(trim($parts[0]), $zone_keys)) $error_lines[] = $line_number + 1;
			} elseif($section != 'dns_records' || count(explode('|', $row)) < 5) {
				$error_lines[] = $line_number + 1;
			}
		}
		if(!empty($error_lines)) return sprintf($app->tform->wordbook[$validator['errmsg']], implode(', ', $error_lines))."<br />\r\n";
	}

	function create(array $data)
	{
        global $app;
        $app->uses('getconf');

        // get system settings
        $settings = $app->getconf->get_global_config();

        $error = '';

        // get the correct server_id
        if (isset($data['server_id'])) {
            $server_id = $app->functions->intval($data['server_id']);
            $post_server_id = true;
        } elseif (isset($data['server_id_value'])) {
            $server_id = $app->functions->intval($data['server_id_value']);
            $post_server_id = true;
        } else {
            $server_id = $app->functions->intval($settings['dns']['default_dnsserver']);
            if(empty($server_id)) {
                $tmp = $app->db->queryOneRecord('SELECT server_id FROM server WHERE dns_server = 1 LIMIT 0,1');
                if(!empty($tmp['server_id'])) {
                    $server_id = $tmp['server_id'];
                } else {
                    $error .= $app->lng('error_no_server_id').'<br />';
                }
            }
            $post_server_id = false;
        }

        if ($post_server_id)
        {
            $client_group_id = $app->functions->intval($_SESSION["s"]["user"]["default_group"]);
            $client = $app->db->queryOneRecord("SELECT dns_servers FROM sys_group, client WHERE sys_group.client_id = client.client_id and sys_group.groupid = ?", $client_group_id);

            $client['dns_servers_ids'] = explode(',', $client['dns_servers']);

            // Check if chosen server is in authorized servers for this client
            if (!(is_array($client['dns_servers_ids']) && in_array($server_id, $client['dns_servers_ids'])) && $_SESSION["s"]["user"]["typ"] != 'admin') {
                $error .= $app->lng('error_not_allowed_server_id').'<br />';
            }
        }
        /*
        else
        {
            $error .= $app->lng('error_no_server_id').'<br />';
        }
        */

        // apply filters
        if(isset($data['domain']) && $data['domain'] != ''){
            /* check if the domain module is used - and check if the selected domain can be used! */
            if ($settings['domains']['use_domain_module'] == 'y') {
                // get domain_id for domain
                $tmp = $app->db->queryOneRecord('SELECT domain_id from domain where domain = ?', $data['domain']);
                $domain_id = $app->functions->intval( $tmp['domain_id']);
                
                if ($_SESSION["s"]["user"]["typ"] == 'admin' || $app->auth->has_clients($_SESSION['s']['user']['userid'])) {
                    $data['client_group_id'] = $app->tools_sites->getClientIdForDomain($domain_id);
                }
                $domain_check = $app->tools_sites->checkDomainModuleDomain($domain_id);
                if($domain_check === false) {
                    // invalid domain selected
                    $data['domain'] = '';
                } else {
                    $data['domain'] = $domain_check;
                }
            } else {
                $data['domain'] = $app->functions->idn_encode($data['domain']);
                $data['domain'] = strtolower($data['domain']);
            }
        }
        if(isset($data['ns1']) && $data['ns1'] != ''){
            $data['ns1'] = $app->functions->idn_encode($data['ns1']);
            $data['ns1'] = strtolower($data['ns1']);
        }
        if(isset($data['ns2']) && $data['ns2'] != ''){
            $data['ns2'] = $app->functions->idn_encode($data['ns2']);
            $data['ns2'] = strtolower($data['ns2']);
        }
        if(isset($data['email']) && $data['email'] != ''){
            $data['email'] = $app->functions->idn_encode($data['email']);
            $data['email'] = strtolower($data['email']);
        }


        # fixme: this regex is pretty poor for domain validation
        if(isset($data['domain']) && $data['domain'] == '') $error .= $app->lng('error_domain_empty').'<br />';
        elseif(isset($data['domain']) && !preg_match('/^[\w\.\-]{1,64}\.[a-zA-Z0-9\-]{2,63}$/D', $data['domain'])) $error .= $app->lng('error_domain_regex').'<br />';

        if(isset($data['ip']) && $data['ip'] == '') $error .= $app->lng('error_ip_empty').'<br />';
        elseif(isset($data['ip']) && filter_var($data['ip'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) === false) $error .= $app->lng('error_ip_regex').'<br />';

        //if(isset($data['ipv6']) && $data['ipv6'] == '') $error .= $app->lng('error_ipv6_empty').'<br />';
        if(isset($data['ipv6']) && $data['ipv6'] != '' && filter_var($data['ipv6'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) === false) $error .= $app->lng('error_ipv6_regex').'<br />';

        # fixme: this regex is pretty poor for hostname validation
        if(isset($data['ns1']) && $data['ns1'] == '') $error .= $app->lng('error_ns1_empty').'<br />';
        elseif(isset($data['ns1']) && !preg_match('/^[\w\.\-]{1,64}\.[a-zA-Z0-9]{2,63}$/D', $data['ns1'])) $error .= $app->lng('error_ns1_regex').'<br />';

        if(isset($data['ns2']) && $data['ns2'] == '') $error .= $app->lng('error_ns2_empty').'<br />';
        elseif(isset($data['ns2']) && !preg_match('/^[\w\.\-]{1,64}\.[a-zA-Z0-9]{2,63}$/D', $data['ns2'])) $error .= $app->lng('error_ns2_regex').'<br />';

        //* the address becomes the mbox of the zone, so no quoted local part
        if(isset($data['email']) && $data['email'] == '') $error .= $app->lng('error_email_empty').'<br />';
        elseif(isset($data['email']) && (filter_var($data['email'], FILTER_VALIDATE_EMAIL) === false || preg_match('/[\s"|\\\\]/', $data['email']))) $error .= $app->lng('error_email_regex').'<br />';

        // make sure that the record belongs to the client group and not the admin group when admin inserts it
        if($_SESSION["s"]["user"]["typ"] == 'admin' && isset($data['client_group_id'])) {
            $sys_groupid = $app->functions->intval($data['client_group_id']);
        } elseif(isset($data['client_group_id']) && $app->auth->is_allowed_client_group_id($data['client_group_id'])) {
            $sys_groupid = $app->functions->intval($data['client_group_id']);
        } else {
            $sys_groupid = $_SESSION["s"]["user"]["default_group"];
        }

        $tform_def_file = "../../web/dns/form/dns_soa.tform.php";
        $app->uses('tform');
        $app->tform->loadFormDef($tform_def_file);

        if($_SESSION['s']['user']['typ'] != 'admin') {
            if(!$app->tform->checkClientLimit('limit_dns_zone')) {
                $error .= $app->tform->wordbook["limit_dns_zone_txt"];
            }
            if(!$app->tform->checkResellerLimit('limit_dns_zone')) {
                $error .= $app->tform->wordbook["limit_dns_zone_txt"];
            }
        }


        // the values replace the template placeholders in the parsed fields
        $placeholders = array();
        foreach(array('{DOMAIN}' => 'domain', '{IP}' => 'ip', '{IPV6}' => 'ipv6', '{NS1}' => 'ns1', '{NS2}' => 'ns2', '{EMAIL}' => 'email') as $placeholder => $key) {
            if(isset($data[$key]) && $data[$key] != '') $placeholders[$placeholder] = $data[$key];
        }

        // Parse the template
        $template_id = (isset($data['template_id']))?$app->functions->intval($data['template_id']):0;
        //* clients and resellers can use only the templates that the wizard offers
        $template_record = $app->db->queryOneRecord("SELECT * FROM dns_template WHERE template_id = ?".($_SESSION['s']['user']['typ'] == 'admin' ? '' : " AND visible = 'Y'"), $template_id);
        $tpl_rows = explode("\n", is_array($template_record) ? $template_record['template'] : '');
        $section = '';
        $vars = array();
        $vars['xfer']='';
        //* the template can override the checkbox
        $vars['dnssec_wanted'] = isset($data['dnssec']) ? 'Y' : 'N';
        $vars['dnssec_algo']='ECDSAP256SHA256';
        $dns_rr = array();
        $unknown_sections = array();
        foreach($tpl_rows as $line_number => $row) {
            $row = trim($row);
            if(substr($row, 0, 1) == '[') {
                if($row == '[ZONE]') {
                    $section = 'zone';
                } elseif($row == '[DNS_RECORDS]') {
                    $section = 'dns_records';
                } else {
                    $section = '';
                    $unknown_sections[] = $line_number + 1;
                }
            } else {
                if($row != '') {
                    // Handle zone section
                    if($section == 'zone') {
                        $parts = explode('=', $row);
                        $key = trim($parts[0]);
                        $val = strtr(trim($parts[1]), $placeholders);
                        if($key != '') $vars[$key] = $val;
                    }
                    // Handle DNS Record rows
                    if($section == 'dns_records') {
                        $parts = explode('|', $row);
                        foreach($parts as $i => $part) $parts[$i] = strtr($part, $placeholders);
                        $dns_rr[] = array(
                            'name' => $parts[1],
                            'type' => $parts[0],
                            'data' => $parts[2],
                            'aux'  => $parts[3],
                            'ttl'  => $parts[4]
                        );
                    }
                }
            }

        } // end foreach
        if(!empty($unknown_sections)) $error .= sprintf($app->lng('error_template_lines'), implode(', ', $unknown_sections)).'<br />';

        if(isset($data['dkim']) && preg_match('/^[\w\.\-\/]{1,255}\.[a-zA-Z0-9\-]{2,63}[\.]{0,1}$/D', $data['domain'])) {
            $sql = $app->db->queryOneRecord("SELECT dkim_public, dkim_selector FROM mail_domain WHERE domain = ? AND dkim = 'y' AND ".$app->tform->getAuthSQL('r'), $data['domain']);
            $public_key = $sql['dkim_public'];
            if ($public_key!='') {
                if (empty($sql['dkim_selector'])) $sql['dkim_selector'] = 'default';
                $dns_record=str_replace(array("\r\n", "\n", "\r", "-----BEGIN PUBLIC KEY-----", "-----END PUBLIC KEY-----"), '', $public_key);
                $dns_rr[] = array('name' => $sql['dkim_selector'].'._domainkey.'.$data['domain'].'.', 'type' => 'TXT', 'data' => 'v=DKIM1; t=s; p='.$dns_record, 'aux' => null, 'ttl' => null);
            }
        }

        if($vars['origin'] == '') $error .= $app->lng('error_origin_empty').'<br />';
        if($vars['ns'] == '') $error .= $app->lng('error_ns_empty').'<br />';
        if($vars['mbox'] == '') $error .= $app->lng('error_mbox_empty').'<br />';
        if($vars['refresh'] == '') $error .= $app->lng('error_refresh_empty').'<br />';
        if($vars['retry'] == '') $error .= $app->lng('error_retry_empty').'<br />';
        if($vars['expire'] == '') $error .= $app->lng('error_expire_empty').'<br />';
        if($vars['minimum'] == '') $error .= $app->lng('error_minimum_empty').'<br />';
        if($vars['ttl'] == '') $error .= $app->lng('error_ttl_empty').'<br />';

        $app->uses('validate_dns');
        if($vars['origin'] != '' && $app->validate_dns->zone_of_other_owner($vars['origin'])) $error .= sprintf($app->lng('err_invalid_option'), $app->tform->wordbook['origin_txt']).'<br />';
        elseif($vars['origin'] != '' && is_array($app->db->queryOneRecord('SELECT id FROM dns_soa WHERE origin = ?', $vars['origin']))) $error .= $app->lng('error_zone_exists').'<br />';

        //* dots of the local part are escaped
        $at = strrpos($vars['mbox'], '@');
        if($at !== false) $vars['mbox'] = str_replace('.', '\.', substr($vars['mbox'], 0, $at)).'.'.substr($vars['mbox'], $at + 1);

        //* the template values get the format checks of the zone form and the TXT record form
        foreach(array('origin', 'ns', 'mbox') as $key) {
            foreach($app->tform->formDef['tabs']['dns_soa']['fields'][$key]['validators'] as $validator) {
                if($validator['type'] == 'REGEX' && !preg_match($validator['regex'].'sD', (string)$vars[$key])) $error .= $app->tform->wordbook[$validator['errmsg']].'<br />';
            }
        }
        $error .= $app->validate_dns->validate_update_acl('update_acl', isset($vars['update_acl']) ? $vars['update_acl'] : '', array());
        foreach($dns_rr as $rr) {
            if($rr['type'] == 'TXT') $error .= $app->validate_dns->validate_txt_data('data', $rr['data'], array());
        }

        if($error == '') {
            // Insert the soa record
            $sys_userid = $_SESSION['s']['user']['userid'];
            $origin = $vars['origin'];
            $ns = $vars['ns'];
            $mbox = $vars['mbox'];
            $refresh = $app->functions->intval($vars['refresh']);
            $retry = $app->functions->intval($vars['retry']);
            $expire = $app->functions->intval($vars['expire']);
            $minimum = $app->functions->intval($vars['minimum']);
            $ttl = $app->functions->intval($vars['ttl']);
            $xfer = $vars['xfer'];
            $also_notify = $vars['also_notify'];
            $update_acl = $vars['update_acl'];
            $dnssec_wanted = $vars['dnssec_wanted'];
            $dnssec_algo = $vars['dnssec_algo'];
            $serial = $app->validate_dns->increase_serial(0);

            $insert_data = array(
                "sys_userid" => $sys_userid,
                "sys_groupid" => $sys_groupid,
                "sys_perm_user" => 'riud',
                "sys_perm_group" => 'riud',
                "sys_perm_other" => '',
                "server_id" => $server_id,
                "origin" => $origin,
                "ns" => $ns,
                "mbox" => $mbox,
                "serial" => $serial,
                "refresh" => $refresh,
                "retry" => $retry,
                "expire" => $expire,
                "minimum" => $minimum,
                "ttl" => $ttl,
                "active" => 'N', // Activated later when all DNS records are added.
                "xfer" => $xfer,
                "also_notify" => $also_notify,
                "update_acl" => $update_acl,
                "dnssec_wanted" => $dnssec_wanted,
                "dnssec_algo" => $dnssec_algo
            );

            $dns_soa_id = $app->db->datalogInsert('dns_soa', $insert_data, 'id');
            if(!($dns_soa_id > 0)) return $app->lng('error_zone_exists');
            $app->plugin->raiseEvent('dns:wizard:on_after_insert', $dns_soa_id);

            // Insert the dns_rr records
            if(is_array($dns_rr) && $dns_soa_id > 0) {
                foreach($dns_rr as $rr) {
                    $insert_data = array(
                        "sys_userid" => $sys_userid,
                        "sys_groupid" => $sys_groupid,
                        "sys_perm_user" => 'riud',
                        "sys_perm_group" => 'riud',
                        "sys_perm_other" => '',
                        "server_id" => $server_id,
                        "zone" => $dns_soa_id,
                        "name" => $rr['name'],
                        "type" => $rr['type'],
                        "data" => $rr['data'],
                        "aux" => $rr['aux'],
                        "ttl" => $rr['ttl'],
                        "active" => 'Y'
                    );
                    $dns_rr_id = $app->db->datalogInsert('dns_rr', $insert_data, 'id');
                }
            }

            // Activate the DNS zone.
            $app->db->datalogUpdate('dns_soa', array('active' => 'Y'), 'id', $dns_soa_id);

            return 'ok';

        } else {
            return $error;
        }
	}

}
